#!/usr/bin/env python3
"""Whole-process RSS, including parsing, verification, warmups and serialization."""
import hashlib,json,re,subprocess,time
from pathlib import Path
out=Path('/tmp/palim-scale-measurements-20261005')
root=Path('/tmp/palim-guard-construction-measurements-20261005')
binary=root/'probes/candidate/target/release/timing'
summary=json.loads((out/'summary.json').read_text());rows=[]
for name,mode in [('scalar-guards-100000','plain-guarded'),('file_migrations_move_copy_5000','guarded'),('rotate-1000000','guarded'),('disjoint-20000','guarded'),('array-parent-guards-1024','inverse-guarded')]:
 start=time.monotonic()
 r=subprocess.run(['/usr/bin/time','-l',str(binary),str(out/'fixtures'/f'{name}.json'),mode],capture_output=True,text=True,timeout=180)
 assert r.returncode==0,r.stderr
 result=json.loads(r.stdout)
 prior=next(row for row in summary if row['case']==name and row['mode']==mode)
 assert hashlib.sha256(result['wire'].encode()).hexdigest()==prior['wire_sha256']
 match=re.search(r'(\d+)\s+maximum resident set size',r.stderr);assert match,r.stderr
 row=dict(case=name,mode=mode,peak_rss_bytes=int(match[1]),wall_seconds=time.monotonic()-start,roundtrip_verified=result['roundtrip_verified'],time_stderr=r.stderr,
  scope='Whole default-allocator timing process; includes loaded fixtures, original typed patch, initial output, independent apply/inverse verification, serialized wire, warmups and samples. Not incremental API-only memory.')
 rows.append(row);(out/'rss.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,mode,round(row['peak_rss_bytes']/1e6,2),'MB whole process',flush=True)
