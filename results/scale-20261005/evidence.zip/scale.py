#!/usr/bin/env python3
"""Bounded scale matrix; reuse frozen, hash-verified default and counted binaries."""
import argparse,copy,hashlib,json,platform,statistics,subprocess,time
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('frozen',type=Path)
parser.add_argument('output',type=Path)
args=parser.parse_args()
frozen=args.frozen.resolve(); out=args.output.resolve()
out.mkdir(exist_ok=False,parents=True); (out/'fixtures').mkdir()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
prior=json.loads((frozen/'environment.json').read_text())
binaries={}
for label in ['baseline','candidate']:
 for kind in ['timing','allocation']:
  p=frozen/'probes'/label/'target/release'/kind
  assert sha(p)==prior['builds'][label][kind+'_sha256'],str(p)
  binaries[label,kind]=p
 for name,expected in prior['source'][label]['hashes'].items():
  assert sha(frozen/'sources'/label/name)==expected,name

# Same scalar naming and migration payloads as the previous guard comparison.
fixtures=[]; cases=[]
def add(fixture,modes,baseline_modes=()):
 name=fixture['name']; path=out/'fixtures'/f'{name}.json'
 path.write_text(json.dumps(fixture,ensure_ascii=False,separators=(',',':'))+'\n')
 fixtures.append(dict(name=name,path=str(path),sha256=sha(path),
   left_bytes=len(json.dumps(fixture['left'],ensure_ascii=False,separators=(',',':')).encode()),
   right_bytes=len(json.dumps(fixture['right'],ensure_ascii=False,separators=(',',':')).encode())))
 for mode in modes:cases.append(dict(case=name,mode=mode,baseline=mode in baseline_modes))
for n in [2000,10000,100000]:
 add(dict(name=f'scalar-guards-{n}',left={'fields':{f'field_{i:04}':i for i in range(n)}},
   right={'fields':{f'field_{i:04}':i+1 for i in range(n)}},
   patch=[dict(op='replace',path=f'/fields/field_{i:04}',value=i+1) for i in range(n)]),
   ['plain','plain-guarded','inverse-guarded'],['plain-guarded','inverse-guarded'] if n==100000 else [])
seed=json.loads((frozen/'fixtures/file_migrations_move_copy_800.json').read_text())
for n in [800,2000,5000]:
 f=copy.deepcopy(seed);f['name']=f'file_migrations_move_copy_{n}';f['size']=n
 f['provenance']='Scaled synthetic migration; exact 800-item payload family retained'
 for side,prefix in [('left','legacy'),('right','current')]:
  entries={}
  for i in range(n):
   v=copy.deepcopy(seed['left']['files']['legacy_component_0000.toml']);v['component']=i
   entries[f'{prefix}_component_{i:04}.toml']=v
  f[side]['files']=entries
 add(f,['optimized','guarded'],['guarded'] if n==5000 else [])
for n in [2000,20000,100000,1000000]:
 a=[f'entry-{i:08d}' for i in range(n)]
 add(dict(name=f'rotate-{n}',left=a,right=a[-1:]+a[:-1]),['optimized','guarded'],['guarded'] if n==1000000 else [])
for n in [2000,10000,20000]:
 a=[f'entry-{i:08d}' for i in range(n)]
 add(dict(name=f'disjoint-{n}',left=a,right=[f'other-{i:08d}' for i in range(n)]),
   ['optimized','guarded'],['guarded'] if n==20000 else [])
for n in [128,512,1024]:
 add(dict(name=f'array-parent-guards-{n}',left={'items':list(range(2*n))},
   right={'items':list(range(n,2*n))},patch=[dict(op='remove',path='/items/0') for _ in range(n)]),
   ['inverse','inverse-guarded'],['inverse-guarded'] if n==1024 else [])
environment=dict(platform=platform.platform(),cpu=subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),
 memory_bytes=int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True)),rustc=prior['rustc'],date=time.strftime('%Y-%m-%d'),
 base_commit='50c72d59fd02d8a0e642100ad30be0771fb4eab0',candidate='Uncommitted typed-guard construction; source hashes match the current worktree before measurement',
 source=prior['source'],builds=prior['builds'],runner_sha256=sha(Path(__file__)),fixture_manifest=fixtures,
 timing=prior['timing'],samples='3 warmups, >=10ms calibration cap2048, 9 batches, 3 independent processes/version; scalar guard highest sizes and selected largest cases alternate version order',
 allocation='One separate counter process per input/mode/version; successful requested allocations; peak incremental live requests exclude held inputs, initial output and serialized wire, not RSS',
 correctness='Every probe independently applies the generated RFC patch with json-patch 4.2.0, checks target equality, generates inverse and applies it to restore source; outside timing',
 bounds='180-second timeout per process; measured modes and counts are fixed by runner; million-item rotation only, fully disjoint capped at 20k, growing-array guarded inverse capped at 1024 removes')
dump(out/'environment.json',environment)
records=[]; failures=[]; summary=[]
def run_case(case,label,kind,repeat):
 started=time.monotonic(); cmd=[str(binaries[label,kind]),str(out/'fixtures'/f"{case['case']}.json"),case['mode']]
 try:
  r=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
  if r.returncode:raise RuntimeError(f'exit {r.returncode}: {r.stderr[-4000:]}')
  row=json.loads(r.stdout)
  row['wire_sha256']=hashlib.sha256(row.pop('wire').encode()).hexdigest()
  row.update(version=label,kind=kind,repeat=repeat,wall_seconds=time.monotonic()-started)
  if row['samples_ms']:row['median_ms']=statistics.median(row['samples_ms'])
  assert row['roundtrip_verified']
  if kind=='allocation':assert row['allocation']['final_live_delta_bytes']==0
  records.append(row);dump(out/'measurements.json',records)
  return True
 except (subprocess.TimeoutExpired,RuntimeError,AssertionError,json.JSONDecodeError) as e:
  failure=dict(case=case['case'],mode=case['mode'],version=label,kind=kind,repeat=repeat,error=str(e),wall_seconds=time.monotonic()-started)
  failures.append(failure);dump(out/'failures.json',failures)
  print('FAILED',json.dumps(failure),flush=True);return False
for index,case in enumerate(cases):
 labels=['baseline','candidate'] if case['baseline'] else ['candidate']
 ok=True
 for repeat in range(3):
  order=labels if (repeat+index)%2==0 else list(reversed(labels))
  for label in order:
   if not run_case(case,label,'timing',repeat):ok=False;break
  if not ok:break
 if ok:
  for label in labels:
   if not run_case(case,label,'allocation',0):ok=False;break
 selected=[r for r in records if r['case']==case['case'] and r['mode']==case['mode']]
 if ok:
  assert len({r['wire_sha256'] for r in selected})==1,(case,'non-identical output')
  row=dict(case=case['case'],mode=case['mode'],wire_sha256=selected[0]['wire_sha256'],roundtrip_verified=True)
  for label in labels:
   ts=[r for r in selected if r['version']==label and r['kind']=='timing']
   alloc=next(r for r in selected if r['version']==label and r['kind']=='allocation')
   row[label]=dict(median_ms=statistics.median(r['median_ms'] for r in ts),process_medians_ms=[r['median_ms'] for r in ts],
    wire_bytes=ts[0]['wire_bytes'],operations=ts[0]['operations'],allocation=alloc['allocation'])
  if case['baseline']:row['speedup']=row['baseline']['median_ms']/row['candidate']['median_ms']
  summary.append(row);dump(out/'summary.json',summary)
  print('DONE',case['case'],case['mode'],f"{row['candidate']['median_ms']:.3f} ms",f"wire {row['candidate']['wire_bytes']}",flush=True)
 print('PROGRESS',index+1,'/',len(cases),flush=True)
dump(out/'failures.json',failures)
print(json.dumps(dict(combinations=len(cases),completed=len(summary),records=len(records),failures=len(failures))),flush=True)
if failures:raise SystemExit(1)
