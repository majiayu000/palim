#!/usr/bin/env python3
import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=False,parents=True)
env=json.loads((root/'frozen-environment.json').read_text())
for label in ['baseline','candidate']:
 shutil.copytree(root/'sources'/label,out/'sources'/label)
 shutil.copytree(root/'probes'/label,out/'probes'/label)
 p=out/'probes'/label
 subprocess.run(['cargo','build','--release','--locked','--bins'],cwd=p,check=True)
 for kind in ['timing','allocation']:
  env['builds'][label][kind+'_sha256']=hashlib.sha256((p/'target/release'/kind).read_bytes()).hexdigest()
 env['builds'][label]['lock_sha256']=hashlib.sha256((p/'Cargo.lock').read_bytes()).hexdigest()
 env['builds'][label]['stderr']='Rebuilt from portable evidence; original build details remain in frozen-environment.json'
shutil.copytree(root/'fixtures',out/'fixtures')
env['rustc']=subprocess.check_output(['rustc','-Vv'],text=True)
(out/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
