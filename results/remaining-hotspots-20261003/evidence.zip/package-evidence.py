import hashlib
import json
import pathlib
import sys
import zipfile

P = pathlib.Path('/Users/apple/Desktop/code/AI/tool/secrets/palim-next')
O = P / 'results/remaining-hotspots-20261003'
O.mkdir(parents=True, exist_ok=True)
entries = {}


def add(path, name):
    path = pathlib.Path(path)
    if path.is_file():
        entries[name] = path.read_bytes()


def tree(path, prefix):
    path = pathlib.Path(path)
    for f in sorted(path.rglob('*')):
        if f.is_file() and not any(x in f.parts for x in ['target', 'node_modules', '.git']):
            add(f, prefix + '/' + str(f.relative_to(path)))


def benchmark(directory, prefix):
    root = pathlib.Path(directory)
    for name in ['environment.json', 'measurements.json', 'summary.json']:
        add(root / name, prefix + '/' + name)
    for name in ['sources', 'fixtures', 'probes']:
        tree(root / name, prefix + '/' + name)


benchmark('/tmp/palim-next-benchmark-accepted-20261003', 'final-internal')
benchmark('/tmp/palim-next-benchmark-20261003', 'stages/tuple-before-shrink')
benchmark('/tmp/palim-next-benchmark-final-20261003', 'stages/lazy-before-short-line-fix')
root = pathlib.Path('/tmp/palim-next-competitors-final-20261003')
for name in ['environment.json', 'measurements.json', 'summary.json']:
    add(root / name, 'final-competitors/' + name)
add('/tmp/palim-next-competitors-final.py', 'final-competitors/run.py')
competitor = pathlib.Path('/tmp/palim-competitor-20261003')
for name in ['js/bench.mjs', 'js/verify.mjs', 'js/package.json', 'js/package-lock.json', 'go/main.go', 'go/go.mod', 'go/go.sum']:
    add(competitor / name, 'competitor-probes/' + name)
tree(competitor / 'fixtures', 'competitor-probes/fixtures')
for name in ['palim-next-rfc-20261003', 'palim-next-rfc-capacity-20261003', 'palim-next-pipeline-20261003']:
    root = pathlib.Path('/tmp') / name
    for f in root.iterdir():
        if f.is_file() and f.suffix in ['.json', '.jsonl', '.md', '.txt', '.patch', '.py', '.rs']:
            add(f, 'diagnostic/' + name + '/' + f.name)
    for folder in ['probe', 'baseline-driver', 'candidate-driver', 'baseline', 'candidate']:
        d = root / folder
        for f in ['Cargo.toml', 'Cargo.lock']:
            add(d / f, 'diagnostic/' + name + '/' + folder + '/' + f)
        tree(d / 'src', 'diagnostic/' + name + '/' + folder + '/src')
for name in ['palim-next-text-20261003', 'palim-next-text-lazy-20261003', 'palim-next-text-endpoints-20261003']:
    add(pathlib.Path('/tmp') / name / 'evidence.zip', 'diagnostic/' + name + '.zip')
for directory in sys.argv[1:]:
    tree(directory, 'diagnostic/' + pathlib.Path(directory).name)
for name in ['palim-next-start-20261003.json', 'palim-next-final-review-20261003.json', 'palim-next-endpoint-review-20261003.json', 'palim-next-attribution-20261003.json', 'palim-next-package-consumer-20261003.json']:
    add('/tmp/' + name, 'checks/' + name)
for group in ['rust', 'interop', 'fuzz', 'package']:
    add('/tmp/palim-next-checks-20261003-' + group + '.json', 'checks/' + group + '.json')
add('/tmp/palim-next-checks.py', 'checks/run.py')
tree('/tmp/palim-next-consumer-20261003/src', 'checks/package-consumer/src')
for name in ['Cargo.toml', 'Cargo.lock']:
    add('/tmp/palim-next-consumer-20261003/' + name, 'checks/package-consumer/' + name)
add(P / 'tests/fixtures/correctness.json', 'checks/correctness.json')
tree(P / 'tests', 'checks/tests')
tree(P / 'fuzz/fuzz_targets', 'checks/fuzz/fuzz_targets')
for name in ['Cargo.toml', 'Cargo.lock']:
    add(P / 'fuzz' / name, 'checks/fuzz/' + name)
add('/Users/apple/go/pkg/mod/github.com/w!i2!l/jsondiff@v0.7.1/differ.go', 'prior-art/go-jsondiff-v0.7.1/differ.go')
add('/Users/apple/go/pkg/mod/github.com/w!i2!l/jsondiff@v0.7.1/LICENSE', 'prior-art/go-jsondiff-v0.7.1/LICENSE')
add(P / 'tools/remaining-hotspots.py', 'remaining-hotspots.py')
add(pathlib.Path(__file__), 'package-evidence.py')
entries['REPRODUCE.md'] = b'''# Frozen experiment artifacts

Final tables use final-internal and final-competitors only. Earlier snapshots
are kept under stages to explain measured regressions and rejected variants.

For internal measurements, unpack the two final-internal/sources trees and run
remaining-hotspots.py with baseline, candidate and a new output directory. The
runner retrieves fixtures from baseline's previous results archives. Actual
inputs are also included under final-internal/fixtures; embedded Rust probes
can be rebuilt from final-internal/probes after adjusting dependency paths.

For competitors, use competitor-probes and its pinned npm/Go lock files. Build
the frozen candidate examples, adjust paths in final-competitors/run.py, then
run it. All measured inputs are included.

Checks preserve commands, exit status, stdout and stderr. Fuzz is time bounded,
not line coverage. Requested heap bytes are not RSS or physical allocator
capacity. Binary hashes identify measured executables, not reproducible linking.
'''
entries['MANIFEST.json'] = json.dumps({name: hashlib.sha256(data).hexdigest() for name, data in sorted(entries.items())}, indent=2).encode()
with zipfile.ZipFile(O / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        z.writestr(name, data)
print(json.dumps({'files': len(entries), 'evidence_bytes': (O / 'evidence.zip').stat().st_size}))
