
use serde_json::json;
use palim::{DiffPatcher,JsonPatchOptions};
fn main(){for n in [1,24,100,400] {for tests in [false,true] {
 let a=json!((0..n).map(|i|json!({"id":i,"a_long_property_name":i,"b_long_property_name":i,"c_long_property_name":i})).collect::<Vec<_>>());
 let b=json!((0..n).map(|i|json!({"id":i,"a_long_property_name":i+100000,"b_long_property_name":i+200000,"c_long_property_name":i+300000})).collect::<Vec<_>>());
 let p=DiffPatcher::default().diff_json_patch(&a,&b,&JsonPatchOptions{factorize:true,rationalize:true,tests}).unwrap();
 assert_eq!(palim::apply_json_patch(&a,&p).unwrap(),b);
 println!("{}",json!({"case":n,"guarded":tests,"operations":p.0.len(),"capacity":p.0.capacity(),"operation_size":std::mem::size_of::<palim::PatchOperation>(),"bytes":serde_json::to_vec(&p).unwrap().len()}));
}}}
