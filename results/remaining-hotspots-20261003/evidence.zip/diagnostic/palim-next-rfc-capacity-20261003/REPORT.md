# Retained RFC operation capacity — 2026-10-03

Scope: only src/rfc.rs received an additional minimal fix. It records rationalize's original operation count and calls shrink_to_fit exactly once at the end only when accepted compression reduced the final count. No candidate-loop shrink, global Vec cleanup, threshold or public configuration. Existing performance tests were not changed in this follow-up.

## Evidence before change

Standalone public Patch.0.capacity() probe:

| Input | AFE original root1-op capacity | Optimized before fix root1-op capacity |
|---|---:|---:|
|100 independent objects|4|512|
|400 independent objects|4|2048|

PatchOperation size64B. The optimized IntoIter/filter_map/collect reused the original Vec allocation. Public guarded output is2 operations with capacity4 in both versions, so its retained result alone concealed the oversized intermediate rationalized Patch.

System global allocator instrumentation reproduces root's exact guarded400 peaks: AFE1,936,853 B; optimized before2,022,129 B. Instrumentation counts live requested successful allocation bytes from process startup; each diff scope reports peak minus initial live baseline. Values/input generation, serialization, independent application and driver output are outside scope. Realloc charges/debits only successful size changes. These are requested heap bytes, not RSS or allocator physical capacity. No allocation timing is promoted as an ordinary performance benchmark.

For unguarded400, retained live before fix429,762 B vs AFE298,946 B; difference130,816 B exactly equals (2048-4)*64. Both own the same target Value payload. This isolates the returned operation allocation.

## Actual fix result

|400 objects|AFE|Optimized before shrink|Optimized after shrink|
|---|---:|---:|---:|
|unguarded root operation capacity|4|2048|1|
|unguarded retained extra live B|298,946|429,762|298,754|
|unguarded peak extra live B|1,930,405|1,729,763|1,729,763|
|guarded peak extra live B|1,936,853|2,022,129|1,891,121|
|guarded retained extra live B|593,706|593,706|593,706|

Guard peak decreases131,008 B, exactly (2048-1)*64. This before/after change establishes that retained source operation capacity caused the measured extra peak. The final optimized guard peak is45,732 B below AFE. Peak deltas between AFE and optimized need not equal their returned capacity differences because the versions have different dominant lifetime stages.

## Controls and expected cost

- small-config-edit root1-op capacity4 ->4; guarded2-op capacity4 ->4. There was no operation-count reduction, so no shrink call.
- rotate-2000 root1-op capacity4 ->4; guarded3-op capacity4 ->4. No count reduction, no shrink call.
- default disjoint-2000 root1-op capacity4000 ->1; its output bytes34038 and operation count1 stay unchanged.
- the shrink occurs only once after complete rationalization; it may cause one allocator resize/move of the small final operation array. Input payload ownership and all candidates' serialized-cost/error semantics are unchanged. No isolated CPU multiplier is asserted; root will rebuild final combined benchmarks to quantify small controls.

## Completed verification

- Focused release: lib8 + performance13 + RFC23 =44 tests passed after shrink.
- Rebuilt final candidate public driver:373 pairs x8 RFC configs =2984 patch outputs byte-identical to AFE; forward/inverse application passed for all.
- rustfmt completed on src/rfc.rs. Root owns final full-suite/MSRV/Clippy/CI gates.

## Raw evidence and reproduction

- baseline-capacity.jsonl / candidate-before-capacity.jsonl / candidate-after-capacity.jsonl
- baseline-allocation.jsonl / candidate-before-allocation.jsonl / candidate-after-allocation.jsonl
- candidate-before-control-capacity.jsonl / candidate-after-control-capacity.jsonl
- candidate-before-rfc.rs, candidate-before-capacity-binary, candidate-before-allocation-binary freeze the pre-fix version.
- before-shrink-crate is an isolated source copy with only rfc.rs restored to pre-shrink, used for the control comparison.
- baseline/ depends on AFE detached source; candidate/ depends on current palim-next; source for each driver is retained.
- differential-verification-final.json ties exact equivalence checks to final RFC source SHA256.

```
cargo run --release --offline --bin allocation --manifest-path /tmp/palim-next-rfc-capacity-20261003/candidate/Cargo.toml
cargo run --release --offline --bin controls --manifest-path /tmp/palim-next-rfc-capacity-20261003/candidate/Cargo.toml
```

Final source SHA256:90f80e85af329b8dc063342c95f834dd1f29ebbc701c5cce23a2f5d56fdd06a9. No source work remains for this agent; no commits/push/release.
