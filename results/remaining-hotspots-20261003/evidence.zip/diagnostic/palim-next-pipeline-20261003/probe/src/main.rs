use palim::{DiffPatcher,DiffOptions};
use serde_json::{Value,json};
use std::{hint::black_box,sync::Arc,time::Instant};

#[cfg(feature="alloc-track")]
mod tracked{
use std::{alloc::{GlobalAlloc,Layout,System},sync::atomic::{AtomicBool,AtomicUsize,Ordering}};
pub struct Tracker; pub static ACTIVE:AtomicBool=AtomicBool::new(false); pub static ALLOC:AtomicUsize=AtomicUsize::new(0);pub static BYTES:AtomicUsize=AtomicUsize::new(0);pub static DEALLOC:AtomicUsize=AtomicUsize::new(0);
unsafe impl GlobalAlloc for Tracker{
 unsafe fn alloc(&self,l:Layout)->*mut u8 {if ACTIVE.load(Ordering::Relaxed){ALLOC.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(l.size(),Ordering::Relaxed);} unsafe{System.alloc(l)}}
 unsafe fn dealloc(&self,p:*mut u8,l:Layout){if ACTIVE.load(Ordering::Relaxed){DEALLOC.fetch_add(l.size(),Ordering::Relaxed);}unsafe{System.dealloc(p,l)}}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8{if ACTIVE.load(Ordering::Relaxed){ALLOC.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(n,Ordering::Relaxed);DEALLOC.fetch_add(l.size(),Ordering::Relaxed);}unsafe{System.realloc(p,l,n)}}
}
pub fn count<T>(name:&str,f:impl FnOnce()->T)->Value {ALLOC.store(0,Ordering::Relaxed);BYTES.store(0,Ordering::Relaxed);DEALLOC.store(0,Ordering::Relaxed);ACTIVE.store(true,Ordering::Relaxed);let result=f();ACTIVE.store(false,Ordering::Relaxed);let row=serde_json::json!({"name":name,"alloc_calls":ALLOC.load(Ordering::Relaxed),"allocated_bytes":BYTES.load(Ordering::Relaxed),"deallocated_bytes":DEALLOC.load(Ordering::Relaxed)});drop(result);row}
use serde_json::Value;
}
#[cfg(feature="alloc-track")]
#[global_allocator]static ALLOC:tracked::Tracker=tracked::Tracker;
fn measure<T>(name:&str, n:usize, mut f:impl FnMut()->T)->Value {let mut samples=Vec::new();for _ in 0..7{let t=Instant::now();for _ in 0..n{drop(black_box(f()));}samples.push(t.elapsed().as_secs_f64()*1e6/n as f64);}let mut sorted=samples.clone();sorted.sort_by(f64::total_cmp);json!({"phase":name,"median_us":sorted[3],"samples_us":samples,"iterations":n})}
fn produce_only<T>(name:&str,n:usize,mut f:impl FnMut()->T)->Value {let mut samples=Vec::new();for _ in 0..7 {let mut out=Vec::with_capacity(n);let t=Instant::now();for _ in 0..n{out.push(black_box(f()));}samples.push(t.elapsed().as_secs_f64()*1e6/n as f64);drop(out);}let mut sorted=samples.clone();sorted.sort_by(f64::total_cmp);json!({"phase":name,"median_us":sorted[3],"samples_us":samples,"iterations":n,"output_drop":"excluded"})}
fn drop_only<T>(name:&str,n:usize,mut f:impl FnMut()->T)->Value {let mut samples=Vec::new();for _ in 0..7{let out:Vec<_>=(0..n).map(|_|black_box(f())).collect();let t=Instant::now();drop(out);samples.push(t.elapsed().as_secs_f64()*1e6/n as f64);}let mut sorted=samples.clone();sorted.sort_by(f64::total_cmp);json!({"phase":name,"median_us":sorted[3],"samples_us":samples,"iterations":n,"construction":"excluded"})}
fn main(){
 for value in [0.1,398043487186.00244,1.0e40,f64::MAX,f64::MIN_POSITIVE,f64::from_bits(1)] {
 let number=serde_json::Number::from_f64(value).unwrap();let source=Value::Number(number);let target=Value::Bool(false);let macro_value=json!([&source,&target]);let clone_value=Value::Array(vec![source.clone(),target.clone()]);
 let delta=palim::diff(&source,&target).unwrap().unwrap();let forward=palim::patch(&source,&delta);let back=palim::unpatch(&target,&delta);
 eprintln!("representation:{}",json!({"number":source.as_number().unwrap().as_str(),"macro_equal":macro_value==clone_value,"macro":macro_value,"clone":clone_value,"baseline_forward":forward.map_err(|e|e.to_string()).is_ok(),"baseline_back_equal":back.ok().is_some_and(|v|v==source)}));
 }
 let fixture:Value=serde_json::from_slice(&std::fs::read(std::env::args().nth(1).unwrap()).unwrap()).unwrap();let a=&fixture["left"];let b=&fixture["right"];
 let raw_a=serde_json::to_vec(a).unwrap();let raw_b=serde_json::to_vec(b).unwrap();let str_a=std::str::from_utf8(&raw_a).unwrap();let str_b=std::str::from_utf8(&raw_b).unwrap();
 let dp=DiffPatcher::new(DiffOptions{object_hash:Some(Arc::new(|v,_|v.get("id").map(Value::to_string))),..Default::default()});let delta=dp.diff(a,b).unwrap();let bytes=serde_json::to_vec(&delta).unwrap();
 assert_eq!(dp.patch(a,delta.as_ref().unwrap()).unwrap(),*b);assert_eq!(dp.unpatch(b,delta.as_ref().unwrap()).unwrap(),*a);assert_eq!(bytes,br#"{"settings":{"key5":[5,99]}}"#);
 let mut rows=Vec::new();
 if cfg!(feature="alloc-track") {
 #[cfg(feature="alloc-track")] {
 rows.push(tracked::count("parse_pair_retained",|| (serde_json::from_slice::<Value>(&raw_a).unwrap(),serde_json::from_slice::<Value>(&raw_b).unwrap())));
 rows.push(tracked::count("clone_pair_retained",|| (a.clone(),b.clone())));
 rows.push(tracked::count("loaded_native_delta_retained",|| dp.diff(a,b).unwrap()));
 rows.push(tracked::count("serialize_delta_retained",||serde_json::to_vec(&delta).unwrap()));
 for text in ["1","1.0","-1","0","1e10000","18446744073709551617","true",r#""number""#] {rows.push(tracked::count(&format!("parse_scalar:{text}"),||serde_json::from_str::<Value>(text).unwrap()));}
 }
 } else {
 let n=2048;
 for _ in 0..100{drop(dp.diff(a,b).unwrap());}
 rows.push(measure("pipeline",n,||{let a:Value=serde_json::from_slice(&raw_a).unwrap();let b:Value=serde_json::from_slice(&raw_b).unwrap();serde_json::to_vec(&dp.diff(&a,&b).unwrap()).unwrap()}));
 rows.push(measure("parse_pair_and_drop",n,||(serde_json::from_slice::<Value>(&raw_a).unwrap(),serde_json::from_slice::<Value>(&raw_b).unwrap())));
 rows.push(produce_only("parse_pair_only",n,||(serde_json::from_slice::<Value>(&raw_a).unwrap(),serde_json::from_slice::<Value>(&raw_b).unwrap())));
 rows.push(drop_only("drop_input_pair_only",n,||(a.clone(),b.clone())));
 rows.push(measure("from_str_pair_and_drop",n,||(serde_json::from_str::<Value>(str_a).unwrap(),serde_json::from_str::<Value>(str_b).unwrap())));
 rows.push(measure("clone_pair_and_drop",n,||(a.clone(),b.clone())));
 rows.push(produce_only("clone_pair_only",n,||(a.clone(),b.clone())));
 rows.push(measure("loaded_native_diff_and_drop",n,|| dp.diff(a,b).unwrap()));
 rows.push(produce_only("loaded_native_diff_only",n,|| dp.diff(a,b).unwrap()));
 rows.push(drop_only("drop_native_delta_only",n,||delta.clone()));
 rows.push(measure("serialize_delta_and_drop",n,||serde_json::to_vec(&delta).unwrap()));
 let mut output=Vec::with_capacity(128);
 rows.push(measure("serialize_delta_reused_vec",n,||{output.clear();serde_json::to_writer(&mut output,&delta).unwrap();black_box(output.len())}));
 rows.push(measure("loaded_native_diff_serialize_drop",n,||serde_json::to_vec(&dp.diff(a,b).unwrap()).unwrap()));
 rows.push(measure("serialize_input_pair",n,||(serde_json::to_vec(a).unwrap(),serde_json::to_vec(b).unwrap())));
 }
 println!("{}",json!({"input_bytes":raw_a.len()+raw_b.len(),"output_bytes":bytes.len(),"raw_a":str_a,"raw_b":str_b,"rows":rows,"numeric_features":["arbitrary_precision","float_roundtrip"],"allocation_tracking":cfg!(feature="alloc-track")}));
}
