# 小配置 native pipeline 的真实成本

2026-10-03，冻结 Palim afe1868，隔离诊断阶段使用只读冻结源码；后续获得授权，仅改动src/diff.rs的原子replacement与tests/core.rs。使用前轮相同 small-config-edit：两份各含30个整数的 settings 对象，key5 从5变99。两份输入649B，native delta28B；每次严格正向/撤销在计时外确认，delta字节固定。具体字节见 timing.json。

## 测量边界

与现有 examples/fixture_runner.rs native pipeline 相同：serde_json::from_slice 两份 → dp.diff → serde_json::to_vec → 释放结果与两个输入。ID callback与现有runner一致，默认text/depth等选项不变。依赖使用冻结Cargo.lock，serde_json1.0.151 开启 arbitrary_precision 和 float_roundtrip。

无allocator插桩的timing binary：3个独立进程，每阶段7批，每批2048次。分阶段构造/释放通过批量保留结果移出计时，可能改变heap/cache状态；这些是诊断，不能把各阶段严格相加，亦非正式跨语言排名。独立 feature=alloc-track binary 只计调用的累计分配次数/字节，不混入timing。

| 阶段 | µs，进程中位数的中位数 |
|---|---:|
| 完整 native pipeline | 10.3324 |
| parse两份并立即释放 | 7.4257 |
| parse两份，释放排除 | 6.3399 |
| 单独释放两份输入 | 1.6367 |
| 已解析 diff，含delta释放 | 2.6495 |
| 已解析 diff，delta释放排除 | 2.5807 |
| delta序列化并释放 | 0.0459 |
| 复用Vec的delta序列化 | 0.0307 |
| 已解析 diff+serialize+释放 | 2.6960 |
| clone输入pair+释放（不是diff必有阶段） | 2.8770 |
| clone输入pair，释放排除 | 1.7184 |
| from_str两份并释放 | 7.2868 |

**约72%的完整流程时间处于解析和输入释放边界。** loaded diff+输出仅约2.7µs；因此不能将约10µs全归因于Palim算法。from_str与from_slice差距只有约2%，不能在共享机器据此宣称可靠parser提速。delta序列化约0.05µs，复用输出buffer预算小于整体1%。

## 累计分配，不是峰值内存

| 操作，输出保留 | 分配/重分配调用 | 累计申请B | 调用内已释放B |
|---|---:|---:|---:|
| parse输入pair | 194 | 9,133 | 960 |
| clone已解析pair | 134 | 8,173 | 0 |
| loaded diff | 24 | 1,517 | 174 |
| serialize delta | 1 | 128 | 0 |

diff没有复制整份输入，输入clone只作为成本对照。两个Value输入60个整数，parse比clone多60次分配与960B瞬时分配，恰好对应每整数16B scanner String。小对象还持有全部owned key、数字String与BTreeMap节点。

## serde_json官方实现证据

- [number.rs](https://github.com/serde-rs/json/blob/v1.0.151/src/number.rs)：开启arbitrary_precision时Number内部是String；这是现有精确数字表示，不应关feature换取分数。
- [de.rs](https://github.com/serde-rs/json/blob/v1.0.151/src/de.rs)：parse_any_number先扫描到capacity16的String；小整数可转u64/i64，再由Number构造owned字符串。普通整数scalar实际2次分配17B，16B扫描buffer在调用内释放。浮点与大整数也保留准确表示，详细分配在allocations.json。
- [map.rs](https://github.com/serde-rs/json/blob/v1.0.151/src/map.rs)：默认对象为BTreeMap<String,Value>。改变preserve_order会改变顺序与构造/序列化合同，不属于本轮安全改动。
- [ser.rs](https://github.com/serde-rs/json/blob/v1.0.151/src/ser.rs)：to_vec先分配128B，故28Bdelta输出申请128B；caller已有to_writer可重用buffer，不需要新public API。

serde_json解析发生在调用者，Palim公开API接收&Value。保持Value与数字feature时，Palim内部无法消除已在调用前发生的解析/owned输入成本。现有API允许caller持有已解析配置直接借用；更新流程只解析实际新输入，避免每次重新序列化再解析旧配置。这个收益属于集成边界优化。

## 最小内部改动，已实现并验证

src/diff.rs 的原子替换分支 `_ => json!([left,right])` 把已经是Value的输入再次过serde Serialize → Value Serializer。官方 [macros.rs](https://github.com/serde-rs/json/blob/v1.0.151/src/macros.rs) 插值展开为to_value；[value/ser.rs](https://github.com/serde-rs/json/blob/v1.0.151/src/value/ser.rs) AP NumberValueEmitter再次做字符串解析。可以隔离比较 `Value::Array(vec![left.clone(),right.clone()])`，在正常公开/解析Number的已验证表示上避免无用重解析，也保持真实old/new表示。

仅建议先比较这个最小replacement分支；对owned projected值可直接move的其他分支另需等价验证。不得把直接clone说成parser整体变快。serde_json隐藏from_string_unchecked注明not public API，当前to_value会重验证其文本；不以这个隐藏测试入口作为支持合同，不添加新验证层。本轮已仅修改 palim-next/src/diff.rs 的原子replacement这一行，直接clone输入Value构造Array；其余add/delete/projection宏未修改。新 tests/core.rs regression包含20个parsed/公开from_f64/mixed payload，证明Value与旧宏及wire bytes等价；正向、reverse、unpatch、标准导出及wire重读通过。cargo test --release --locked --test core --test numbers 共20项测试通过；targeted rustfmt --check、git diff --check通过。正式性能收益尚待主agent统一测量，不把消除重新Serialize当成已证倍率。

## 明确不做

不关闭arbitrary_precision/float_roundtrip，不采用不同numeric contract的parser，不增加SIMD/Tape/新依赖/缓存/byte API，不换JSON表示。现阶段没有理由重写JSON parser或把caller解析边界包装成另一个库抽象。

## 复现与工件

- pipeline-source.rs：原始诊断及分配harness，与environment.json源hash对应；probe/src/main.rs后来加入Number构造探查。
- timing.json / summary.json：无插桩3进程原始阶段数据。
- allocations.json：独立allocator二进制分配结果。
- environment.json：冻结源码、锁文件、输入、二进制与serde源码SHA-256。
- pipeline-timing：保留的无插桩release binary。

构建默认probe后保存binary；再以features=alloc-track构建，分别运行fixture.json。诊断期间曾因copyfile未保留执行权限失败，chmod后成功，不曾用失败结果作测量。正式测量由主agent另行完成，避免与文本agent计时竞争。


任务归属：owned-checks.json保存src/diff.rs与tests/core.rs最终SHA-256和实际检查；Patch Guard observed还看到其他agent在snapshot之后写入rfc/performance_regressions，未修改这些文件，也不将observed当正确性验收。pipeline-source.rs保存正式诊断二进制对应的原始harness，environment.json对应hash已核实；representation_probe.rs为后续Number构造探查版本，不能混用它的源码hash归因原始timing。


## text/rfc 独立只读审查

当前源码hash记录在 independent-review.json，未找到blocker。

RFC的独立边界在任意上级array发生直接Add/Remove/Move/Copy或Move source移除时拒绝快捷验证；Copy/Move跨边界与读取包含该边界的ancestor时拒绝；写入ancestor拒绝。root/单op保留真正candidate replay。tests=true的costing已经完整执行候选，只有其final shadow与right数学相等才接受。每次接受后的baseline_verified对应当前已证明有效patch；正常公共生成在rationalize之后才插入Test，不存在任意外部Test被优化掉的public入口。深度推导依赖公共输入right已验证及祖先路径不漂移，符合实际调用边界。

Text借用UTF-8行token与旧char slice token有同一相等关系；按原窗口顺序intern给出同一token编号。tuple boundary字符索引对应原char向量，byte索引用于borrow原str，两端common-prefix/suffix先对齐char boundaries，之后char refinement得到同一changed文本。LF边界byte+1正确，CRLF/NUL/空行/astral/combining mark不改变分组含义。没有具体失败假设，未增加投机probe或额外benchmark。

隐藏unchecked Number边界的事实是：serde_json Number::from_string_unchecked注明not public API且供内部测试；ValueSerializer旧路径会parse文本，直接Value::clone不会再parse。自行通过该隐藏入口制造无效JSON数值不在已验证有效JSON合同内。公开parsed/Number::from_f64表示已由新regression实测等价；Palim接受固定Value，并不接收任意自定义Serialize实现，其调用者的Serialize错误仍发生在Value构造边界。
