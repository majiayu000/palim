# RFC rationalization optimization — 2026-10-03

## Scope and evidence

Baseline: `afe18686171131963f1ceb5237014f1590d693ed`. Only owned production files src/rfc.rs and tests/performance_regressions.rs changed in palim-next. No public options, backends, publishing or commits. Final root agent should run serialized production benchmarks; diagnostic times here are single calls, not stable rankings.

## Maintained prior art and decision

Read [wI2L/jsondiff's maintained rationalize implementation](https://github.com/wI2L/jsondiff/blob/master/differ.go): it compares a recursively generated local operation slice against one parent replacement using serialized length. It provides precedent for using local independence, but its preparation/factorization and array matching boundaries differ, so copying its no-validation replacement verbatim is rejected. [Rust json-patch implementation](https://github.com/idubrov/json-patch/blob/main/src/lib.rs) iterates borrowed operations in patch_unsafe; Palim still uses its own established source-depth and per-step helper, preserving mathematical tests, depth/error ordering and the default unlimited copy-byte budget.

Decision: adapt borrowed candidate iteration and transfer retained owned operations only after acceptance. Build a narrowly proven independence check inside the current optimizer. Reject blanket parent membership proofs, reordered parent heuristics, a new DOM/backend, global mutable replay caches, and new public configuration.

## Profile before mutation

100 unguarded: total12.862 ms; candidate cloning1.469 ms; final validation8.997 ms.
400 unguarded: total177.679 ms; candidate cloning19.832 ms; final validation136.166 ms (~77%).
400 guarded: total346.706 ms; cloning19.678 ms; exact guard-cost replay168.916 ms; repeated final validation134.819 ms.
400 accepted-element replacements plus root =401 accepted candidates. Raw profile: diagnostic-baseline.jsonl and diagnostic-baseline-stderr.txt, with the diagnostic-only source under profile/.

## Changes and proof

1. Candidate operations are borrowed through a cloneable iterator. Full validation still runs existing delta::check_depth(left,128), followed by apply_json_patch_step with original candidate operation indices. This matches default max_depth128/max_copy_bytesNone. On acceptance, consume the original Vec, transfer unselected owned operations and insert one replacement. No whole patch payload clone is necessary.
2. Exact guarded costing already executes the entire candidate on scratch, including the unchanged prefix and every changed suffix. Return this completed shadow and compare it to the target, eliminating a second identical whole-document replay. All guard values/UTF-8/path/commas and operation counts are still computed as before. Guard source Values are prechecked by the public diff boundary; intermediate states use the same depth-checking step helper.
3. For unguarded candidates, first prove the current original patch reaches right (lazily, at most once until success; any full validated accepted candidate establishes validity). A parent replacement preserves the result without replay ONLY when:
   - no outside destination is a strict ancestor of the candidate boundary;
   - every Move/Copy source stays on the same side as its destination and no external source is a strict ancestor of the boundary;
   - for every array container on the boundary's path, no operation structurally writes directly to that array (Add/Remove/Move/Copy), and no Move removes a direct element from it.

Under these restrictions, the boundary remains at the same pointer throughout the sequence; operations outside it neither read nor modify it or its enclosing containers; operations inside it cannot change external state. Replacing all interior edits with the known target subtree at the first interior edit therefore commutes with the external sequence and produces the same final mathematical JSON. Final target subtree depth is bounded at the existing trusted public input boundary. Outside original intermediate states remain unchanged; deleted interior operations cannot introduce a new failing state.

Root and one-operation candidates always use original-style true candidate validation, preventing default root replacement from needlessly replaying thousands of original operations. Cross-copy reads, array shifts and any unproven case retain complete real validation. No heuristic work budget hides costs.

Resource cost: one path-length-bounded Vec of borrowed array prefix strings per eligible candidate, operation scan, and at most one original-document clone/replay for initial proof. No global or persistent state. Candidate guards still replay the full document per accepted candidate, so guarded rationalization remains quadratic in adversarial independent-parent inputs.

## Verification

- Focused release: lib8 + performance13 + RFC23 =44 tests passed; rustfmt and scoped git diff --check completed.
- 373 saved pairs ×8 option combinations =2984: exact patch bytes match afe1868; forward and inverse application verified for each. differential-verification.json includes hashes and candidate RFC source SHA256.
- New internal adversarial tests explicitly preserve interleaved Copy reads of the replaced subtree AND its root ancestor: replacing first/last internal edits must not expose later values to the intermediate copy.
- New internal array tests preserve interleaved Remove/Move index shifts: the same /1 pointer refers to different original items before and after the structural operation.
- Existing escaped parent, cross-move, guard-prefix/copy, mathematical-number, real-serializer-error and invalid-operation tests retained and passed.
- New public regression:24 independently compressible array objects retain the exact root Replace and guarded Test+Replace, independent application/inverse and baseline drift rejection.

## Diagnostic after

Same loaded-input generation boundary, no parsing/serialization/validation timed:
100 unguarded1.669 ms; guarded13.323 ms.
400 unguarded7.976 ms; guarded190.074 ms.
These are single exploratory calls under shared-machine load. Inputs/output byte sizes match. Root agent must measure final combined source serially before claiming multipliers. Raw: diagnostic-candidate.jsonl.

## Files and reproduction

- rfc-performance.patch: current owned source/tests diff.
- baseline-driver/ and candidate-driver/: standalone public API 373×8 differential programs with separate target directories.
- profile/: frozen baseline source plus diagnostic timers only; never ship its timers.
- probe/: the 100/400 loaded-input diagnostic driver, currently depends on palim-next.

```
cargo run --release --offline --manifest-path /tmp/palim-next-rfc-20261003/baseline-driver/Cargo.toml > /tmp/base-rfc.jsonl
cargo run --release --offline --manifest-path /tmp/palim-next-rfc-20261003/candidate-driver/Cargo.toml > /tmp/new-rfc.jsonl
cmp /tmp/base-rfc.jsonl /tmp/new-rfc.jsonl
```

No full final suite, MSRV, Clippy, cross-platform CI or formal benchmark matrix is claimed by this agent; root owns final gates.
