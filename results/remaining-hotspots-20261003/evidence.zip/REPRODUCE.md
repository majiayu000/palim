# Frozen experiment artifacts

Final tables use final-internal and final-competitors only. Earlier snapshots
are kept under stages to explain measured regressions and rejected variants.

For internal measurements, unpack the two final-internal/sources trees and run
remaining-hotspots.py with baseline, candidate and a new output directory. The
runner retrieves fixtures from baseline's previous results archives. Actual
inputs are also included under final-internal/fixtures; embedded Rust probes
can be rebuilt from final-internal/probes after adjusting dependency paths.

For competitors, use competitor-probes and its pinned npm/Go lock files. Build
the frozen candidate examples, adjust paths in final-competitors/run.py, then
run it. All measured inputs are included.

Checks preserve commands, exit status, stdout and stderr. Fuzz is time bounded,
not line coverage. Requested heap bytes are not RSS or physical allocator
capacity. Binary hashes identify measured executables, not reproducible linking.
