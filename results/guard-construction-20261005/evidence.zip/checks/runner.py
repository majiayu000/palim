from pathlib import Path
import subprocess,json,sys,re
root=Path('/Users/apple/Desktop/code/AI/tool/secrets/palim')
commands=[
 ['cargo','fmt','--check'],['git','diff','--check'],
 ['cargo','test','--locked'],['cargo','test','--release','--locked'],
 ['cargo','clippy','--all-targets','--locked','--','-D','warnings'],
 ['cargo','+1.85.0','check','--lib','--locked'],
 ['cargo','build','--release','--examples','--locked'],
 ['node','tools/interop.mjs'],
]
records=[]
for command in commands:
 r=subprocess.run(command,cwd=root,capture_output=True,text=True)
 row=dict(command=command,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr)
 records.append(row)
 Path('/tmp/palim-guard-construction-checks-20261005.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(dict(command=command,exit_code=r.returncode,passed_tests=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',r.stdout))))),flush=True)
 if r.returncode:
  print((r.stdout+r.stderr)[-5000:],flush=True);sys.exit(r.returncode)
