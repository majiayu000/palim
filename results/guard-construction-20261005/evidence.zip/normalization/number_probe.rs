fn main() {
    for raw in ["-0", "1E+0003", "1.00e00", "1234567890123456789012345678901234567890"] {
        let value = serde_json::Value::Number(serde_json::Number::from_string_unchecked(raw.into()));
        println!("{} -> {}",serde_json::to_string(&value).unwrap(),serde_json::to_string(&serde_json::to_value(&value).unwrap()).unwrap());
    }
}
