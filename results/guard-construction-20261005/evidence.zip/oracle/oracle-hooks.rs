#[cfg(test)]
mod index_review_oracle {
    use super::*;
    use std::sync::Arc;

    fn wire(patch: &Patch) -> String { serde_json::to_string(patch).unwrap() }
    fn error(phase: &str, error: Error) -> Value {
        json!({"phase":phase,"path":error.path,"message":error.message})
    }
    fn original(case: &Value) -> Patch {
        Patch(case["original"].as_array().unwrap().iter().cloned().map(|v|decode(v).unwrap()).collect())
    }
    #[test]
    fn freeze() {
        let output = std::path::PathBuf::from(std::env::var("PALIM_INDEX_ORACLE_OUTPUT_DIR").unwrap());
        std::fs::create_dir_all(&output).unwrap();
        let private: Vec<Value> = serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../frozen-private-cases.json"))).unwrap();
        let mut records = Vec::new();
        for case in private {
            let left = &case["left"];
            let original = original(&case);
            let right = case.get("right").cloned().unwrap_or_else(|| apply_json_patch(left, &original).unwrap());
            for tests in [false, true] {
                let mut record = json!({"id":case["id"],"tests":tests});
                let optimized = match rationalize(left, &right, original.clone(), tests) {
                    Ok(v) => v,
                    Err(e) => {
                        assert!(tests && case["expect_guarded_error"] == true, "unexpected rationalize error: {:?}", e);
                        record["error"] = error("rationalize", e);
                        records.push(record);
                        continue;
                    }
                };
                assert!(!(tests && case["expect_guarded_error"] == true), "expected original guard error");
                record["optimized_wire"] = Value::String(wire(&optimized));
                let final_patch = if tests {guard(left.clone(), &optimized).unwrap()} else {optimized};
                record["patch_wire"] = Value::String(wire(&final_patch));
                let actual = apply_json_patch(left, &final_patch).unwrap();
                let matches = json_equal(&actual, &right);
                assert!(matches || case["allow_incomplete"] == true, "private {} does not reach target", case["id"]);
                record["forward_matches_target"] = Value::Bool(matches);
                let inverse = crate::invert_json_patch(left, &final_patch).unwrap();
                assert!(json_equal(&apply_json_patch(&actual, &inverse).unwrap(), left), "private inverse {}", case["id"]);
                record["inverse_wire"] = Value::String(wire(&inverse));
                records.push(record);
            }
        }
        std::fs::write(output.join("private-output.json"), serde_json::to_vec(&records).unwrap()).unwrap();
        let public: Vec<Value> = serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../frozen-public-cases.json"))).unwrap();
        let dp = crate::DiffPatcher::new(crate::DiffOptions {
            object_hash: Some(Arc::new(|v, _| v.get("id").map(Value::to_string))),
            ..Default::default()
        });
        let mut records = Vec::new();
        for (index, case) in public.iter().enumerate() {
            for factorize in [false, true] { for rationalize in [false, true] { for tests in [false, true] {
                let patch = dp.diff_json_patch(&case["left"], &case["right"], &JsonPatchOptions {factorize, rationalize, tests}).unwrap();
                let actual = apply_json_patch(&case["left"], &patch).unwrap();
                assert!(json_equal(&actual, &case["right"]), "public forward {} flags {:?}", index, (factorize,rationalize,tests));
                let inverse = crate::invert_json_patch(&case["left"], &patch).unwrap();
                assert!(json_equal(&apply_json_patch(&actual, &inverse).unwrap(), &case["left"]), "public inverse {}", index);
                records.push(json!({"index":index,"name":case["name"],"factorize":factorize,"rationalize":rationalize,"tests":tests,
                    "patch_wire":wire(&patch),"inverse_wire":wire(&inverse)}));
            } } }
        }
        std::fs::write(output.join("public-output.json"), serde_json::to_vec(&records).unwrap()).unwrap();
        println!("oracle complete: {} public records; {} private cases x2", records.len(), 17);
    }
}

#[cfg(test)]
mod mixed_review_oracle {
    use super::*;
    #[test]
    fn freeze() {
        let cases: Vec<Value> = serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../mixed-factor-cases.json"))).unwrap();
        let mut records = Vec::new();
        for case in cases {
            let left = &case["left"];
            let original = Patch(case["original"].as_array().unwrap().iter().cloned().map(|v| decode(v).unwrap()).collect());
            let right = case.get("right").cloned().unwrap_or_else(|| apply_json_patch(left, &original).unwrap());
            for tests in [false,true] {
                let component = case["component"].as_str().unwrap();
                let mut record = json!({"id":case["id"],"component":component,"tests":tests});
                let optimized = match if component == "factorize" {
                    factorize(left,&right,original.clone())
                } else {
                    rationalize(left,&right,original.clone(),tests)
                } {
                    Ok(v) => v,
                    Err(error) => {
                        assert!(case["expect_component_error"]==true || tests && case["expect_guarded_error"]==true,"unexpected error {}: {:?}",case["id"],error);
                        record["error"]=json!({"phase":component,"path":error.path,"message":error.message});
                        records.push(record);continue;
                    }
                };
                assert!(case["expect_component_error"]!=true && !(tests && case["expect_guarded_error"]==true),"expected component error {}",case["id"]);
                record["optimized_wire"]=Value::String(serde_json::to_string(&optimized).unwrap());
                let patch=if tests {guard(left.clone(),&optimized).unwrap()} else {optimized};
                record["patch_wire"]=Value::String(serde_json::to_string(&patch).unwrap());
                let actual=apply_json_patch(left,&patch).unwrap();
                assert!(json_equal(&actual,&right),"forward {}",case["id"]);
                let inverse=crate::invert_json_patch(left,&patch).unwrap();
                assert!(json_equal(&apply_json_patch(&actual,&inverse).unwrap(),left),"inverse {}",case["id"]);
                record["inverse_wire"]=Value::String(serde_json::to_string(&inverse).unwrap());
                records.push(record);
            }
        }
        std::fs::write(std::env::var("PALIM_MIXED_ORACLE_OUTPUT").unwrap(),serde_json::to_vec(&records).unwrap()).unwrap();
        println!("mixed/factor oracle complete: {} records",records.len());
    }
}
#[cfg(test)]
mod snapshot_cost_oracle {
    use super::*;
    #[test]
    fn freeze() {
        let cases: Vec<Value> = serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../snapshot-cases.json"))).unwrap();
        let mut records=Vec::new();
        for case in cases {
            let left=&case["left"];
            let original=Patch(case["original"].as_array().unwrap().iter().cloned().map(|v|decode(v).unwrap()).collect());
            let actual=guard(left.clone(),&original);
            let calculated=guarded_operation_bytes(left,original.0.iter(),original.0.len(),&[]);
            let mut record=json!({"id":case["id"]});
            match (actual,calculated) {
                (Err(a),Err(b))=>{assert_eq!(a,b);assert_eq!(case["error"],true);record["error"]=json!({"path":a.path,"message":a.message});},
                (Ok(actual),Ok((size,costs,shadow)))=>{
                    assert_ne!(case["error"],true);
                    assert_eq!(size,bytes(&actual).unwrap());
                    let mut independent=left.clone();json_patch::patch(&mut independent,&actual).unwrap();assert_eq!(independent,shadow);
                    let mut prefixes=Vec::new();
                    for end in 0..=original.0.len() {
                        let prefix=guard(left.clone(),&Patch(original.0[..end].to_vec())).unwrap();
                        assert_eq!(costs[end].bytes,bytes(&prefix).unwrap());
                        assert_eq!(costs[end].operations,prefix.0.len());
                        assert_eq!(guarded_bytes(left,&original,true,&costs[..=end]).unwrap().0,size);
                        prefixes.push(json!({"bytes":costs[end].bytes,"operations":costs[end].operations}));
                    }
                    record["prefixes"]=json!(prefixes);
                    record["patch_wire"]=json!(serde_json::to_string(&actual).unwrap());
                    let inverse=crate::invert_json_patch(left,&actual).unwrap();
                    json_patch::patch(&mut independent,&inverse).unwrap();assert_eq!(independent,*left);
                    record["inverse_wire"]=json!(serde_json::to_string(&inverse).unwrap());
                },
                _=>panic!("error contract mismatch {}",case["id"]),
            }
            records.push(record);
        }
        std::fs::write(std::env::var("PALIM_SNAPSHOT_ORACLE_OUTPUT").unwrap(),serde_json::to_vec(&records).unwrap()).unwrap();
        println!("Snapshot oracle: {} cases",records.len());
    }
}

#[cfg(test)]
mod guard_construction_oracle {
    use super::*;
    #[test]
    fn freeze() {
        let mut records=Vec::new();
        for raw in ["-0","1E+0003","1.00e00","1.0","1e9999","1234567890123456789012345678901234567890"] {
            let mut fields=serde_json::Map::new();
            fields.insert("a/~🦀".into(),Value::Number(serde_json::Number::from_string_unchecked(raw.into())));
            fields.insert("keep".into(),json!(["Unicode\n🤖",null,true]));
            let left=Value::Object(fields);
            let normalized:Value=serde_json::from_str(raw).unwrap();
            for operation in [
                json!({"op":"remove","path":"/a~1~0🦀"}),
                json!({"op":"replace","path":"/a~1~0🦀","value":7}),
                json!({"op":"add","path":"/a~1~0🦀","value":8}),
                json!({"op":"copy","from":"/a~1~0🦀","path":"/destination"}),
                json!({"op":"move","from":"/a~1~0🦀","path":"/destination"}),
                json!({"op":"test","path":"/a~1~0🦀","value":normalized}),
            ] {
                let name=operation["op"].clone();
                let original=Patch(vec![decode(operation).unwrap()]);
                let expected=apply_json_patch(&left,&original).unwrap();
                let actual=guard(left.clone(),&original).unwrap();
                let applied=apply_json_patch(&left,&actual).unwrap();
                assert_eq!(applied,expected);
                let inverse=crate::invert_json_patch_guarded(&left,&original).unwrap();
                records.push(json!({"raw":raw,"op":name,
                    "guard_wire":serde_json::to_string(&actual).unwrap(),
                    "inverse_guard_wire":serde_json::to_string(&inverse).unwrap()}));
            }
        }
        std::fs::write(std::env::var("PALIM_GUARD_CONSTRUCTION_OUTPUT").unwrap(),serde_json::to_vec(&records).unwrap()).unwrap();
    }
}
