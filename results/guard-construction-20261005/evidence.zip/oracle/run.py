from pathlib import Path
import subprocess,json,os,hashlib,sys
root=Path(__file__).parent
records=[]
for label in ['baseline','candidate']:
 out=root/(label+'-output');out.mkdir(exist_ok=True)
 env=os.environ.copy();env['CARGO_TARGET_DIR']=str(root/('target-'+label));env['PALIM_INDEX_ORACLE_OUTPUT_DIR']=str(out);env['PALIM_MIXED_ORACLE_OUTPUT']=str(out/'targeted-output.json');env['PALIM_SNAPSHOT_ORACLE_OUTPUT']=str(out/'snapshot-output.json');env['PALIM_GUARD_CONSTRUCTION_OUTPUT']=str(out/'construction-output.json')
 for name in ['rfc::index_review_oracle::freeze','rfc::mixed_review_oracle::freeze','rfc::snapshot_cost_oracle::freeze','rfc::guard_construction_oracle::freeze','rfc::guard_cost_tests::guard_payloads_keep_existing_number_normalization_and_escaped_paths','rfc::guard_cost_tests::guard_construction_keeps_missing_sources_and_application_error_order']:
  cmd=['cargo','test','--locked','--offline','--lib',name,'--','--exact','--nocapture']
  p=subprocess.run(cmd,cwd=root/label,env=env,capture_output=True,text=True)
  records.append(dict(label=label,command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))
  (root/'checks.json').write_text(json.dumps(records,indent=2));print(label,name,p.returncode,flush=True)
  if p.returncode:print((p.stdout+p.stderr)[-5000:]);sys.exit(p.returncode)
comparison={}
for filename in ['public-output.json','private-output.json','targeted-output.json','snapshot-output.json','construction-output.json']:
 a=(root/'baseline-output'/filename).read_bytes();b=(root/'candidate-output'/filename).read_bytes()
 comparison[filename]=dict(byte_identical=a==b,records=len(json.loads(a)),sha256=hashlib.sha256(a).hexdigest())
(root/'comparison.json').write_text(json.dumps(comparison,indent=2));print(json.dumps(comparison),flush=True)
assert all(x['byte_identical'] for x in comparison.values())
