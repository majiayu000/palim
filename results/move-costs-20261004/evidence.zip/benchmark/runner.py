#!/usr/bin/env python3
"""Freeze two source trees; measure public APIs and allocator requests separately."""
import hashlib
import io
import json
from pathlib import Path
import platform
import shutil
import statistics
import subprocess
import sys
import time
import zipfile

baseline, candidate, output = [Path(arg).resolve() for arg in sys.argv[1:4]]
output.mkdir(parents=True, exist_ok=False)

RUST = '\nuse palim::{Delta,DiffOptions,DiffPatcher,JsonPatchOptions,Patch};\nuse serde_json::{Value,json};\nuse std::{error::Error,fs,hint::black_box,sync::Arc,time::Instant};\ntype Result<T> = std::result::Result<T,Box<dyn Error>>;\nenum Output { Native(Option<Delta>), Standard(Patch) }\nfn generate(dp:&DiffPatcher,a:&Value,b:&Value,mode:&str)->Result<Output> {\n    Ok(if mode=="native" || mode=="pipeline-native" || mode=="retained-old-pipeline" { Output::Native(dp.diff(a,b)?) } else {\n        Output::Standard(dp.diff_json_patch(a,b,&JsonPatchOptions {\n            factorize:true,rationalize:!mode.starts_with("factorize"),tests:mode.ends_with("guarded")\n        })?)\n    })\n}\nfn main()->Result<()> {\n    let args:Vec<_>=std::env::args().collect();\n    let fixture:Value=serde_json::from_slice(&fs::read(&args[1])?)?;\n    let mode=&args[2];\n    let (a,b)=(&fixture["left"],&fixture["right"]);\n    let dp=DiffPatcher::new(DiffOptions {\n        object_hash:Some(Arc::new(|v,_|v.get("id").map(Value::to_string))),\n        ..Default::default()\n    });\n    let initial=generate(&dp,a,b,mode)?;\n    let (wire,operations)=match &initial {\n        Output::Native(Some(delta))=>{\n            assert_eq!(palim::patch(a,delta)?,*b);\n            assert_eq!(palim::patch(b,&palim::reverse(delta)?)?,*a);\n            (serde_json::to_vec(delta)?,None)\n        },\n        Output::Native(None)=>{assert_eq!(a,b);(b"null".to_vec(),None)},\n        Output::Standard(patch)=>{\n            let mut result=a.clone();json_patch::patch(&mut result,patch)?;assert_eq!(result,*b);\n            let inverse=palim::invert_json_patch(a,patch)?;\n            json_patch::patch(&mut result,&inverse)?;assert_eq!(result,*a);\n            (serde_json::to_vec(patch)?,Some(patch.0.len()))\n        },\n    };\n\n    if mode=="pipeline-native" || mode=="retained-old-pipeline" {\n        let left_bytes=fixture["left_raw"].as_str().unwrap().as_bytes();\n        let right_bytes=fixture["right_raw"].as_str().unwrap().as_bytes();\n        assert_eq!(serde_json::from_slice::<Value>(left_bytes)?,*a);\n        assert_eq!(serde_json::from_slice::<Value>(right_bytes)?,*b);\n        let work=||->Result<Vec<u8>> {\n            let parsed_left:Option<Value>=if mode=="pipeline-native" {\n                Some(serde_json::from_slice(left_bytes)?)\n            } else {None};\n            let left=parsed_left.as_ref().unwrap_or(a);\n            let right:Value=serde_json::from_slice(right_bytes)?;\n            let delta=dp.diff(left,&right)?;\n            Ok(serde_json::to_vec(&delta)?)\n        };\n        assert_eq!(work()?,wire);\n        drop(initial);\n        for _ in 0..3 {black_box(work()?);}\n        let mut samples=Vec::new();let mut iterations=1;\n        if !counter::ENABLED {\n            loop {\n                let start=Instant::now();\n                for _ in 0..iterations {black_box(work()?);}\n                if start.elapsed().as_secs_f64()>=0.01||iterations>=2048 {break;}\n                iterations*=2;\n            }\n            for _ in 0..9 {\n                let start=Instant::now();\n                for _ in 0..iterations {black_box(work()?);}\n                samples.push(start.elapsed().as_secs_f64()*1000.0/iterations as f64);\n            }\n        }\n        let allocation=if counter::ENABLED {\n            let mark=counter::begin();let output=work()?;black_box(&output);drop(output);\n            Some(counter::finish(mark))\n        } else {None};\n        println!("{}",json!({"case":fixture["name"],"mode":mode,"samples_ms":samples,\n            "iterations":iterations,"allocation":allocation,"wire_bytes":wire.len(),\n            "operations":operations,"wire":String::from_utf8(wire)?,"roundtrip_verified":true,\n            "input_bytes":left_bytes.len()+right_bytes.len()}));\n        return Ok(());\n    }\n    drop(initial);\n    for _ in 0..3 { black_box(generate(&dp,a,b,mode)?); }\n    let mut samples=Vec::new();\n    let mut iterations=1;\n    if !counter::ENABLED {\n        loop {\n            let start=Instant::now();\n            for _ in 0..iterations { black_box(generate(&dp,a,b,mode)?); }\n            if start.elapsed().as_secs_f64()>=0.01||iterations>=2048 {break;}\n            iterations*=2;\n        }\n        for _ in 0..9 {\n            let start=Instant::now();\n            for _ in 0..iterations { black_box(generate(&dp,a,b,mode)?); }\n            samples.push(start.elapsed().as_secs_f64()*1000.0/iterations as f64);\n        }\n    }\n    let allocation=if counter::ENABLED {\n        let mark=counter::begin();\n        let generated=generate(&dp,a,b,mode)?;\n        black_box(&generated);\n        drop(generated);\n        Some(counter::finish(mark))\n    } else {None};\n    println!("{}",json!({"case":fixture["name"],"mode":mode,\n        "samples_ms":samples,"iterations":iterations,"allocation":allocation,\n        "wire_bytes":wire.len(),"operations":operations,\n        "wire":String::from_utf8(wire)?,"roundtrip_verified":true}));\n    Ok(())\n}\n'

COUNTER = '\nuse std::alloc::{GlobalAlloc,Layout,System};\nuse std::sync::atomic::{AtomicBool,AtomicIsize,AtomicUsize,Ordering::Relaxed};\nuse serde_json::{Value,json};\npub const ENABLED:bool=true;\nstatic LIVE:AtomicIsize=AtomicIsize::new(0);\nstatic PEAK:AtomicIsize=AtomicIsize::new(0);\nstatic ACTIVE:AtomicBool=AtomicBool::new(false);\nstatic CALLS:AtomicUsize=AtomicUsize::new(0);\nstatic BYTES:AtomicUsize=AtomicUsize::new(0);\nstruct Counted;\nfn allocated(size:usize) {\n    let live=LIVE.fetch_add(size as isize,Relaxed)+size as isize;\n    if ACTIVE.load(Relaxed) {\n        CALLS.fetch_add(1,Relaxed);BYTES.fetch_add(size,Relaxed);PEAK.fetch_max(live,Relaxed);\n    }\n}\n// This benchmark forwards the original pointer/Layout unchanged to System.\n// Statistics never alter allocation success, ownership, size or alignment.\nunsafe impl GlobalAlloc for Counted {\n    unsafe fn alloc(&self,layout:Layout)->*mut u8 {\n        let pointer=unsafe {System.alloc(layout)};\n        if !pointer.is_null(){allocated(layout.size());}\n        pointer\n    }\n    unsafe fn alloc_zeroed(&self,layout:Layout)->*mut u8 {\n        let pointer=unsafe {System.alloc_zeroed(layout)};\n        if !pointer.is_null(){allocated(layout.size());}\n        pointer\n    }\n    unsafe fn dealloc(&self,pointer:*mut u8,layout:Layout) {\n        unsafe {System.dealloc(pointer,layout)};\n        LIVE.fetch_sub(layout.size() as isize,Relaxed);\n    }\n    unsafe fn realloc(&self,pointer:*mut u8,layout:Layout,size:usize)->*mut u8 {\n        let resized=unsafe {System.realloc(pointer,layout,size)};\n        if !resized.is_null(){LIVE.fetch_sub(layout.size() as isize,Relaxed);allocated(size);}\n        resized\n    }\n}\n#[global_allocator] static ALLOCATOR:Counted=Counted;\npub fn begin()->isize {\n    let mark=LIVE.load(Relaxed);PEAK.store(mark,Relaxed);\n    CALLS.store(0,Relaxed);BYTES.store(0,Relaxed);ACTIVE.store(true,Relaxed);mark\n}\npub fn finish(mark:isize)->Value {\n    ACTIVE.store(false,Relaxed);\n    let calls=CALLS.load(Relaxed);\n    let bytes=BYTES.load(Relaxed);\n    let peak=PEAK.load(Relaxed)-mark;\n    let remaining=LIVE.load(Relaxed)-mark;\n    json!({"allocation_or_reallocation_calls":calls,\n        "requested_bytes":bytes,"peak_additional_live_bytes":peak,\n        "final_live_delta_bytes":remaining})\n}\n'

STUB = '\npub const ENABLED:bool=false;\npub fn begin()->isize{0}\npub fn finish(_:isize)->serde_json::Value{serde_json::Value::Null}\n'
def run(command, cwd=None, timeout=600):
    result = subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    if result.returncode:
        raise RuntimeError(f"{command}\n{result.stdout[-2000:]}\n{result.stderr[-4000:]}")
    return result

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


cases = []
fixture_source = Path(sys.argv[4]).resolve()
for name, modes in [('small-config-edit', ['optimized', 'guarded']), ('rotate-2000', ['optimized', 'guarded']), ('disjoint-2000', ['optimized', 'guarded']), ('ambiguous-ids-2000', ['optimized', 'guarded']), ('file_migrations_move_copy_100', ['factorize', 'optimized', 'guarded']), ('file_migrations_move_copy_400', ['factorize', 'optimized', 'guarded']), ('file_migrations_move_copy_800', ['factorize', 'optimized', 'guarded']), ('duplicate-object-migrations-100', ['factorize', 'optimized', 'guarded']), ('duplicate-object-migrations-800', ['factorize', 'optimized', 'guarded']), ('independent_add_remove_replace_800', ['optimized', 'guarded']), ('root_add_guard_overlap_800', ['optimized', 'guarded'])]:
    fixture=json.loads((fixture_source/(name+".json")).read_text())
    for mode in modes: cases.append((fixture,mode))

environment = dict(platform=platform.platform(), rustc=run(["rustc","-Vv"]).stdout,
    timing="Loaded generation/drop for ordinary modes; pipeline-native parses two frozen raw inputs; retained-old-pipeline borrows an existing left Value and only parses the frozen new input; both diff and serialize with timed temporaries/output destruction; verification outside timings",
    samples="3 warmups, >=10ms calibration cap2048, 9 batches, 3 independent processes/version, alternating order",
    allocation="Separate instrumented binary; one generation/drop after warmup; requested allocations, not RSS or allocator internals",
    source={}, builds={}, fixtures={}, runner_sha256=sha(Path(__file__)))
binaries = {}
for label, source in [("baseline", baseline), ("candidate", candidate)]:
    snapshot = output/"sources"/label
    snapshot.mkdir(parents=True)
    for name in ["Cargo.toml","Cargo.lock","README.md"]:
        shutil.copy2(source/name,snapshot/name)
    for directory in ["src","benches","examples"]:
        shutil.copytree(source/directory,snapshot/directory)
    environment["source"][label] = dict(commit="7646a6f676d3c5c00dcc462433f8cfcded2e487c",
        hashes={str(path.relative_to(snapshot)):sha(path) for path in snapshot.rglob("*") if path.is_file()})
    project = output/"probes"/label
    (project/"src/bin").mkdir(parents=True)
    for name, counter in [("timing", STUB), ("allocation", COUNTER)]:
        (project/f"src/bin/{name}.rs").write_text("mod counter {"+counter+"}\n"+RUST)
    (project/"Cargo.toml").write_text('[package]\nname="palim-remaining-probe"\nversion="0.0.0"\nedition="2024"\n[dependencies]\npalim={path='+json.dumps(str(snapshot))+'}\nserde_json={version="1.0",features=["float_roundtrip","arbitrary_precision"]}\njson-patch="4.2.0"\n')
    shutil.copy2(source/"Cargo.lock",project/"Cargo.lock")
    built = run(["cargo","build","--release","--offline","--bins"],cwd=project)
    environment["builds"][label] = dict(stderr=built.stderr,lock_sha256=sha(project/"Cargo.lock"))
    for name in ["timing","allocation"]:
        binaries[(label,name)] = project/f"target/release/{name}"
        environment["builds"][label][name+"_sha256"] = sha(binaries[(label,name)])
    print("built",label,flush=True)

(output/"fixtures").mkdir()
paths = {}
for fixture, mode in cases:
    name = fixture["name"]
    path = output/f"fixtures/{name}.json"
    path.write_text(json.dumps(fixture,ensure_ascii=False))
    paths[name] = path
    environment["fixtures"][name] = sha(path)
records = []
for repeat in range(3):
    for index, (fixture, mode) in enumerate(cases):
        labels = ["baseline","candidate"] if (repeat+index)%2==0 else ["candidate","baseline"]
        for kind in ["timing","allocation"]:
            for label in labels:
                started = time.monotonic()
                row = json.loads(run([str(binaries[(label,kind)]),str(paths[fixture["name"]]),mode],timeout=300).stdout)
                row["wire_sha256"] = hashlib.sha256(row.pop("wire").encode()).hexdigest()
                row.update(version=label,kind=kind,repeat=repeat,wall_seconds=time.monotonic()-started)
                if row["samples_ms"]:
                    row["median_ms"] = statistics.median(row["samples_ms"])
                records.append(row)
                (output/"measurements.json").write_text(json.dumps(records,indent=2))
    print("completed process repeat",repeat+1,flush=True)
summary = []
for fixture, mode in cases:
    row = dict(case=fixture["name"],mode=mode)
    selected = [r for r in records if r["case"]==fixture["name"] and r["mode"]==mode]
    assert len({r["wire_sha256"] for r in selected})==1, (fixture["name"],mode,"output changed")
    row["identical_output"] = True
    for label in ["baseline","candidate"]:
        timing = [r for r in selected if r["version"]==label and r["kind"]=="timing"]
        memory = [r for r in selected if r["version"]==label and r["kind"]=="allocation"]
        row[label] = dict(median_ms=statistics.median(r["median_ms"] for r in timing),
            process_medians_ms=[r["median_ms"] for r in timing],wire_bytes=timing[0]["wire_bytes"],
            operations=timing[0]["operations"],allocation=[r["allocation"] for r in memory])
    row["speedup"] = row["baseline"]["median_ms"]/row["candidate"]["median_ms"]
    summary.append(row)
(output/"summary.json").write_text(json.dumps(summary,indent=2))
(output/"environment.json").write_text(json.dumps(environment,indent=2))
print(json.dumps([{k:r[k] for k in ["case","mode","speedup"]} for r in summary],indent=2))
