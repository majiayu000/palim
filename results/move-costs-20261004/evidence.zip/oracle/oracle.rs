
#[cfg(test)]
mod index_review_oracle {
    use super::*;
    use std::sync::Arc;

    fn wire(patch: &Patch) -> String { serde_json::to_string(patch).unwrap() }
    fn error(phase: &str, error: Error) -> Value {
        json!({"phase":phase,"path":error.path,"message":error.message})
    }
    fn original(case: &Value) -> Patch {
        Patch(case["original"].as_array().unwrap().iter().cloned().map(|v|decode(v).unwrap()).collect())
    }
    #[test]
    fn freeze() {
        let output = std::path::PathBuf::from(std::env::var("PALIM_INDEX_ORACLE_OUTPUT_DIR").unwrap());
        std::fs::create_dir_all(&output).unwrap();
        let private: Vec<Value> = serde_json::from_str(include_str!("/tmp/palim-move-oracle-20261004/frozen-private-cases.json")).unwrap();
        let mut records = Vec::new();
        for case in private {
            let left = &case["left"];
            let original = original(&case);
            let right = case.get("right").cloned().unwrap_or_else(|| apply_json_patch(left, &original).unwrap());
            for tests in [false, true] {
                let mut record = json!({"id":case["id"],"tests":tests});
                let optimized = match rationalize(left, &right, original.clone(), tests) {
                    Ok(v) => v,
                    Err(e) => {
                        assert!(tests && case["expect_guarded_error"] == true, "unexpected rationalize error: {:?}", e);
                        record["error"] = error("rationalize", e);
                        records.push(record);
                        continue;
                    }
                };
                assert!(!(tests && case["expect_guarded_error"] == true), "expected original guard error");
                record["optimized_wire"] = Value::String(wire(&optimized));
                let final_patch = if tests {guard(left.clone(), &optimized).unwrap()} else {optimized};
                record["patch_wire"] = Value::String(wire(&final_patch));
                let actual = apply_json_patch(left, &final_patch).unwrap();
                let matches = json_equal(&actual, &right);
                assert!(matches || case["allow_incomplete"] == true, "private {} does not reach target", case["id"]);
                record["forward_matches_target"] = Value::Bool(matches);
                let inverse = crate::invert_json_patch(left, &final_patch).unwrap();
                assert!(json_equal(&apply_json_patch(&actual, &inverse).unwrap(), left), "private inverse {}", case["id"]);
                record["inverse_wire"] = Value::String(wire(&inverse));
                records.push(record);
            }
        }
        std::fs::write(output.join("private-output.json"), serde_json::to_vec(&records).unwrap()).unwrap();
        let public: Vec<Value> = serde_json::from_str(include_str!("/tmp/palim-move-oracle-20261004/frozen-public-cases.json")).unwrap();
        let dp = crate::DiffPatcher::new(crate::DiffOptions {
            object_hash: Some(Arc::new(|v, _| v.get("id").map(Value::to_string))),
            ..Default::default()
        });
        let mut records = Vec::new();
        for (index, case) in public.iter().enumerate() {
            for factorize in [false, true] { for rationalize in [false, true] { for tests in [false, true] {
                let patch = dp.diff_json_patch(&case["left"], &case["right"], &JsonPatchOptions {factorize, rationalize, tests}).unwrap();
                let actual = apply_json_patch(&case["left"], &patch).unwrap();
                assert!(json_equal(&actual, &case["right"]), "public forward {} flags {:?}", index, (factorize,rationalize,tests));
                let inverse = crate::invert_json_patch(&case["left"], &patch).unwrap();
                assert!(json_equal(&apply_json_patch(&actual, &inverse).unwrap(), &case["left"]), "public inverse {}", index);
                records.push(json!({"index":index,"name":case["name"],"factorize":factorize,"rationalize":rationalize,"tests":tests,
                    "patch_wire":wire(&patch),"inverse_wire":wire(&inverse)}));
            } } }
        }
        std::fs::write(output.join("public-output.json"), serde_json::to_vec(&records).unwrap()).unwrap();
        println!("oracle complete: {} public records; {} private cases x2", records.len(), 17);
    }
}

#[cfg(test)]
mod mixed_review_oracle {
    use super::*;
    #[test]
    fn freeze() {
        let cases: Vec<Value> = serde_json::from_str(include_str!("/tmp/palim-move-oracle-20261004/mixed-factor-cases.json")).unwrap();
        let mut records = Vec::new();
        for case in cases {
            let left = &case["left"];
            let original = Patch(case["original"].as_array().unwrap().iter().cloned().map(|v| decode(v).unwrap()).collect());
            let right = case.get("right").cloned().unwrap_or_else(|| apply_json_patch(left, &original).unwrap());
            for tests in [false,true] {
                let component = case["component"].as_str().unwrap();
                let mut record = json!({"id":case["id"],"component":component,"tests":tests});
                let optimized = match if component == "factorize" {
                    factorize(left,&right,original.clone())
                } else {
                    rationalize(left,&right,original.clone(),tests)
                } {
                    Ok(v) => v,
                    Err(error) => {
                        assert!(case["expect_component_error"]==true || tests && case["expect_guarded_error"]==true,"unexpected error {}: {:?}",case["id"],error);
                        record["error"]=json!({"phase":component,"path":error.path,"message":error.message});
                        records.push(record);continue;
                    }
                };
                assert!(case["expect_component_error"]!=true && !(tests && case["expect_guarded_error"]==true),"expected component error {}",case["id"]);
                record["optimized_wire"]=Value::String(serde_json::to_string(&optimized).unwrap());
                let patch=if tests {guard(left.clone(),&optimized).unwrap()} else {optimized};
                record["patch_wire"]=Value::String(serde_json::to_string(&patch).unwrap());
                let actual=apply_json_patch(left,&patch).unwrap();
                assert!(json_equal(&actual,&right),"forward {}",case["id"]);
                let inverse=crate::invert_json_patch(left,&patch).unwrap();
                assert!(json_equal(&apply_json_patch(&actual,&inverse).unwrap(),left),"inverse {}",case["id"]);
                record["inverse_wire"]=Value::String(serde_json::to_string(&inverse).unwrap());
                records.push(record);
            }
        }
        std::fs::write(std::env::var("PALIM_MIXED_ORACLE_OUTPUT").unwrap(),serde_json::to_vec(&records).unwrap()).unwrap();
        println!("mixed/factor oracle complete: {} records",records.len());
    }
}
