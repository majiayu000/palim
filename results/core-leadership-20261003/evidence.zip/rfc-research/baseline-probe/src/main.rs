
use serde_json::{Value,json};
use palim::{DiffOptions,DiffPatcher,JsonPatchOptions};
use std::{time::Instant,hint::black_box,sync::Arc};
fn bench<T>(mut f: impl FnMut()->T)->f64 {
  for _ in 0..3 {black_box(f());}
  let mut n=1;
  loop { let start=Instant::now();for _ in 0..n {black_box(f());}if start.elapsed().as_millis()>=5||n>=1024{break;}n*=2; }
  let mut values=Vec::new();
  for _ in 0..7 {let start=Instant::now();for _ in 0..n {black_box(f());}values.push(start.elapsed().as_secs_f64()*1000.0/n as f64);}
  values.sort_by(f64::total_cmp);values[3]
}
fn main(){
 let dir="/Users/apple/Desktop/code/AI/tool/secrets/palim/results/standard-benchmark-pipeline-20260930T214341.446185Z/fixtures";
 let mut cases=Vec::new();
 for name in ["small-config-edit","disjoint-2000","ambiguous-ids-2000","rotate-2000"] {let v:Value=serde_json::from_slice(&std::fs::read(format!("{dir}/{name}.json")).unwrap()).unwrap();cases.push((name.to_string(),v["left"].clone(),v["right"].clone()));}
 cases.push(("large-stable-1MiB".into(),json!({"keep":"A".repeat(1048576),"edit":{"x":1}}),json!({"keep":"A".repeat(1048576),"edit":{"x":2}})));
 for n in [100,400] {
  let a=json!((0..n).map(|i|serde_json::json!({"id":i,"a_long_property_name":i,"b_long_property_name":i,"c_long_property_name":i})).collect::<Vec<_>>());
  let b=json!((0..n).map(|i|serde_json::json!({"id":i,"a_long_property_name":i+100000,"b_long_property_name":i+200000,"c_long_property_name":i+300000})).collect::<Vec<_>>());
  cases.push((format!("many-accepted-{n}"),a,b));
 }
 let dp=DiffPatcher::new(DiffOptions {object_hash:Some(Arc::new(|v,_|v.get("id").map(Value::to_string))),..Default::default()});
 for (name,a,b) in cases {
  let delta=dp.diff(&a,&b).unwrap().unwrap();
  let exported=palim::export::export_known(&a,&b,&delta,false).unwrap();
  let factored=palim::rfc::factorize(&a,&b,exported.clone()).unwrap();
  let optimized=palim::rfc::rationalize(&a,&b,factored.clone(),false).unwrap();
  assert_eq!(palim::apply_json_patch(&a,&optimized).unwrap(),b);
  let plain=JsonPatchOptions{factorize:false,rationalize:false,tests:false};
  println!("{}",json!({"case":name,"native_ms":bench(||dp.diff(&a,&b).unwrap()),"export_ms":bench(||palim::export::export_known(&a,&b,&delta,false).unwrap()),"factorize_clone_inside_ms":bench(||palim::rfc::factorize(&a,&b,exported.clone()).unwrap()),"rationalize_clone_inside_ms":bench(||palim::rfc::rationalize(&a,&b,factored.clone(),false).unwrap()),"default_ms":bench(||dp.diff_json_patch(&a,&b,&JsonPatchOptions::default()).unwrap()),"plain_ms":bench(||dp.diff_json_patch(&a,&b,&plain).unwrap()),"native_patch_ms":bench(||palim::patch(&a,&delta).unwrap()),"native_owned_clone_outside_ms":({let vals:Vec<_>=(0..64).map(|_|a.clone()).collect();let start=Instant::now();for val in vals {black_box(palim::patch_owned(val,&delta).unwrap());}start.elapsed().as_secs_f64()*1000.0/64.0}),"rfc_apply_ms":bench(||palim::apply_json_patch(&a,&optimized).unwrap()),"rfc_inverse_ms":bench(||palim::invert_json_patch(&a,&optimized).unwrap()),"rfc_export_ops":exported.0.len(),"rfc_factor_ops":factored.0.len(),"rfc_final_ops":optimized.0.len(),"wire":serde_json::to_string(&optimized).unwrap().len(),"output":optimized}));
 }
}
