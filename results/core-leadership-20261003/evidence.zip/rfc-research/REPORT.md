# Performance candidate report — 2026-10-03

All implementation/profiling work is isolated in this detached worktree based on `be76218b1ddde5752004cc5a99fc19b41686558f`. Primary repository and other agents' files were not changed. Rust best practices was read before Rust probe changes. No commits, push, registry release or GitHub messages.

## Selected changes

1. Root disjoint primitive arrays with factorization enabled directly construct the exact original Remove-descending/Add-ascending standard sequence. The existing optimizer still decides Copy/Move and parent replacement. This removes the native reversible tree construction and conversion. Tests/filters/custom matcher remain outside the fast path. `object_hash` is not invoked on primitives in original `diff.rs::key`, so configured hashes have no skipped invocations.
2. Rationalize lazily indexes destination ancestor -> original operation indices, exact destination set, and move indices only while the initial patch is unchanged. Candidate ordering, operation ordering, move-boundary rejection, byte budgeting and full candidate application verification remain unchanged. Root-only and single-operation candidates avoid indexing. After the first accepted mutation, original scanning is used, rather than rebuilding repeatedly.

Production-ready source diff: `performance.patch`; no public profiling hooks included. Scope: src/lib.rs, src/export.rs, src/rfc.rs only. The parent must review and integrate and should add focused regression tests for index invalidation, escaped paths and primitive object_hash callback counts.

## Measured result

Loaded Values; input parsing/serialization/verification excluded. Generation and return-value destruction included. 3 warmups, >=5 ms calibration capped at 1024 iterations, 7 samples, 3 independent processes per version with alternating version order. Median of process medians. Phase rationalize measurement additionally includes the required incoming patch clone, so it is not a pure internal function timer.

| Case | Baseline default ms | Prototype default ms | Baseline / prototype |
|---|---:|---:|---:|
| disjoint-2000 | 4.340000 | 2.366416 | 1.83x |
| ambiguous-ids-2000 | 23.847459 | 7.908417 | 3.02x |
| small-config-edit | 0.004017 | 0.004001 | 1.00x |
| rotate-2000 | 0.329175 | 0.332049 | 0.99x |
| large-stable-1MiB | 0.027579 | 0.027669 | 1.00x |
| many-accepted-100 | 11.551666 | 11.722542 | 0.99x |
| many-accepted-400 | 174.500542 | 177.531333 | 0.98x |

ambiguous rationalize phase 19.885333 -> 4.057104 ms (4.90x). All seven canonical final patch outputs identical. Final measurements and source/binary SHA256: summary-final.json, measurements-final.json, environment-final.json. This is a single host with concurrent user sessions; 1-2% control differences cannot establish true regressions or rankings.

## Rejected experiment

Rebuilding the complete ancestor index after every accepted candidate regressed the independent compressible-parent control: many-accepted-100 11.757 -> 17.185 ms and many-accepted-400 182.749 -> 266.860 ms (~46%). This is concrete evidence for the conservative after-first-mutation scan policy. Raw records: baseline-many-accepted.jsonl, prototype-many-accepted.jsonl. Earlier five-case-only summary.json/measurements.json refers to this rejected implementation and MUST NOT be presented as final.

## Verification

- Final production patch (profiling exports removed): cargo fmt and git diff --check completed.
- cargo test --release --locked: 146 tests including doc test passed. Raw final stdout/stderr: release-tests-final.json.
- 373 saved pairs x all 8 RFC factorize/rationalize/tests configurations = 2,984 exact output comparisons against baseline. All outputs byte-identical; forward/inverse application independently checked for each. Final candidate rebuilt after hook removal. differential-verification-final.json; baseline-differential.jsonl and prototype-final-differential.jsonl.
- Stage timing prototype exposed otherwise private functions only to the separate probe. Final patch removes these exports. The final production tree differs from the timed source only in visibility, comments/formatting and replacing proven Move-only unwrap with typed if-let.

## Remaining cost / minimal next investigation

Many independently compressible parents still clone and apply the entire candidate patch for each accepted replacement (~175 ms at 400 objects). Indexing alone cannot remove this cost. A narrowly proven subtree-local validation can help only when the replaced boundary is stable through object parents and all Move/Copy dependencies are inside it; array index shifts, destination overwrite and cross-subtree copies otherwise require the existing whole-document verification. No unsafe bypass has been included.

Owned application APIs already exist. Transferring a caller-owned Value avoids the baseline clone; simply cloning inside an owned call restores the same work. Do not introduce another borrowed backend or copy-on-write DOM for this task. The isolated probe measures owned transfer after preparing its clones outside timing; those numbers are not fair speed comparisons for borrowed callers.

Small object generation is already around 4 microseconds and unchanged. No unmeasured claim of being fastest across competitors is justified by this report.

## Reproduction

Binaries and embedded Rust probe source retained under probe/ and baseline-probe/. To run final public-API differential output checks:

```
cd /tmp/palim-performance-lead-20261003/probe
cargo run --release --bin differential --offline > /tmp/candidate-differential.jsonl
cmp /tmp/candidate-differential.jsonl ../baseline-differential.jsonl
```

For stage timing, retained binaries use private profiling visibility hooks; production-ready source has had hooks removed, so rebuilding that specific timing driver requires reinstating those temporary exports. This is an analysis tool, not a new production API. Existing parent `tools/performance-fixes.py` can verify production APIs directly after integration.
