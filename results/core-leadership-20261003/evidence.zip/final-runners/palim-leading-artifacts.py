import hashlib, json, pathlib, subprocess, zipfile

R = pathlib.Path('/Users/apple/Desktop/code/AI/tool/secrets/palim-leading')
O = R/'results/core-leadership-20261003'
O.mkdir(exist_ok=True)
C = pathlib.Path('/tmp/palim-competitor-20261003')
P = pathlib.Path('/tmp/palim-performance-lead-20261003')
T = pathlib.Path('/tmp/palim-text-opt-20261003')
A = pathlib.Path('/tmp/palim-capability-20261003')
F = pathlib.Path('/tmp/palim-leading-benchmark-20261003')
U = pathlib.Path('/tmp/palim-leading-consumer-20261003')

def read(path):
    return json.loads(path.read_text())

criterion = {}
criterion_paths = list((R/'target/criterion/standard_test-only').glob('*/**/new/*.json'))
criterion_paths += list((R/'target/criterion/risk_standard-apply').glob('invert*/new/*.json'))
for path in criterion_paths:
    criterion[str(path.relative_to(R/'target/criterion'))] = read(path)
measurements = dict(
    final_competitor=dict(summary=read(F/'summary.json'), records=read(F/'measurements.json'), environment=read(F/'environment.json')),
    baseline_competitor_summary=read(C/'summary.json'),
    loaded_rfc_prototype=dict(summary=read(P/'summary-final.json'), records=read(P/'measurements-final.json'), environment=read(P/'environment-final.json')),
    native_text_prototype=dict(summary=read(T/'summary.json'), records=read(T/'measurements.json'), environment=read(T/'environment.json')),
    criterion=criterion,
)
(O/'measurements.json').write_text(json.dumps(measurements, ensure_ascii=False, indent=2))
checks = dict(commands=read(pathlib.Path('/tmp/palim-leading-checks-20261003.json')),
    packaged_consumer=read(U/'verification.json'),
    integrated_rfc_differential=read(P/'differential-verification-integrated.json'),
    text_differential=read(T/'generated-verification.json'),
    criterion_commands=[dict(command=['cargo','bench','--bench','core','--locked','--','standard/test-only','--noplot'],exit_code=0),
        dict(command=['cargo','bench','--bench','core','--locked','--','risk/standard-apply/invert','--noplot'],exit_code=0)],
    readonly_review=dict(agent='capability_lead', blockers=[], checks=['shared Test error order and depth','inverse error priority','consume final shadow','guard scope']),
    platform_limit='Local macOS only; CI cross-platform jobs were not re-executed here',
)
(O/'checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2))

with zipfile.ZipFile(O/'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path,label in [(C/'evidence.zip','baseline-competitors.zip'),(T/'evidence.zip','native-text-prototype.zip')]:
        archive.write(path,label)
    for path in [pathlib.Path('/tmp/palim-leading-benchmark.py'),pathlib.Path('/tmp/palim-leading-checks.py'),pathlib.Path(__file__)]:
        archive.write(path,'final-runners/'+path.name)
    for path in [F/'summary.json',F/'measurements.json',F/'environment.json']:
        archive.write(path,'final-competitor/'+path.name)
    for path in sorted((R/'src').glob('*.rs')) + [R/'Cargo.toml',R/'Cargo.lock',R/'examples/standard_bench.rs',R/'examples/fixture_runner.rs',R/'benches/core.rs',R/'tests/standard_extensions.rs',R/'tests/performance_regressions.rs',R/'fuzz/fuzz_targets/core.rs']:
        archive.write(path,'final-source/'+str(path.relative_to(R)))
    for path in sorted((C/'source/src').glob('*.rs')) + [C/'source/Cargo.toml',C/'source/Cargo.lock',C/'source/examples/standard_bench.rs',C/'source/examples/fixture_runner.rs']:
        archive.write(path,'baseline-source/'+str(path.relative_to(C/'source')))
    archive.write(R/'tests/fixtures/correctness.json','rfc-research/fixtures/correctness.json')
    for path in P.iterdir():
        if path.is_file() and path.suffix in ['.json','.jsonl','.patch','.md']:
            archive.write(path,'rfc-research/'+path.name)
    for directory in [P/'probe/src',P/'baseline-probe/src']:
        if directory.exists():
            for path in directory.rglob('*.rs'):
                archive.write(path,'rfc-research/'+str(path.relative_to(P)))
    for path in [P/'probe/Cargo.toml',P/'probe/Cargo.lock',P/'baseline-probe/Cargo.toml',P/'baseline-probe/Cargo.lock']:
        if path.exists():
            archive.write(path,'rfc-research/'+str(path.relative_to(P)))
    for path in [A/'REPORT.md',A/'observations.json',A/'enumeration.json',A/'enumerate_matchings.py',A/'exact-first-rejected.patch']:
        archive.write(path,'capability-research/'+path.name)
    for path in [U/'Cargo.toml',U/'Cargo.lock',U/'src/main.rs',U/'verification.json']:
        archive.write(path,'packaged-consumer/'+str(path.relative_to(U)))
    for path in criterion_paths:
        archive.write(path,'criterion/'+str(path.relative_to(R/'target/criterion')))
    patch = subprocess.check_output(['git','diff','--','src','benches','fuzz/fuzz_targets','tests/performance_regressions.rs','README.md'],cwd=R)
    archive.writestr('final-source/changes.patch',patch)
    archive.writestr('final-source/new-test.patch',subprocess.run(['git','diff','--no-index','--','/dev/null',str(R/'tests/standard_extensions.rs')],capture_output=True).stdout)
print(json.dumps(dict(directory=str(O), files={path.name:dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in O.iterdir() if path.is_file()}),indent=2))
