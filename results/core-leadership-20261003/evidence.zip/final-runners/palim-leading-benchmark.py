import hashlib, json, pathlib, platform, statistics, subprocess, time

P = pathlib.Path('/tmp/palim-competitor-20261003')
C = pathlib.Path('/Users/apple/Desktop/code/AI/tool/secrets/palim-leading')
O = pathlib.Path('/tmp/palim-leading-benchmark-20261003')
O.mkdir(exist_ok=False)
records = []

def run(command, fixture, repeat):
    start = time.monotonic()
    result = subprocess.run(command, capture_output=True, text=True, timeout=120, check=True)
    row = json.loads(result.stdout.strip().splitlines()[-1])
    row = row[0] if isinstance(row, list) else row
    row.update(repeat=repeat, wall_seconds=time.monotonic()-start)
    if 'patch' in row:
        patch = row.pop('patch')
        verified = subprocess.run(['node', str(P/'js/verify.mjs'), str(fixture)], input=json.dumps(patch), capture_output=True, text=True, check=True)
        row['independent_verify'] = verified.stdout.strip()
        row['patch_sha256'] = hashlib.sha256(json.dumps(patch, separators=(',', ':')).encode()).hexdigest()
    records.append(row)
    (O/'measurements.json').write_text(json.dumps(records, indent=2))
    print(row['name'], row['engine'], repeat, round(row['pipeline_ms'], 6), row['patch_bytes'], flush=True)

for repeat in range(3):
    for name in ['small-config-edit', 'disjoint-2000', 'long-text-ascii', 'unicode-three-edits']:
        fixture = P/'fixtures'/(name+'.json')
        engines = ['json-patch', 'plain', 'optimized']
        engines = engines[repeat:] + engines[:repeat]
        for engine in engines:
            run([str(C/'target/release/examples/standard_bench'), engine, str(fixture)], fixture, repeat)
        for engine in ['default', 'optimized', 'optimized-lcs']:
            run([str(P/'go/probe'), engine, str(fixture)], fixture, repeat)
for repeat in range(3):
    for name in ['small-config-edit', 'rotate-2000', 'disjoint-2000', 'unicode-three-edits']:
        fixture = P/'fixtures'/(name+'.json')
        engines = ['palim', 'default', 'no-position']
        engines = engines[repeat:] + engines[:repeat]
        for engine in engines:
            command = ([str(C/'target/release/examples/fixture_runner'), 'benchmark', str(fixture)] if engine == 'palim'
                       else ['node', str(P/'js/bench.mjs'), str(fixture), engine])
            run(command, fixture, repeat)
grouped = {}
for row in records:
    grouped.setdefault((row['name'], row['engine']), []).append(row)
summary = []
for (name, engine), rows in grouped.items():
    summary.append(dict(name=name, engine=engine, pipeline_ms=statistics.median(row['pipeline_ms'] for row in rows),
        diff_ms=statistics.median(row['diff_ms'] for row in rows) if 'diff_ms' in rows[0] else None,
        patch_bytes=rows[0]['patch_bytes'], operations=rows[0].get('operations'), processes=len(rows)))
(O/'summary.json').write_text(json.dumps(summary, indent=2))
paths = list((C/'src').glob('*.rs')) + [C/'Cargo.lock', C/'Cargo.toml', C/'examples/fixture_runner.rs', C/'examples/standard_bench.rs',
    C/'target/release/examples/fixture_runner', C/'target/release/examples/standard_bench', P/'go/probe', P/'go/go.sum', P/'go/main.go', P/'js/bench.mjs', P/'js/verify.mjs', pathlib.Path(__file__)] + list((P/'fixtures').glob('*.json'))
environment = dict(platform=platform.platform(), source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=C, text=True).strip(),
    hashes={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in paths},
    rustc=subprocess.check_output(['rustc', '-Vv'], text=True), node=subprocess.check_output(['node', '-v'], text=True),
    go=subprocess.check_output(['go', 'version'], text=True), concurrent_agent_benchmarks=False,
    rfc_boundary='parse both documents -> typed RFC diff -> serialize patch', native_boundary='parse both documents -> reversible delta -> serialize delta')
(O/'environment.json').write_text(json.dumps(environment, indent=2))
print('DONE', len(records), flush=True)
