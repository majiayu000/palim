# Palim 核心功能研究与实验

日期 2026-10-03。冻结基线 be76218，生产目录只读。隔离 Rust 消费者和 rejected candidate 保存在本目录。未提交、推送或联系外部维护者。

## 1. 只读 Test API：建议 adopt

真实需求 [idubrov/json-patch #52](https://github.com/idubrov/json-patch/issues/52) 是使用者只有 `&Value` 时不必 clone 输入 JSON。当前 Rust [源码](https://github.com/idubrov/json-patch/blob/master/src/lib.rs) 的 private test 已用 `&Value`，public patch/patch_unsafe 仍要求 `&mut Value`。不能宣传上游算法本身总会 clone；拥有 mutable access 的调用者不需要 clone。JS fast-json-patch [validate(document) 源码](https://github.com/Starcounter-Jack/JSON-Patch/blob/master/src/core.ts) 克隆 document 和 sequence 后试运行。

最小 API `test_json_patch(left: &Value, patch: &Patch) -> Result<(), Error>`，接受 empty/Test-only 序列，按操作次序遇到非 Test 报错，不能默默忽略写操作。开头复用 check_standard_source 默认 max_depth=128；包括空 patch 在内保持输入 depth 检查。把现有 Test 的 payload-depth → pointer → mathematical json_equal 提到一个 private helper，供 apply 与 test-only 共用。错误保留 operation index/path：missing path != null，invalid `/01` index 拒绝，1 与 1.0 相等。不要一次提前扫描全部非 Test，以免掩盖更早的 Test 失败。

源码位置（be76218）：src/lib.rs apply_json_patch_with_options 335，check_standard_source 369，step_with_depth 434，Test 分支 449；tests/standard_semantics.rs numeric equality 10、operation/path 113。需测借用输入 apply clone vs Test-only、allocation bytes、源数据 depth 检查成本；不要宣称常量时间/零分配，因为默认 depth 检查仍遍历容器并分配 scratch。

## 2. 核心差距一：guarded inverse，建议适应现有 guard

src/rfc.rs invert_json_patch 862 丢掉原 Test（原函数已有文档合同）。实际复现：left={x:1,items:[1,2]} → right={x:2,items:[2,1]}，带 Test 正向能正确应用；逆向输出没有 Test，应用漂移值 {x:99,items:[9,8]} 被接受并产生 {x:1,items:[8,2]}。

[Go jsondiff 当前 Patch.Invert](https://github.com/wI2L/jsondiff/blob/master/patch.go) 对 Add/Replace 的逆向会先 Test 新值，但它拒绝 Copy 逆转。Palim 已能用完整 baseline 逆转所有六种 operation，可增加显式 invert_json_patch_guarded 复用 final shadow 和 guard，不改变原 inverse 合同。private invert_with_target 返回 (Patch, Value)；guard 消费已有 Value 可免多一次全量 clone。

这是被触及值/容器的条件撤销，不是整份文档或 ID 漂移认证。missing object key Add 与 array insertion 的 absence/order 没有单项 RFC Test，因此现有 guard_add_value 检查整个 parent；无关 sibling 漂移在这些场景也可能拒绝。已有 object Replace 才能宽容未触及 sibling 的变化。

验收：all-six-op overwrite/append/root/ancestor Move 往返；错误原 operation/index/path 一致；新增右值漂移拒绝；现存 object Replace 的 sibling 漂移可接受；missing-key Add 父容器漂移拒绝；Test-only inverse 空序列；depth/数值边界沿用。

## 3. 核心差距二：自定义相似匹配的补丁质量

src/diff.rs custom_matches 354 当前目标是最大配对数量，之后对选定配对求 LIS。这不等于最大 unchanged 配对、最少 Move 或最少 bytes。冻结消费者证明 left=[0,1,2], right=[1,2,0] 的合法候选关系 new1:[0,1,2],new2:[1,2],new0:[0]，当前结果2 Move+2 Replace；关系允许1 Move+0 Replace，默认 value 匹配也输出这个结果。

### rejected experiment：exact allowed candidates 优先

candidate 仅对 matcher 返回 true 的候选按 Value equality 做稳定分组；callback 仍按 b-major/a-ascending 顺序执行一次，BFS其他逻辑不变。26 项既有 tests（array_quality 17、performance_regressions 9）全通过，无既有 golden 变动；3 项新测试验证改善案例、禁止强行接受 rejected exact 值、augment 能重新分配 exact 配对以保留最大基数。合计 release29 tests通过。

但这个启发式有实际退化，暂不建议直接合入。

| 相同 left=[0,1,2]，right 与允许候选 | baseline | exact-first candidate |
|---|---|---|
| right=[1,2,0]；new1:[0,1,2],new2:[1,2],new0:[0] | 2 Move+2 Replace | 1 Move+0 Replace |
| right=[0,2,1]；new0:[0,1],new2:[1,2],new1:[0,2] | 0 Move+2 Replace | 1 Move+2 Replace |
| right=[1,0,2]；new1:[0,1],new0:[1,2],new2:[1,2] | 0 Move+2 Replace，1 unchanged pair | 1 Move+3 Replace，0 unchanged pair |

三个案例均 native apply/unpatch 成功。独立 Python 枚举镜像算法也找到相同退化；该枚举是匹配层模型，不等于整库质量测试。结论是：值优先局部排序不能保证每个输入改善，更不能凭一个优例宣布全面领先。应先定义“匹配基数/不变值/移动/bytes”目标，再研究有测量边界的选优；本轮不要引入通用 min-cost graph 或新配置。

## 4. 过滤与产品边界

[.NET #48](https://github.com/weichch/system-text-json-jsondiffpatch/issues/48) 对 null/object 的 property_filter 期待值得说明，但完整可逆 delta 必须保留真实 old subtree，删除 ignored 字段会破坏 strict old-value 与 reverse 合同。Palim node_filter 可以投影 null→object 的新值，object→null 保持授权父节点原子替换；tests/array_quality.rs subtree_filters_allow_atomic_container_to_scalar_replacement 已固定该语义。这个问题不应通过制造 object/null/缺失值兼容层“修复”。

ID 漂移同步、JSONPath wildcard、语言绑定、CLI、HTML formatter 属于更大的产品/协议边界，不是完成当前 JSON diff/patch 核心领先所必需的新平台。

## 工件

- observations.json：冻结基线/候选真实运行输出、consumer source 与 binary SHA-256。
- probe/src/main.rs 与 candidate-probe/src/main.rs：核心反例与 RFC Test error contract。
- exact-first-rejected.patch：两个文件的独立候选 diff，可复现，不建议无条件合入。
- candidate/：可用 cargo test --release --offline --test array_quality --test performance_regressions 重跑29tests。
