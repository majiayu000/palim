from collections import deque
from itertools import permutations
from bisect import bisect_left
import json

def match(n, candidates):
    old_for_new = [None] * n
    new_for_old = [None] * n
    for new in range(n):
        seen_old, seen_new = set(), {new}
        previous, queue, free = {new: None}, deque([new]), None
        while queue and free is None:
            current = queue.popleft()
            for old in candidates[current]:
                if old in seen_old:
                    continue
                seen_old.add(old)
                following = new_for_old[old]
                if following is None:
                    free = (current, old)
                    break
                if following not in seen_new:
                    seen_new.add(following)
                    previous[following] = (current, old)
                    queue.append(following)
        while free is not None:
            current, old = free
            old_for_new[current] = old
            new_for_old[old] = current
            free = previous[current]
    return old_for_new

def lis(values):
    tails = []
    for value in values:
        if value is None:
            continue
        index = bisect_left(tails, value)
        if index == len(tails):
            tails.append(value)
        else:
            tails[index] = value
    return len(tails)

summary = dict(graphs_checked=0, changed=0, equal_more=0, equal_less=0, cost_more=0, cost_less=0)
examples = {}
n = 3
for right in permutations(range(n)):
    for mask in range(1 << (n * n)):
        candidates = [[old for old in range(n) if mask & (1 << (new * n + old))] for new in range(n)]
        baseline = match(n, candidates)
        candidate = match(n, [sorted(edges, key=lambda old: old != right[new]) for new, edges in enumerate(candidates)])
        if None in baseline:
            continue
        summary['graphs_checked'] += 1
        if baseline == candidate:
            continue
        summary['changed'] += 1
        baseline_exact = sum(old == value for old, value in zip(baseline, right))
        candidate_exact = sum(old == value for old, value in zip(candidate, right))
        baseline_cost = n - baseline_exact + n - lis(baseline)
        candidate_cost = n - candidate_exact + n - lis(candidate)
        for key, relevant in [('equal_more', candidate_exact > baseline_exact), ('equal_less', candidate_exact < baseline_exact), ('cost_more', candidate_cost > baseline_cost), ('cost_less', candidate_cost < baseline_cost)]:
            if relevant:
                summary[key] += 1
                examples.setdefault(key, dict(right=right, candidates=candidates, before=baseline, after=candidate, exact_before=baseline_exact, exact_after=candidate_exact, operation_cost_before=baseline_cost, operation_cost_after=candidate_cost))
print(json.dumps(dict(summary=summary, examples=examples, scope='matching layer model only, includes right==left permutations bypassed by full library'), indent=2))
