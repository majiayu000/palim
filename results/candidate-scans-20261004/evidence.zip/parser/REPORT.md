# 小 JSON 解析预算：只读诊断，2026-10-03

## 结论与范围

**没有发现可以直接落入 Palim 内部、同时保持既有合同的解析改动。**
Palim 的公开 diff 接收已经拥有的 `serde_json::Value`；JSON bytes→Value 解析发生在调用方。
保持 arbitrary_precision、float_roundtrip 和 Value/数学/原生表示合同，换公开 parse 入口只能
带来这个小输入约3%的有限差异；不是足以消除完整流程差距的内部算法修复。

本报告是 **08f3735ad3d1fe31c0ebe3a6142002ab9251d958 单 snapshot 的 caller 阶段诊断**。
不代表本轮最终新 RFC 候选性能，不是 JS 的新排名；没有修改仓库、Cargo 依赖或 API。
未扩大 parser 选型、引入 adapter/borrowed DOM/SIMD backend、修改数字 flags 或替换 allocator。

## 新鲜实测

冻结同一个30整数小配置，key5从5变99；实际左右 JSON bytes合计649，完整可逆delta28 B。
这些真正输入和输出已分别保存为 raw-left.json/raw-right.json/native-delta.json，含SHA256。
每个阶段3个独立进程，32次预热、9批×2048次，解析和所有相应输出析构都计时。
时间取进程中位数的中位数。System计时二进制与独立allocation feature二进制分开。
每次进程在计时外验证 slice/str输入Value相同、forward/unpatch、固定wire输出。

| 现有调用边界 | μs |
|---|---:|
| 两份 from_slice → native diff → serialize → 析构 | 9.382710 |
| 两份 from_slice + 输入析构 | 7.352234 |
| 已解析输入 native diff + delta析构 | 1.922546 |
| 已有delta serialize + bytes析构 | 0.054281 |
| 已解析输入 diff + serialize + 输出析构 | 1.921977 |
| 两份已有 &str → from_str → diff → serialize | 9.091451 |
| caller 已持有 old Value，只parse新input→diff→serialize | 5.656820 |
| 两份 from_slice → diff → to_writer复用输出Vec | 9.322733 |

原始进程medians和全部batch保存于 timing.json/summary.json，不删样本。
解析/输入析构预算约为完整流程的 **78%**，这只是阶段诊断比例；不同生命周期、allocator/cache
和编译优化意味着阶段medians不能严格相加，也不能把parse-only当成最终pipeline硬下界。
loaded diff目前约1.9μs，delta序列化约0.05μs；继续只改核心diff无法消除已在调用前发生的解析成本。

最新已有 guard-performance 报告的另一组公平竞品完整流程为 Palim9.615μs、JS6.721μs，
已解析输入则为Palim2.008μs、JS5.288μs。这里只引用旧组作为需求背景，不把本报告9.383与旧JS6.721
拼成新倍率。旧Rust/JS runners分别重序列化fixture，对象key顺序可能不同；本次内部诊断保存确切raw bytes，
不声称其字节与全部旧跨语言runner完全一致。

## 分配证据

独立allocation程序统计调用内alloc/realloc新请求尺寸的累计值，结果保留到计数结束。
这**不是峰值 live heap 或 RSS**，没有从累计字节下降推出峰值下降。

| 操作/保留结果 | alloc/realloc调用 | 累计申请 B | 调用内释放 B |
|---|---:|---:|---:|
| parse两份Value | 194 | 9133 | 960 |
| parse新Value | 97 | 4567 | 480 |
| loaded native delta | 20 | 1482 | 139 |
| serialize已有delta | 1 | 128 | 0 |
| 双parse完整pipeline，保留输出bytes | 215 | 10743 | 10615 |
| caller已有old的pipeline，保留输出bytes | 118 | 6177 | 6049 |

scalar探针：普通整数1分配2次/17 B、其中16 B暂存释放；1.0和1.00各2次/32 B；
1e10000为2次/32 B；18446744073709551617为4次/96 B。true无分配，string "number"为1次/6 B。
对应官方release源码与SHA256一起保存在official-sources，保持原许可文件。

## 已核实的原因：官方源码

- [de.rs:938](official-sources/serde_json-1.0.151/src/de.rs)：arbitrary_precision 的每个数字先用
  capacity16 String扫描；普通整数再解析成U64/I64。
- [value/de.rs:43](official-sources/serde_json-1.0.151/src/value/de.rs)与
  [number.rs:745](official-sources/serde_json-1.0.151/src/number.rs)：Value把普通整数转回Number，
  AP Number内部是owned String，因此又format一次并保留。这解释60个整数的960 B短命scanner缓冲。
- [number.rs:503](official-sources/serde_json-1.0.151/src/number.rs)：非整数/大数经NumberFromString再parse，
  不可从Palim的已构造Value接口绕过；不能用f64近似来换速度。
- [value/de.rs:75](official-sources/serde_json-1.0.151/src/value/de.rs)：即使parser暂时借用字符串，
  Value visitor仍创建owned String；对象keys/Map也拥有数据。只换parse入口不能变成borrowed Value。
- [de.rs:2667/2709](official-sources/serde_json-1.0.151/src/de.rs)：from_slice/from_str共享from_trait与数字scanner；
  StrRead能利用已有UTF8保证跳过字符串的重复UTF8检查。该输入上from_str约少3.1%时间，
  适用于caller已经拥有&str；不是新增library配置/API，也不宣称任意JSON都有同等收益。
- [serde_core de/mod.rs:585](official-sources/serde_core-1.0.229/src/de/mod.rs)：deserialize_in_place默认重新
  deserialize然后替换Value。Value没有override；简单换这个入口并不复用Map/Number存储。
- [de.rs:2507/2534](official-sources/serde_json-1.0.151/src/de.rs)：直接管理Deserializer仍做同一解析和end检查；
  from_reader在已内存驻留输入场景官方也说明通常更慢，无需额外reader adapter。

以上为已核实的本地官方release源码，不依赖营销介绍或对另一parser的性能猜测。

## 可用的最小做法与拒绝项

1. **caller复用已有 old Value。** 现有 `DiffPatcher::diff(&old,&new)` 已支持借用。只解析真正新的输入
   实测9.383→5.657μs，累计分配215→118次；旧Value的构造/持有和更新成本在本边界之外。
   这是调用流程选择，不能冒充“两份JSON每次重新解析”基准的胜出或Palim内部提速。
2. caller输入本来就是String/&str时可直接用公开from_str。这组三进程均小幅改善，但仅约0.29μs；
   不为此造新的parse API。bytes需先验证UTF8，额外错误类型/验证边界不能默认为替换serde_json错误合同。
3. 输出buffer复用只有约0.6%差异，样本重叠且序列化预算极小，未认定稳定收益。
   caller本来就有to_writer，不添加新的库层。

进一步减少AP scanner临时String/再次Number构造需要serde_json上游内部改动及完整数值/错误验证；
本轮不修改依赖、不制作兼容adapter或新parser。改变精度features、使用f64重构数字、略过真正解析/验证、
假装输入已解析但仍宣称相同pipeline，均不符合当前任务。也没有研究全局allocator替换。

## 验证、冻结与复现

- 单snapshot release构建成功；timing3独立进程、allocation1独立进程完成。
- fixture两种公开parse入口Value相同；native forward/unpatch和28 B exact wire通过。
- 没有生产修改，所以未重复全suite或建立新的实现镜像测试。
- build-timing.json/build-allocation.json保存实际命令/退出码/完整构建stdout/stderr。
- hashes.json绑定runner、Cargo锁、完整snapshot源码、真正输入/输出、两种二进制以及官方源码；
  timing和allocation二进制不同且各自feature明确，不能把allocation版本计时当纯System结果。

从probe目录：`cargo build --release --locked`，保存target/release/palim-scans-parser-probe为timing；
执行`timing ../fixture.json`三次，再`cargo build --release --locked --features alloc-track`保存allocation，
执行一次。证据包保留精确source/probe/lock/fixture/raw outputs；迁移时只改Cargo.toml中的snapshot路径。
所有阶段数字来自一台macOS arm64短时测量，不是P99、跨机器结果或最终RFC优化器新排名。
