# 公开 JSON 用例：限定本轮扫描优化验证

这里是公开真实文档的形状，右侧变更由本轮构造。它们不是观察到的生产变更，也不能证明已有下游采用 Palim。仅作为现有 diff/guard/压缩行为的 6 个小输入，不新增能力。

| 用途 | 固定来源 | raw source / compact before | 主要检查 |
|---|---|---:|---|
| Infrastructure object change tracking / configuration review | [kubernetes/website/content/en/examples/controllers/nginx-deployment.yaml](https://raw.githubusercontent.com/kubernetes/website/77db41e9c776b614fdb31de4cc6c8e9a70673817/content/en/examples/controllers/nginx-deployment.yaml) | 341 / 319 B | Sparse replicas change is one scalar Replace in a deep but otherwise unchanged document; it checks small candidate-budget rejection overhead. |
| Package metadata comparison / automated release review | [benjamine/jsondiffpatch/packages/jsondiffpatch/package.json](https://raw.githubusercontent.com/benjamine/jsondiffpatch/a60db8a232f92ee4b987c14f43f77402885d1a5a/packages/jsondiffpatch/package.json) | 1491 / 1340 B | Sparse version change is a single string replacement with many unrelated fields; no claim of an actual published next version is made. |
| Project configuration review / saved settings synchronization | [benjamine/jsondiffpatch/tsconfig.json](https://raw.githubusercontent.com/benjamine/jsondiffpatch/a60db8a232f92ee4b987c14f43f77402885d1a5a/tsconfig.json) | 464 / 393 B | A real small boolean-rich compilerOptions object checks one-toggle overhead without a synthetic 30-key integer map. |

## 结构与边界

### kubernetes-deployment

License: CC-BY-4.0；固定原文和许可文件、commit、SHA256见 `source-manifest.json`/`usecases.json`。

- Sparse replicas change is one scalar Replace in a deep but otherwise unchanged document; it checks small candidate-budget rejection overhead.
- Controlled case changes several independent nested objects and one container array element. Slash label keys require JSON Pointer ~1 escaping; no array order-insensitive semantic assumption is made.
- New root status and absent label/imagePullPolicy keys exercise parent snapshots. Any child shortcut must preserve external ancestor snapshot rejection and real fallback.
- This is generic JSON diff verification, not a Kubernetes admission/strategic-merge/apply-conformance assertion. Status is a constructed document field, not an instruction to write it to a cluster.

输入：`fixtures/kubernetes-deployment-sparse.json`, `fixtures/kubernetes-deployment-controlled.json`

### npm-package

License: MIT；固定原文和许可文件、commit、SHA256见 `source-manifest.json`/`usecases.json`。

- Sparse version change is a single string replacement with many unrelated fields; no claim of an actual published next version is made.
- Controlled scripts, devDependencies and exports edits create several independently compressible objects. Existing exports keys contain slash and require JSON Pointer escaping.
- New root private key forces a root parent guard for missing-key Add; child compression cannot reuse a changed root snapshot.
- Manifest strings are inert JSON. No scripts run and no package is published; hypothetical paths/versions are not claimed to exist upstream.

输入：`fixtures/npm-package-sparse.json`, `fixtures/npm-package-controlled.json`

### typescript-config

License: MIT；固定原文和许可文件、commit、SHA256见 `source-manifest.json`/`usecases.json`。

- A real small boolean-rich compilerOptions object checks one-toggle overhead without a synthetic 30-key integer map.
- Controlled multi-option changes can trigger or reject parent compression based on exact serialized size; new compileOnSave root key adds an ancestor parent guard.
- The object arrays include/exclude/types remain unchanged, testing preservation of unrelated branches. JSON scalar types must be preserved.
- This verifies generic JSON settings diff only; it does not execute TypeScript or assert that these hypothetical options are an upstream recommendation.

输入：`fixtures/typescript-config-sparse.json`, `fixtures/typescript-config-controlled.json`

## 验证范围

本 agent 只读取 source、解析和写入 /tmp 数据，检查 JSON 可解析与文件 hash。没有运行 Palim、编译、计时或 benchmark。各 case 与已有 `fixture_runner` 的 name/left/right/tasks 输入结构一致。建议交给 root 的既有冻结 baseline/candidate runner；检验完整 serialized delta/RFC/guards 与正向/逆向，而不是新增业务语义验证。

公开 fixture 原文保留来源和许可证。Kubernetes YAML只做JSON规范化；npm作者/贡献者公开联系方式在实际 fixture 中换成稳定 `.invalid` 占位符。源文件 attribution 保留。

## 额外固定 synthetic control（root指定）

`fixtures/synthetic-after-first-accept-100.json` 不是公开实际文档；它专门控制 after-first-accept 的预算拒绝风险。第一个 `a_first` 对象的 3 个长 key 都改 scalar；之后恰好 100 个 sibling 对象各只改短 key `x`，并保留 200B unchanged padding。共 101 个对象，不扩大 n。验证 optimized 与 guarded 两模式即可。

新增 selection proof 在 serializer budget rejection 前计算，因此可能把原本无需 proof 的 rejected candidates 变贵；这个 fixture 仅定位该具体风险，是否 material 由 root 正式独立过程测量判定。尚未运行 native Palim，实际 parent 接受/拒绝仍由 root 验证。

## 首版扫描候选审查（保留，不代表最终采用）

首版 RFC hash `4f12a321ae4ffda4d41ce9eceb0e36ff9b4a9742a1293c72788f2825c7e0ddb2` 已只读核实，生产 helper/caller 的 proof 与错误合同未发现 correctness blocker。3 个 after-accept golden 覆盖 masked Copy、外部祖先 Add parent guard、array shift，并保留实际正向/逆向断言。已读取 owner 的 private 22 条与 public 2984 条输出，各基线/候选完整文件字节相同；已有 49 focused tests 的日志通过。这些 native 执行来自 performance_lead，我没有重跑。

Root 正式控制发现 ordinary-mode 提前 proof 的性能风险，因此当前首版不作最终采用确认。等待仅 tests=true 融合、tests=false 恢复 lazy proof 的最小修正版冻结，复核 gating 后再给最终 review。完整首版证据见 `review-first-scan.json`。

## 最终修正版只读审查

RFC 已冻结为 `f809c4abf04687374e4493e38b62068b79dc97ec4e04b05695624aa40321a773`，本 reviewer 核实 hash 一致。相对保留的首版，唯一逻辑变化是将 selection 中的 arrays/proof 计算限于 tests=true；tests=false 不调用 ancestor_arrays 或 per-op proof，selection_proof=None，恢复 serializer 预算通过后的 lazy 独立证明。Guarded 安全条件和完整 fallback、root 实际 candidate apply、错误/wire 合同均保留。没有 correctness blocker。

再次只读核对 owner 工件：private22条、public2984条基线/候选完整输出仍字节相同；candidate oracle production-prefix hash 与末版一致。49focused日志仍通过且包含3个after-accept golden分支。native重编译/执行来自 implementation owner/root，本 reviewer 未运行测试、编译或计时。没有宣称普通模式性能已恢复，等待root正式重测。最终单文件审查见 `review.json`。
