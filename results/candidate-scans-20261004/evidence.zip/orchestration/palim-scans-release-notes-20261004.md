## Added since 0.1.0

- `test_json_patch`: execute RFC 6902 Test operations against a borrowed document without cloning the complete document.
- `invert_json_patch_guarded`: generate inverse operations with tests of the values and containers they will touch.

## Fixes and performance

- Fix legal JavaScript text inverse patches with repeated emoji and overlapping NUL/CRLF context; malformed patches remain errors.
- Reduce array matching, scalar copy search, Unicode line scanning and atomic replacement work.
- Reuse exact guarded subtree costs when writes and external authentication reads are proven independent. Keep full simulation for unproven boundaries.
- Remove unused target comparisons for single-operation/root-only guarded compression and combine repeated candidate/proof scans.
- Skip redundant object key lookups when all right-hand keys were already found.

## Verification and limits

The release preserves arbitrary-precision numbers, reversible native deltas and operation errors. See BENCHMARK.md and the attached repository reports for exact workloads, raw samples and validation boundaries.

Performance depends on the input and contract. Candidate processing can still have quadratic costs; small complete JSON pipelines may remain slower than JavaScript. Public configuration documents with controlled edits are verification inputs, not evidence of production adoption. No new parser backend or language bindings were added.
