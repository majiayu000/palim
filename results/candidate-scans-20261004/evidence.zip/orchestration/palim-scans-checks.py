import json, pathlib, re, subprocess, sys, time

repo = pathlib.Path('/Users/apple/Desktop/code/AI/tool/secrets/palim-scans')
group = sys.argv[1]
out = pathlib.Path('/tmp/palim-scans-checks-20261003-' + group + '.json')
groups = {
    'rust': [
        ['cargo', 'fmt', '--check'],
        ['git', 'diff', '--check'],
        ['cargo', 'test', '--locked'],
        ['cargo', 'test', '--release', '--locked'],
        ['cargo', 'clippy', '--all-targets', '--locked', '--', '-D', 'warnings'],
        ['cargo', '+1.85.0', 'check', '--lib', '--locked'],
        ['cargo', 'build', '--release', '--examples', '--locked'],
    ],
    'interop': [
        ['npm', 'ci', '--prefix', 'tools', '--ignore-scripts', '--no-audit', '--no-fund'],
        ['node', 'tools/interop.mjs'],
    ],
    'fuzz': [
        ['cargo', '+nightly', 'fuzz', 'run', 'core', '--', '-max_total_time=60', '-max_len=2048', '-rss_limit_mb=1024', '-seed=20261001'],
    ],
    'package': [['cargo', 'package', '--allow-dirty', '--locked']],
}
records = json.loads(out.read_text()) if out.exists() else []
for command in groups[group]:
    start = time.monotonic()
    result = subprocess.run(command, cwd=repo, capture_output=True, text=True)
    records.append(dict(command=command, exit_code=result.returncode, seconds=time.monotonic()-start, stdout=result.stdout, stderr=result.stderr))
    out.write_text(json.dumps(records, indent=2))
    counts = re.findall(r'test result: ok\. (\d+) passed', result.stdout)
    print(json.dumps(dict(command=command, exit_code=result.returncode, seconds=round(time.monotonic()-start, 2), tests=sum(map(int, counts)) if counts else None)), flush=True)
    if result.returncode:
        print((result.stdout + result.stderr)[-6000:])
        sys.exit(result.returncode)
