import hashlib,json,pathlib,subprocess,zipfile
R=pathlib.Path('/Users/apple/Desktop/code/AI/tool/secrets/palim-scans');O=R/'results/candidate-scans-20261004';e={}
def add(p,n):
 p=pathlib.Path(p)
 if p.is_file():e[n]=p.read_bytes()
def tree(p,n,skip=('target',)):
 p=pathlib.Path(p)
 for f in sorted(p.rglob('*')):
  rel=f.relative_to(p)
  if f.is_file() and not any(x in skip for x in rel.parts):add(f,n+'/'+str(rel))
M=pathlib.Path('/tmp/palim-scans-benchmark-final-v3-20261004');tree(M,'loaded')
for stage,path in [('early-proof','/tmp/palim-scans-benchmark-final-20261004'),('outlined-predicate','/tmp/palim-scans-benchmark-final-v2-20261004')]:
 p=pathlib.Path(path)
 for f in ['measurements.json','summary.json','environment.json']:add(p/f,'stages/'+stage+'/'+f)
 add(p/'sources/candidate/src/rfc.rs','stages/'+stage+'/src-rfc.rs')
F=pathlib.Path('/tmp/palim-scans-rfc-20261003')
for f in F.iterdir():
 if f.is_file():add(f,'rfc/'+f.name)
for directory in ['baseline','candidate-oracle','baseline-driver','candidate-driver','probe','stage-first-4f12','stage-v2-f809']:
 p=F/directory
 if directory.startswith('stage'):
  tree(p,'rfc/'+directory);continue
 for f in ['Cargo.toml','Cargo.lock','README.md']:add(p/f,'rfc/'+directory+'/'+f)
 for d in ['src','examples','benches']:tree(p/d,'rfc/'+directory+'/'+d)
P=pathlib.Path('/tmp/palim-scans-parser-20261003');add(P/'evidence.zip','parser/evidence.zip');add(P/'REPORT.md','parser/REPORT.md');add(P/'hashes.json','parser/hashes.json')
tree('/tmp/palim-scans-usecases-20261003','usecases')
for f in ['Cargo.toml','Cargo.lock','README.md','BENCHMARK.md','DESIGN.md','LICENSE']:add(R/f,'candidate/'+f)
for d in ['src','tests','examples','benches']:tree(R/d,'candidate/'+d)
for f in ['Cargo.toml','Cargo.lock','fuzz_targets/core.rs']:add(R/'fuzz'/f,'candidate/fuzz/'+f)
for f in ['interop.mjs','package.json','package-lock.json','remaining-hotspots.py']:add(R/'tools'/f,'candidate/tools/'+f)
for f in ['Cargo.toml','Cargo.lock','src/main.rs']:add(pathlib.Path('/tmp/palim-scans-consumer-20261003')/f,'consumer/'+f)
for f in ['palim-scans-benchmark.py','palim-scans-checks.py','palim-scans-artifacts.py','palim-scans-report.py','palim-scans-archive.py','palim-scans-start-20261003.json','palim-scans-plan-20261003.txt','palim-scans-package-consumer-20261004.json','palim-scans-release-notes-20261004.md']:add(pathlib.Path('/tmp')/f,'orchestration/'+f)
for f in ['REPORT.md','checks.json','measurements.json']:add(O/f,'final/'+f)
add(R/'target/package/palim-0.1.1.crate','package/local-candidate-0.1.1.crate')
for f in ['differ.go','LICENSE']:add(pathlib.Path('/Users/apple/go/pkg/mod/github.com/w!i2!l/jsondiff@v0.7.1')/f,'prior-art/go-jsondiff-v0.7.1/'+f)
e['task.patch']=subprocess.check_output(['git','diff','--','src/rfc.rs','Cargo.toml','Cargo.lock','fuzz/Cargo.lock','BENCHMARK.md','DESIGN.md'],cwd=R)
manifest={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in sorted(e.items())};e['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(O/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(e.items()):z.writestr(n,b)
with zipfile.ZipFile(O/'evidence.zip') as z:
 assert z.testzip() is None;assert all(hashlib.sha256(z.read(k)).hexdigest()==v['sha256'] for k,v in manifest.items())
print(json.dumps(dict(entries=len(e),bytes=(O/'evidence.zip').stat().st_size,manifest_verified=True,archive_sha256=hashlib.sha256((O/'evidence.zip').read_bytes()).hexdigest()),indent=2))
