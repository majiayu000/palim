import hashlib,json,pathlib,re,zipfile
R=pathlib.Path('/Users/apple/Desktop/code/AI/tool/secrets/palim-scans');O=R/'results/candidate-scans-20261004'
M=pathlib.Path('/tmp/palim-scans-benchmark-final-v3-20261004');F=pathlib.Path('/tmp/palim-scans-rfc-20261003');P=pathlib.Path('/tmp/palim-scans-parser-20261003');U=pathlib.Path('/tmp/palim-scans-usecases-20261003')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def build():
 O.mkdir(exist_ok=False)
 source={str(f.relative_to(R)):sha(f) for f in sorted((R/'src').glob('*.rs'))}
 env=read(M/'environment.json');raw=read(M/'measurements.json');summary=read(M/'summary.json')
 for f,h in source.items():assert env['source']['candidate']['hashes'][f]==h
 assert len(raw)==len(summary)*12 and all(x['identical_output'] for x in summary)
 assert all(x['roundtrip_verified'] for x in raw)
 measurements=dict(baseline='08f3735ad3d1fe31c0ebe3a6142002ab9251d958',candidate_identity='source and binary hashes; HEAD during timing is not identity',source_sha256=source,loaded=dict(environment=env,summary=summary,records=raw),parser_diagnosis=dict(baseline='08f3735',summary=read(P/'summary.json'),boundary='Single baseline snapshot caller-side phases, not new candidate or JS rankings'),usecases=read(U/'usecases.json'))
 measurements['rejected_stages'] = {name:read(pathlib.Path(path)/'summary.json') for name,path in [('all_mode_early_proof','/tmp/palim-scans-benchmark-final-20261004'),('guarded_only_outlined_predicate','/tmp/palim-scans-benchmark-final-v2-20261004')]}
 (O/'measurements.json').write_text(json.dumps(measurements,ensure_ascii=False,indent=2)+'\n')
 checks={k:read(pathlib.Path('/tmp/palim-scans-checks-20261003-'+k+'.json')) for k in ['rust','interop','fuzz','package']}
 assert all(x['exit_code']==0 for a in checks.values() for x in a)
 consumer=read(pathlib.Path('/tmp/palim-scans-package-consumer-20261004.json'));assert consumer['exit_code']==0
 for f,h in source.items():assert consumer['hashes'][str(R/'target/package/palim-0.1.1'/f)]==h
 checks.update(package_consumer=consumer,source_sha256=source,notes=['Production source hashes match timing snapshot and unpacked package.','Remote cross-OS CI and crate publication occur after this local snapshot.','Parser experiments belong to 08f3735 and change caller boundary when retaining old Value.'])
 (O/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
 return source,summary,checks
if __name__=='__main__':
 source,summary,checks=build();print(json.dumps({'source':source,'measurements':len(summary)*12,'cases':len(summary)},indent=2))
