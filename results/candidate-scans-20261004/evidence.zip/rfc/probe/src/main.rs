use serde_json::{Value,json};
use palim::{DiffPatcher,JsonPatchOptions};
fn main(){let opts=JsonPatchOptions{factorize:false,rationalize:true,tests:true};
 let f:Value=serde_json::from_str(include_str!("/tmp/palim-scans-rfc-20261003/small.json")).unwrap();
 for (name,a,b,n) in std::iter::once(("small".to_owned(),f["left"].clone(),f["right"].clone(),10000)).chain([100,400,800].into_iter().map(|rows|{let a=json!((0..rows).map(|i|json!({"id":i,"a_long_property_name":i,"b_long_property_name":i,"c_long_property_name":i})).collect::<Vec<_>>());let b=json!((0..rows).map(|i|json!({"id":i,"a_long_property_name":i+100000,"b_long_property_name":i+200000,"c_long_property_name":i+300000})).collect::<Vec<_>>());(rows.to_string(),a,b,1)})){
 palim::__profile_reset();let start=std::time::Instant::now();let mut out=None;for _ in 0..n{out=Some(DiffPatcher::default().diff_json_patch(&a,&b,&opts).unwrap());}let p=out.unwrap();assert_eq!(palim::apply_json_patch(&a,&p).unwrap(),b);println!("{}",json!({"case":name,"iterations":n,"total_us":start.elapsed().as_secs_f64()*1e6/n as f64,"stage_ns":palim::__profile_read().map(|v|v/n as u64),"bytes":serde_json::to_vec(&p).unwrap().len()}));
 }}