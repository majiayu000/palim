from pathlib import Path
import subprocess,json,re
root=Path(__file__).parent
repo=Path('/Users/apple/Desktop/code/AI/tool/secrets/palim')
commands=[['cargo','fmt','--check'],['cargo','test','--locked'],['cargo','test','--release','--locked'],['cargo','clippy','--all-targets','--locked','--','-D','warnings'],['cargo','+1.85.0','check','--lib','--locked'],['cargo','build','--release','--example','fixture_runner','--locked'],['node','tools/interop.mjs'],['cargo','+nightly','fuzz','run','core','--','-max_total_time=60','-max_len=2048','-rss_limit_mb=1024','-seed=20261001']]
records=[]
for index,command in enumerate(commands):
 p=subprocess.run(command,cwd=repo,capture_output=True,text=True)
 log=root/('check-%02d.log'%index);log.write_text(p.stdout+p.stderr)
 records.append(dict(command=command,exit_code=p.returncode,log=log.name))
 (root/'checks.json').write_text(json.dumps(records,indent=2)+'\n')
 print(index,' '.join(command),p.returncode,flush=True)
 if p.returncode:
  print((p.stdout+p.stderr)[-5500:],flush=True);raise SystemExit(p.returncode)
 print((p.stdout+p.stderr)[-450:],flush=True)
