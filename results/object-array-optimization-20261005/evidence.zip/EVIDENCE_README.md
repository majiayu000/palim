# Palim object/array optimization evidence

Baseline is the dirty task-start 0.1.4 checkout, including the previous typed guard improvement. Candidate adds direct object RFC generation and the consecutive array insertion guard-cost cache. See measurements/environment.json for source and fixture fingerprints.

Every timing process independently applies its RFC output with json-patch and checks that Palim's inverse restores the baseline. Baseline and candidate wire hashes must match for each measured case. Rust json-patch 4.2.0 is measured again only for the two plain object cases, with the same parsed Values/precision features and same compact serialized patches.

Timing binaries are uninstrumented. Allocation binaries measure requested System allocator bytes/calls and peak additional live bytes above already parsed inputs; they do not measure RSS. One instrumented generation per case is a structural count, not a timing sample.

Run `python3 rebuild.py --replay-small` to verify payload hashes, rebuild both probes and replay the small fixture against archived hashes. Run `python3 run-benchmarks.py` for all 114 timing records and ten allocation probes (several minutes). It writes results to measurements/. Frozen oracle sources contain test-only hooks; `python3 oracle/run.py` replays 3,305 differential records. Project CI commands/logs are in checks.json and check-*.log; run-checks.py names the original workspace and should be adapted if rerunning them in another checkout.

No cross-machine, tail latency, concurrency, or universal fastest-library claim is made. Results are warm measurements from one Apple M2 Max machine.
