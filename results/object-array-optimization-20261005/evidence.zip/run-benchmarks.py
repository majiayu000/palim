from pathlib import Path
import subprocess,json,statistics,hashlib,platform,time
root=Path(__file__).resolve().parent
out=root/'measurements';out.mkdir(exist_ok=True)
fixtures=root/'fixtures'
def dump(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def binary(label):return root/('probe-'+label)/'target/release/palim-scale-competitor-probe'
commands=[['sw_vers'],['sysctl','-n','machdep.cpu.brand_string'],['sysctl','-n','hw.memsize'],['rustc','-Vv']]
environment={ 'platform':platform.platform(),'utc_started':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'commands':[{'command':c,'output':subprocess.check_output(c,text=True).strip()} for c in commands], 'fixtures':{p.name:sha(p) for p in fixtures.glob('*.json')},'source_hashes':{label:{str(p.relative_to(root/label)):sha(p) for p in (root/label).rglob('*') if p.is_file()} for label in ['baseline','candidate']},'probe_hashes':{label:{p.name:sha(p) for p in (root/('probe-'+label)/'src').glob('*.rs')} for label in ['baseline','candidate']}}
dump(out/'environment.json',environment)
cases=[('small-config-edit','plain'),('scalar-guards-2000','plain'),('scalar-guards-10000','plain'),('scalar-guards-100000','plain'),('scalar-guards-100000','plain-guarded'),('scalar-guards-100000','optimized'),('file_migrations_move_copy_5000','plain'),('file_migrations_move_copy_5000','optimized'),('file_migrations_move_copy_5000','guarded'),('disjoint-2000','guarded'),('disjoint-10000','guarded'),('disjoint-20000','guarded'),('disjoint-20000','optimized'),('rotate-2000','plain'),('rotate-1000000','plain'),('unchanged-100000','plain'),('unchanged-100000','plain-guarded'),('mixed-array-last-100000','plain')]
records=[]
for repeat in range(3):
 for name,mode in cases:
  for label in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
   start=time.monotonic()
   row=json.loads(subprocess.check_output([str(binary(label)),mode,str(fixtures/(name+'.json'))],timeout=240))
   wire=row.pop('wire');digest=hashlib.sha256(wire.encode()).hexdigest();p=out/('wire-'+digest+'.json')
   if not p.exists():p.write_text(wire)
   row.update(case=name,label=label,mode=mode,repeat=repeat,wall_seconds=time.monotonic()-start,wire_sha256=digest)
   for metric in ['core','pipeline']:row[metric+'_ms']=statistics.median(row[metric+'_samples_ms'])
   records.append(row);dump(out/'records.json',records)
   print(repeat+1,name,label,mode,'core',round(row['core_ms'],3),'pipeline',round(row['pipeline_ms'],3),flush=True)
 for name in ['scalar-guards-100000','file_migrations_move_copy_5000']:
  row=json.loads(subprocess.check_output([str(binary('candidate')),'json-patch',str(fixtures/(name+'.json'))],timeout=240))
  wire=row.pop('wire');digest=hashlib.sha256(wire.encode()).hexdigest();p=out/('wire-'+digest+'.json')
  if not p.exists():p.write_text(wire)
  row.update(case=name,label='rust-json-patch',mode='plain',repeat=repeat,wire_sha256=digest)
  for metric in ['core','pipeline']:row[metric+'_ms']=statistics.median(row[metric+'_samples_ms'])
  records.append(row);dump(out/'records.json',records)
  print(repeat+1,name,'rust-json-patch','core',round(row['core_ms'],3),'pipeline',round(row['pipeline_ms'],3),flush=True)
summary=[]
for name,mode in cases:
 rows=[]
 for label in ['baseline','candidate']+(['rust-json-patch'] if mode=='plain' and name in ['scalar-guards-100000','file_migrations_move_copy_5000'] else []):
  group=[r for r in records if (r['case'],r['mode'],r['label'])==(name,mode,label)]
  assert len(group)==3 and all(r['self_verified'] for r in group)
  assert len({r['wire_sha256'] for r in group})==1
  row={k:group[0][k] for k in ['case','mode','label','wire_sha256','wire_bytes','operations','operation_counts']}
  for metric in ['core','pipeline']:
   medians=[r[metric+'_ms'] for r in group];row[metric+'_process_medians_ms']=medians;row[metric+'_ms']=statistics.median(medians)
  rows.append(row);summary.append(row)
 assert len({r['wire_sha256'] for r in rows})==1,(name,mode,'wire differs')
dump(out/'summary.json',summary)
allocations=[]
for name,mode in [('scalar-guards-100000','plain'),('scalar-guards-100000','plain-guarded'),('file_migrations_move_copy_5000','plain'),('disjoint-20000','guarded'),('mixed-array-last-100000','plain')]:
 for label in ['baseline','candidate']:
  exe=root/('probe-'+label)/'target/release/allocation'
  row=json.loads(subprocess.check_output([str(exe),str(fixtures/(name+'.json')),mode],timeout=240))
  wire=row.pop('wire');row.update(case=name,label=label,wire_sha256=hashlib.sha256(wire.encode()).hexdigest())
  assert row['allocation']['final_live_delta_bytes']==0
  allocations.append(row);dump(out/'allocations.json',allocations)
  print('allocation',name,label,mode,row['allocation'],flush=True)
print('COMPLETE',len(summary),'combinations',len(records),'timing records',len(allocations),'allocation records',flush=True)
