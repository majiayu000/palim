from pathlib import Path
import subprocess,json,hashlib,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for name,digest in manifest.items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for label in ['baseline','candidate']:
 subprocess.run(['cargo','build','--release','--locked','--manifest-path',str(root/('probe-'+label)/'Cargo.toml')],check=True)
print('Verified all evidence hashes and rebuilt both probes')
if '--replay-small' in sys.argv:
 for label in ['baseline','candidate']:
  exe=root/('probe-'+label)/'target/release/palim-scale-competitor-probe'
  result=json.loads(subprocess.check_output([str(exe),'plain',str(root/'fixtures/small-config-edit.json')]))
  expected=next(row for row in json.loads((root/'measurements/summary.json').read_text()) if (row['case'],row['label'],row['mode'])==('small-config-edit',label,'plain'))
  assert hashlib.sha256(result['wire'].encode()).hexdigest()==expected['wire_sha256']
  assert result['self_verified']
 print('Small fixture forward/inverse replay matches archived wire hashes')
