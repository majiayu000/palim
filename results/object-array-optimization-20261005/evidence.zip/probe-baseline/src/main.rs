use palim::{Delta,DiffOptions,DiffPatcher,JsonPatchOptions,Patch};
use serde_json::{Value,json};
use std::{collections::BTreeMap,error::Error,fs,hint::black_box,sync::Arc,time::Instant};
type Result<T>=std::result::Result<T,Box<dyn Error>>;
enum Output{Native(Option<Delta>),Standard(Patch)}
fn generate(dp:&DiffPatcher,a:&Value,b:&Value,mode:&str)->Result<Output>{
 Ok(if mode=="json-patch"{Output::Standard(json_patch::diff(a,b))}
 else if mode=="native"{Output::Native(dp.diff(a,b)?)}
 else{Output::Standard(dp.diff_json_patch(a,b,&JsonPatchOptions{
  factorize:!mode.starts_with("plain"),rationalize:!mode.starts_with("plain"),tests:mode.ends_with("guarded")})?)})
}
fn wire(output:&Output)->Result<Vec<u8>>{Ok(match output{Output::Native(v)=>serde_json::to_vec(v)?,Output::Standard(v)=>serde_json::to_vec(v)?})}
fn verify(a:&Value,b:&Value,patch:&Patch)->Result<()>{
 let mut applied=a.clone();json_patch::patch(&mut applied,patch)?;assert_eq!(applied,*b);
 let inverse=palim::invert_json_patch(a,patch)?;json_patch::patch(&mut applied,&inverse)?;assert_eq!(applied,*a);Ok(())
}
fn measure<T>(work:impl Fn()->Result<T>)->Result<(Vec<f64>,usize)>{
 for _ in 0..3{black_box(work()?);}
 let mut iterations=1;
 loop{let started=Instant::now();for _ in 0..iterations{black_box(work()?);}if started.elapsed().as_secs_f64()>=0.01||iterations>=2048{break;}iterations*=2;}
 let mut samples=Vec::new();for _ in 0..9{let started=Instant::now();for _ in 0..iterations{black_box(work()?);}samples.push(started.elapsed().as_secs_f64()*1000./iterations as f64);}Ok((samples,iterations))
}
fn main()->Result<()>{
 let args:Vec<_>=std::env::args().collect();let fixture:Value=serde_json::from_slice(&fs::read(&args[2])?)?;
 let (a,b)=(&fixture["left"],&fixture["right"]);
 if args[1]=="verify"{
  let patch:Patch=serde_json::from_slice(&fs::read(&args[3])?)?;verify(a,b,&patch)?;
  let has_tests=patch.0.iter().any(|op|matches!(op,palim::PatchOperation::Test(_)));
  let mut drift=Value::Null;
  if has_tests{
   let mut altered=a.clone();
   if let Some(array)=altered.as_array_mut(){array.push(json!("unexpected-added-element"));}
   else if let Some(fields)=altered.get_mut("fields").and_then(Value::as_object_mut){fields.insert("unexpected-added-key".into(),json!(999));}
   else if let Some(notes)=altered.get_mut("unchanged_notes"){*notes=json!("unexpected unrelated drift");}
   let rejected=json_patch::patch(&mut altered,&patch).is_err();drift=json!(rejected);
  }
  println!("{}",json!({"forward_verified":true,"inverse_verified_with_palim":true,"unrelated_or_parent_drift_rejected":drift}));return Ok(());
 }
 let left_raw=fixture["left_raw"].as_str().ok_or("missing raw left")?.as_bytes();let right_raw=fixture["right_raw"].as_str().ok_or("missing raw right")?.as_bytes();
 assert_eq!(serde_json::from_slice::<Value>(left_raw)?,*a);assert_eq!(serde_json::from_slice::<Value>(right_raw)?,*b);
 let dp=DiffPatcher::new(DiffOptions{object_hash:Some(Arc::new(|v,_|v.get("id").map(Value::to_string))),..Default::default()});
 let mode=&args[1];let initial=generate(&dp,a,b,mode)?;let raw=wire(&initial)?;
 let mut counts=BTreeMap::<&str,usize>::new();let operations=match &initial{
  Output::Native(Some(d))=>{assert_eq!(palim::patch(a,d)?,*b);assert_eq!(palim::patch(b,&palim::reverse(d)?)?,*a);None},
  Output::Native(None)=>{assert_eq!(a,b);None},
  Output::Standard(p)=>{verify(a,b,p)?;for op in &p.0{let key=match op{palim::PatchOperation::Add(_)=>"add",palim::PatchOperation::Remove(_)=>"remove",palim::PatchOperation::Replace(_)=>"replace",palim::PatchOperation::Move(_)=>"move",palim::PatchOperation::Copy(_)=>"copy",palim::PatchOperation::Test(_)=>"test"};*counts.entry(key).or_default()+=1;}Some(p.0.len())}
 };drop(initial);
 let (core,core_iterations)=measure(||generate(&dp,a,b,mode))?;
 let (pipeline,pipeline_iterations)=measure(||{
  let left:Value=serde_json::from_slice(left_raw)?;let right:Value=serde_json::from_slice(right_raw)?;wire(&generate(&dp,&left,&right,mode)?)
 })?;
 println!("{}",json!({"case":fixture["name"],"engine":format!("palim-{mode}"),"core_samples_ms":core,"pipeline_samples_ms":pipeline,"core_iterations":core_iterations,"pipeline_iterations":pipeline_iterations,"wire_bytes":raw.len(),"wire":String::from_utf8(raw)?,"operations":operations,"operation_counts":counts,"self_verified":true}));Ok(())
}
