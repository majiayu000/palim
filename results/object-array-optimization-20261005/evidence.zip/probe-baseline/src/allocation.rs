mod counter {
use std::alloc::{GlobalAlloc,Layout,System};
use std::sync::atomic::{AtomicBool,AtomicIsize,AtomicUsize,Ordering::Relaxed};
use serde_json::{Value,json};
pub const ENABLED:bool=true;
static LIVE:AtomicIsize=AtomicIsize::new(0);
static PEAK:AtomicIsize=AtomicIsize::new(0);
static ACTIVE:AtomicBool=AtomicBool::new(false);
static CALLS:AtomicUsize=AtomicUsize::new(0);
static BYTES:AtomicUsize=AtomicUsize::new(0);
struct Counted;
fn allocated(size:usize) {
    let live=LIVE.fetch_add(size as isize,Relaxed)+size as isize;
    if ACTIVE.load(Relaxed) {
        CALLS.fetch_add(1,Relaxed);BYTES.fetch_add(size,Relaxed);PEAK.fetch_max(live,Relaxed);
    }
}
// This benchmark forwards the original pointer/Layout unchanged to System.
// Statistics never alter allocation success, ownership, size or alignment.
unsafe impl GlobalAlloc for Counted {
    unsafe fn alloc(&self,layout:Layout)->*mut u8 {
        let pointer=unsafe {System.alloc(layout)};
        if !pointer.is_null(){allocated(layout.size());}
        pointer
    }
    unsafe fn alloc_zeroed(&self,layout:Layout)->*mut u8 {
        let pointer=unsafe {System.alloc_zeroed(layout)};
        if !pointer.is_null(){allocated(layout.size());}
        pointer
    }
    unsafe fn dealloc(&self,pointer:*mut u8,layout:Layout) {
        unsafe {System.dealloc(pointer,layout)};
        LIVE.fetch_sub(layout.size() as isize,Relaxed);
    }
    unsafe fn realloc(&self,pointer:*mut u8,layout:Layout,size:usize)->*mut u8 {
        let resized=unsafe {System.realloc(pointer,layout,size)};
        if !resized.is_null(){LIVE.fetch_sub(layout.size() as isize,Relaxed);allocated(size);}
        resized
    }
}
#[global_allocator] static ALLOCATOR:Counted=Counted;
pub fn begin()->isize {
    let mark=LIVE.load(Relaxed);PEAK.store(mark,Relaxed);
    CALLS.store(0,Relaxed);BYTES.store(0,Relaxed);ACTIVE.store(true,Relaxed);mark
}
pub fn finish(mark:isize)->Value {
    ACTIVE.store(false,Relaxed);
    let calls=CALLS.load(Relaxed);
    let bytes=BYTES.load(Relaxed);
    let peak=PEAK.load(Relaxed)-mark;
    let remaining=LIVE.load(Relaxed)-mark;
    json!({"allocation_or_reallocation_calls":calls,
        "requested_bytes":bytes,"peak_additional_live_bytes":peak,
        "final_live_delta_bytes":remaining})
}
}

use palim::{Delta,DiffOptions,DiffPatcher,JsonPatchOptions,Patch};
use serde_json::{Value,json};
use std::{error::Error,fs,hint::black_box,sync::Arc,time::Instant};
type Result<T> = std::result::Result<T,Box<dyn Error>>;
enum Output { Native(Option<Delta>), Standard(Patch) }
fn generate(dp:&DiffPatcher,a:&Value,b:&Value,mode:&str,original:&Patch)->Result<Output> {
    Ok(if mode=="inverse" {Output::Standard(palim::invert_json_patch(a,original)?)}
    else if mode=="inverse-guarded" {Output::Standard(palim::invert_json_patch_guarded(a,original)?)}
    else if mode=="native" || mode=="pipeline-native" || mode=="retained-old-pipeline" { Output::Native(dp.diff(a,b)?) } else {
        Output::Standard(dp.diff_json_patch(a,b,&JsonPatchOptions {
            factorize:!mode.starts_with("plain"),rationalize:!mode.starts_with("factorize")&&!mode.starts_with("plain"),tests:mode.ends_with("guarded")
        })?)
    })
}
fn main()->Result<()> {
    let args:Vec<_>=std::env::args().collect();
    let fixture:Value=serde_json::from_slice(&fs::read(&args[1])?)?;
    let mode=&args[2];
    let original:Patch=fixture.get("patch").map(|v|serde_json::from_value(v.clone())).transpose()?.unwrap_or(Patch(Vec::new()));
    let (a,b)=(&fixture["left"],&fixture["right"]);
    let dp=DiffPatcher::new(DiffOptions {
        object_hash:Some(Arc::new(|v,_|v.get("id").map(Value::to_string))),
        ..Default::default()
    });
    let initial=generate(&dp,a,b,mode,&original)?;
    let (wire,operations)=match &initial {
        Output::Native(Some(delta))=>{
            assert_eq!(palim::patch(a,delta)?,*b);
            assert_eq!(palim::patch(b,&palim::reverse(delta)?)?,*a);
            (serde_json::to_vec(delta)?,None)
        },
        Output::Native(None)=>{assert_eq!(a,b);(b"null".to_vec(),None)},
        Output::Standard(patch)=>{
            let (source,target)=if mode.starts_with("inverse") {(b,a)} else {(a,b)};
            let mut result=source.clone();json_patch::patch(&mut result,patch)?;assert_eq!(result,*target);
            let inverse=palim::invert_json_patch(source,patch)?;
            json_patch::patch(&mut result,&inverse)?;assert_eq!(result,*source);
            (serde_json::to_vec(patch)?,Some(patch.0.len()))
        },
    };

    if mode=="pipeline-native" || mode=="retained-old-pipeline" {
        let left_bytes=fixture["left_raw"].as_str().unwrap().as_bytes();
        let right_bytes=fixture["right_raw"].as_str().unwrap().as_bytes();
        assert_eq!(serde_json::from_slice::<Value>(left_bytes)?,*a);
        assert_eq!(serde_json::from_slice::<Value>(right_bytes)?,*b);
        let work=||->Result<Vec<u8>> {
            let parsed_left:Option<Value>=if mode=="pipeline-native" {
                Some(serde_json::from_slice(left_bytes)?)
            } else {None};
            let left=parsed_left.as_ref().unwrap_or(a);
            let right:Value=serde_json::from_slice(right_bytes)?;
            let delta=dp.diff(left,&right)?;
            Ok(serde_json::to_vec(&delta)?)
        };
        assert_eq!(work()?,wire);
        drop(initial);
        for _ in 0..3 {black_box(work()?);}
        let mut samples=Vec::new();let mut iterations=1;
        if !counter::ENABLED {
            loop {
                let start=Instant::now();
                for _ in 0..iterations {black_box(work()?);}
                if start.elapsed().as_secs_f64()>=0.01||iterations>=2048 {break;}
                iterations*=2;
            }
            for _ in 0..9 {
                let start=Instant::now();
                for _ in 0..iterations {black_box(work()?);}
                samples.push(start.elapsed().as_secs_f64()*1000.0/iterations as f64);
            }
        }
        let allocation=if counter::ENABLED {
            let mark=counter::begin();let output=work()?;black_box(&output);drop(output);
            Some(counter::finish(mark))
        } else {None};
        println!("{}",json!({"case":fixture["name"],"mode":mode,"samples_ms":samples,
            "iterations":iterations,"allocation":allocation,"wire_bytes":wire.len(),
            "operations":operations,"wire":String::from_utf8(wire)?,"roundtrip_verified":true,
            "input_bytes":left_bytes.len()+right_bytes.len()}));
        return Ok(());
    }
    drop(initial);
    for _ in 0..3 { black_box(generate(&dp,a,b,mode,&original)?); }
    let mut samples=Vec::new();
    let mut iterations=1;
    if !counter::ENABLED {
        loop {
            let start=Instant::now();
            for _ in 0..iterations { black_box(generate(&dp,a,b,mode,&original)?); }
            if start.elapsed().as_secs_f64()>=0.01||iterations>=2048 {break;}
            iterations*=2;
        }
        for _ in 0..9 {
            let start=Instant::now();
            for _ in 0..iterations { black_box(generate(&dp,a,b,mode,&original)?); }
            samples.push(start.elapsed().as_secs_f64()*1000.0/iterations as f64);
        }
    }
    let allocation=if counter::ENABLED {
        let mark=counter::begin();
        let generated=generate(&dp,a,b,mode,&original)?;
        black_box(&generated);
        drop(generated);
        Some(counter::finish(mark))
    } else {None};
    println!("{}",json!({"case":fixture["name"],"mode":mode,
        "samples_ms":samples,"iterations":iterations,"allocation":allocation,
        "wire_bytes":wire.len(),"operations":operations,
        "wire":String::from_utf8(wire)?,"roundtrip_verified":true}));
    Ok(())
}
