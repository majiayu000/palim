use serde_json::{Value,json};
use palim::{DiffPatcher,DiffOptions,JsonPatchOptions};
use std::sync::Arc;
fn main(){let dp=DiffPatcher::new(DiffOptions{object_hash:Some(Arc::new(|v,_|v.get("id").map(Value::to_string))),..Default::default()});
 for n in [100,400,800]{for tests in [false,true]{
 let a=json!((0..n).map(|i|json!({"id":i,"a_long_property_name":i,"b_long_property_name":i,"c_long_property_name":i})).collect::<Vec<_>>());
 let b=json!((0..n).map(|i|json!({"id":i,"a_long_property_name":i+100000,"b_long_property_name":i+200000,"c_long_property_name":i+300000})).collect::<Vec<_>>());
 let opts=JsonPatchOptions{factorize:true,rationalize:true,tests};
 palim::__profile_reset();let start=std::time::Instant::now();let p=dp.diff_json_patch(&a,&b,&opts).unwrap();let elapsed=start.elapsed().as_secs_f64()*1e3;
 let counts=palim::__profile_read();assert_eq!(palim::apply_json_patch(&a,&p).unwrap(),b);
 let inv=palim::invert_json_patch(&a,&p).unwrap();assert_eq!(palim::apply_json_patch(&b,&inv).unwrap(),a);
 println!("{}",json!({"parents":n,"tests":tests,"total_ms":elapsed,"stages":counts,"operations":p.0.len(),"wire_bytes":serde_json::to_vec(&p).unwrap().len()}));
 }}}
