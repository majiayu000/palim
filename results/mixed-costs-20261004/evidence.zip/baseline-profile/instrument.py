from pathlib import Path
import json,difflib,hashlib
p=Path('/tmp/palim-mixed-profile-20261004'); source=p/'baseline/src/rfc.rs'; original=source.read_text()
labels=['factor_total_ns','factor_move_iterations','factor_remove_replay_operations','factor_move_pairs','factor_candidate_cloned_operations','factor_move_candidate_apply_calls','factor_move_candidate_apply_slots','factor_move_accepted','factor_copy_search_calls','factor_copy_accepted','factor_copy_shadow_apply_operations','find_copy_nodes','collect_scalar_nodes','factor_move_phase_ns','factor_copy_phase_ns','rationalize_total_ns','parent_candidates','viable_candidates','accepted_candidates','selection_scan_slots','selected_slots','guard_sim_calls','guard_sim_apply_operations','guard_sim_test_values','guard_prefix_rebuild_calls','guard_prefix_rebuild_slots','candidate_apply_calls','candidate_apply_operations','accepted_compact_slots','initial_guard_ns','selection_ns','guard_proof_ns','candidate_cost_ns','candidate_validation_ns','accepted_compact_ns','guard_sim_ns','guard_prefix_rebuild_ns','candidate_apply_ns','final_guard_apply_operations','final_guard_test_values']
for phase in ['raw','factorized','rationalized']:
 labels += [phase+'_'+op for op in ['add','remove','replace','move','copy','test']]
labels += ['factor_candidate_payload_clone_slots','factor_candidate_payload_owned_utf8_bytes']
assert len(labels)==60
header='''const __PROFILE_LABELS: [&str; 60] = %s;
static __PROFILE: [std::sync::atomic::AtomicU64; 60] = [const {std::sync::atomic::AtomicU64::new(0)}; 60];
pub fn __profile_reset() { for slot in &__PROFILE {slot.store(0,std::sync::atomic::Ordering::Relaxed);} }
pub fn __profile_read() -> Vec<(&'static str,u64)> {__PROFILE_LABELS.iter().enumerate().map(|(i,&key)|(key,__PROFILE[i].load(std::sync::atomic::Ordering::Relaxed))).collect()}
fn __profile_add(slot: usize, value: u64) {__PROFILE[slot].fetch_add(value,std::sync::atomic::Ordering::Relaxed);}
struct __ProfileTimer(usize,std::time::Instant);
impl __ProfileTimer {fn new(slot:usize)->Self{Self(slot,std::time::Instant::now())}}
impl Drop for __ProfileTimer {fn drop(&mut self){__profile_add(self.0,self.1.elapsed().as_nanos() as u64)}}
fn __profile_hist(patch:&Patch,first:usize) {for op in &patch.0 {let i=match op {PatchOperation::Add(_)=>0,PatchOperation::Remove(_)=>1,PatchOperation::Replace(_)=>2,PatchOperation::Move(_)=>3,PatchOperation::Copy(_)=>4,PatchOperation::Test(_)=>5};__profile_add(first+i,1);}}
'''%json.dumps(labels)
header += '''fn __payload_owned_utf8_bytes(value:&Value)->usize{match value {Value::String(s)=>s.len(),Value::Array(v)=>v.iter().map(__payload_owned_utf8_bytes).sum(),Value::Object(m)=>m.iter().map(|(k,v)|k.len()+__payload_owned_utf8_bytes(v)).sum(),_=>0}}
'''
s=original

def repl(s,a,b):
 assert s.count(a)==1,(a[:80],s.count(a)); return s.replace(a,b,1)
# operation histogram through actual optimize pipeline
s=repl(s,') -> Result<Patch, Error> {\n    if options.factorize {',') -> Result<Patch, Error> {\n    __profile_hist(&patch,40);\n    if options.factorize {')
s=repl(s,'    if options.rationalize {\n        patch = rationalize','    __profile_hist(&patch,46);\n    if options.rationalize {\n        patch = rationalize')
s=repl(s,'    if options.tests {\n        patch = guard','    __profile_hist(&patch,52);\n    if options.tests {\n        patch = guard')
# independent function regions
start=s.index('fn factorize('); end=s.index('\n#[derive(Hash',start); f=s[start:end]
f=repl(f,'-> Result<Patch, Error> {\n','-> Result<Patch, Error> {\n    let _total=__ProfileTimer::new(0);\n    let move_timer=__ProfileTimer::new(13);\n')
f=repl(f,'    {\n        let mut shadow = left.clone();','    {\n        __profile_add(1,1);\n        __profile_add(2,patch.0.len() as u64);\n        let mut shadow = left.clone();')
f=repl(f,'            for (remove_index, source) in sources {','            for (remove_index, source) in sources {\n                __profile_add(3,1);')
f=repl(f,'                                Some(op.clone())','                                match op {PatchOperation::Add(op)=>{__profile_add(58,1);__profile_add(59,__payload_owned_utf8_bytes(&op.value) as u64);},PatchOperation::Replace(op)=>{__profile_add(58,1);__profile_add(59,__payload_owned_utf8_bytes(&op.value) as u64);},_=>{}}\n                                Some(op.clone())')
f=repl(f,'                let candidate = Patch(','                __profile_add(4,(patch.0.len()-1) as u64);\n                let candidate = Patch(')
f=repl(f,'                if apply_json_patch(left, &candidate).is_ok_and','                __profile_add(5,1);\n                __profile_add(6,candidate.0.len() as u64);\n                if apply_json_patch(left, &candidate).is_ok_and')
f=repl(f,'                    replacement = Some(candidate);','                    __profile_add(7,1);\n                    replacement = Some(candidate);')
f=repl(f,'    // A copy source must exist immediately before that operation.','    drop(move_timer);\n    let _copy_timer=__ProfileTimer::new(14);\n    // A copy source must exist immediately before that operation.')
f=f.replace('                find_copy(\n','                __profile_add(8,1);\n                find_copy(\n',1)
f=repl(f,'                        patch.0[0] = copied;','                        __profile_add(9,1);\n                        patch.0[0] = copied;')
f=repl(f,'                        for (offset, previous) in patch.0[applied..index].iter().enumerate() {','                        __profile_add(10,(index-applied) as u64);\n                        for (offset, previous) in patch.0[applied..index].iter().enumerate() {')
f=repl(f,'                        find_copy(\n','                        __profile_add(8,1);\n                        find_copy(\n')
f=repl(f,'        if let Some(replacement) = replacement {','        if let Some(replacement) = replacement {\n            __profile_add(9,1);')
s=s[:start]+f+s[end:]
# recursive traversal counters (not timings)
start=s.index('fn collect_scalars('); end=s.index('\n// Index destinations',start); f=s[start:end]
f=repl(f,'    let kind = scalar_kind(value);','    __profile_add(12,1);\n    let kind = scalar_kind(value);')
f=repl(f,'    // A source pointer adds its serialized string contents','    __profile_add(11,1);\n    // A source pointer adds its serialized string contents')
s=s[:start]+f+s[end:]
# true one-candidate replay helper
start=s.index('fn candidate_applies');end=s.index('\n// Replace-only patches',start);f=s[start:end]
f=repl(f,') -> bool {',') -> bool {\n    let _timer=__ProfileTimer::new(37);\n    __profile_add(26,1);')
f=repl(f,'    for (index, operation) in operations.enumerate() {','    for (index, operation) in operations.enumerate() {\n        __profile_add(27,1);')
s=s[:start]+f+s[end:]
# general rationalizer stages + loop counts. Specialized replacement branch retains original code.
start=s.index('fn rationalize(left:');end=s.index('\n#[derive(Clone, Copy)]',start);f=s[start:end]
f=repl(f,'-> Result<Patch, Error> {','-> Result<Patch, Error> {\n    let _total=__ProfileTimer::new(15);')
f=repl(f,'    let (mut current_size, mut guard_costs, mut baseline_verified) = if tests {','    let (mut current_size, mut guard_costs, mut baseline_verified) = if tests {\n        let _initial=__ProfileTimer::new(29);')
f=repl(f,'        let mut selection_proof = None;','        __profile_add(16,1);\n        let selection_timer=__ProfileTimer::new(30);\n        let mut selection_proof = None;')
f=repl(f,'            for (index, operation) in patch.0.iter().enumerate() {','            for (index, operation) in patch.0.iter().enumerate() {\n                __profile_add(19,1);')
f=repl(f,'        if boundary_crossed || selected.is_empty() {','        drop(selection_timer);\n        __profile_add(20,selected.len() as u64);\n        if boundary_crossed || selected.is_empty() {')
f=repl(f,'        let independent_guards = tests','        __profile_add(17,1);\n        let proof_timer=__ProfileTimer::new(31);\n        let independent_guards = tests')
f=repl(f,'        let mut guarded_shadow = None;','        drop(proof_timer);\n        let cost_timer=__ProfileTimer::new(32);\n        let mut guarded_shadow = None;')
f=repl(f,'        if let Ok((candidate_size, candidate_costs)) = cost {','        drop(cost_timer);\n        if let Ok((candidate_size, candidate_costs)) = cost {')
f=repl(f,'            let valid = if let Some(shadow) = guarded_shadow {','            let validation_timer=__ProfileTimer::new(33);\n            let valid = if let Some(shadow) = guarded_shadow {')
f=repl(f,'            if valid {','            drop(validation_timer);\n            if valid {\n                __profile_add(18,1);\n                __profile_add(28,patch.0.len() as u64);\n                let compact_timer=__ProfileTimer::new(34);')
f=repl(f,'                selections = None;','                drop(compact_timer);\n                selections = None;')
s=s[:start]+f+s[end:]
# exact cost prefix rebuild
start=s.index('fn replacement_guard_costs');end=s.index('\nfn guarded_bytes(',start);f=s[start:end]
f=repl(f,') -> (usize, Vec<GuardCost>) {',') -> (usize, Vec<GuardCost>) {\n    let _timer=__ProfileTimer::new(36);\n    __profile_add(24,1);\n    __profile_add(25,(costs.len()-1) as u64);')
s=s[:start]+f+s[end:]
# actual guarded replay apply ops and test payloads
start=s.index('fn guarded_operation_bytes');end=s.index('\nfn test_source',start);f=s[start:end]
f=repl(f,'    let mut shadow = left.clone();','    let _timer=__ProfileTimer::new(35);\n    __profile_add(21,1);\n    let mut shadow = left.clone();')
f=repl(f,'    for (index, op) in operations.clone().take(first).enumerate() {','    for (index, op) in operations.clone().take(first).enumerate() {\n        __profile_add(22,1);')
f=repl(f,'        for (path, value) in guard_values(&shadow, op)?.into_iter().flatten() {','        __profile_add(22,1);\n        for (path, value) in guard_values(&shadow, op)?.into_iter().flatten() {\n            __profile_add(23,1);')
s=s[:start]+f+s[end:]
start=s.index('fn guard(mut shadow:');end=s.index('\n/// Produce an inverse',start);f=s[start:end]
f=repl(f,'    for (index, op) in patch.0.iter().enumerate() {','    for (index, op) in patch.0.iter().enumerate() {\n        __profile_add(38,1);')
f=repl(f,'        for (path, value) in guard_values(&shadow, op)?.into_iter().flatten() {','        for (path, value) in guard_values(&shadow, op)?.into_iter().flatten() {\n            __profile_add(39,1);')
s=s[:start]+f+s[end:]
s=header+s
source.write_text(s);(p/'instrumented-rfc.rs').write_text(s)
(p/'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='published/src/rfc.rs',tofile='instrumented/src/rfc.rs')))
lib=p/'baseline/src/lib.rs';lib.write_text(lib.read_text()+'\n#[doc(hidden)]\npub use rfc::{__profile_reset,__profile_read};\n')
(p/'metrics.json').write_text(json.dumps(labels,indent=2)+'\n')
print('instrumented_rfc_sha256',hashlib.sha256(s.encode()).hexdigest())
