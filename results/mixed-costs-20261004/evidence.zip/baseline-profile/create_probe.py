from pathlib import Path
import json,hashlib,copy
p=Path('/tmp/palim-mixed-profile-20261004'); fixtures=p/'fixtures';fixtures.mkdir(exist_ok=True)
manifest=[]
for n in [100,400,800]:
 for kind in ['independent_add_remove_replace','root_add_guard_overlap','file_migrations_move_copy','object_remove_replace_no_add']:
  if kind=='file_migrations_move_copy':
   payload={"license":"MIT","format":"package-manifest","contents":"[package]\nname = \"component\"\n"+'a'*800}
   common={'format':'rust-package','license':'MIT','template':'[package]\n'+'b'*256}
   left={'apiVersion':'workspace/v1','kind':'FileManifest','common_template':common,'files':{f'legacy_component_{i:04d}.toml':dict(payload,component=i) for i in range(n)},'unchanged_notes':'metadata retained '*120}
   right=copy.deepcopy(left);right['files']={f'current_component_{i:04d}.toml':dict(payload,component=i) for i in range(n)};right['common_template_copy']=copy.deepcopy(common)
  else:
   left={'apiVersion':'config/v1','kind':'ConfigManifest','metadata':{'name':'service-configs'},'configs':{},'unchanged_notes':'metadata retained '*120}
   right=copy.deepcopy(left)
   for i in range(n):
    key=f'service_{i:04d}'
    left['configs'][key]={'name':key,'deprecated_timeout_setting':-100000-i,'application_version_long_name':f'v1-{i:04d}','database_connection_pool_size':10+i}
    right['configs'][key]={'name':key,'application_version_long_name':f'v2-{i:04d}','database_connection_pool_size':20+i}
    if kind!='object_remove_replace_no_add':right['configs'][key]['request_timeout_seconds']=100000+i
   if kind=='root_add_guard_overlap':right['deployment_generation']=2
  value={'name':f'{kind}_{n}','shape':kind,'size':n,'provenance':'Synthetic scalable document shaped as service configuration or workspace package-file manifests; no claim to be an actual user document.','left':left,'right':right}
  out=fixtures/(value['name']+'.json');blob=(json.dumps(value,separators=(',',':'),ensure_ascii=False)+'\n').encode();out.write_bytes(blob)
  manifest.append({'name':value['name'],'fixture':str(out),'sha256':hashlib.sha256(blob).hexdigest(),'left_bytes':len(json.dumps(left,separators=(',',':')).encode()),'right_bytes':len(json.dumps(right,separators=(',',':')).encode())})
(p/'fixtures.json').write_text(json.dumps(manifest,indent=2)+'\n')
probe=p/'probe';(probe/'src').mkdir(parents=True,exist_ok=True)
(probe/'Cargo.toml').write_text('''[package]\nname="palim-mixed-stage-profile"\nversion="0.0.0"\nedition="2024"\n[dependencies]\npalim={path="/tmp/palim-mixed-profile-20261004/baseline"}\nserde_json={version="1",features=["float_roundtrip","arbitrary_precision"]}\n''')
(probe/'src/main.rs').write_text(r'''use palim::{DiffOptions,DiffPatcher,JsonPatchOptions};
use serde_json::{Value,json};
use std::{sync::Arc,path::PathBuf,collections::BTreeMap};
fn main(){
 let dp=DiffPatcher::new(DiffOptions{object_hash:Some(Arc::new(|v,_|v.get("id").map(Value::to_string))),..Default::default()});
 let directory=PathBuf::from("/tmp/palim-mixed-profile-20261004");
 let fixtures:Value=serde_json::from_slice(&std::fs::read(directory.join("fixtures.json")).unwrap()).unwrap();
 for fixture in fixtures.as_array().unwrap(){
  let input:Value=serde_json::from_slice(&std::fs::read(fixture["fixture"].as_str().unwrap()).unwrap()).unwrap();
  let left=&input["left"];let right=&input["right"];
  for tests in [false,true]{
   palim::__profile_reset();let start=std::time::Instant::now();
   let patch=dp.diff_json_patch(left,right,&JsonPatchOptions{factorize:true,rationalize:true,tests}).unwrap();
   let elapsed=start.elapsed().as_secs_f64()*1000.0;
   let counts:BTreeMap<_,_>=palim::__profile_read().into_iter().collect();
   let serialized=serde_json::to_vec(&patch).unwrap();
   assert_eq!(palim::apply_json_patch(left,&patch).unwrap(),*right);
   let inverse=palim::invert_json_patch(left,&patch).unwrap();
   assert_eq!(palim::apply_json_patch(right,&inverse).unwrap(),*left);
   let stem=format!("{}-{}",input["name"].as_str().unwrap(),if tests{"guarded"}else{"plain"});
   std::fs::write(directory.join("outputs").join(format!("{stem}.json")),&serialized).unwrap();
   println!("{}",json!({"name":input["name"],"shape":input["shape"],"size":input["size"],"tests":tests,"total_ms_instrumented_nonformal":elapsed,"counts":counts,"operations":patch.0.len(),"wire_bytes":serialized.len(),"forward_inverse_pass":true}));
  }
 }
}
''')
(p/'outputs').mkdir(exist_ok=True)
print('fixtures',len(manifest),'API_calls',len(manifest)*2,'probe_sha256',hashlib.sha256((probe/'src/main.rs').read_bytes()).hexdigest())
