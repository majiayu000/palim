use palim::{DiffOptions,DiffPatcher,JsonPatchOptions};
use serde_json::{Value,json};
use std::{sync::Arc,path::PathBuf,collections::BTreeMap};
fn main(){
 let dp=DiffPatcher::new(DiffOptions{object_hash:Some(Arc::new(|v,_|v.get("id").map(Value::to_string))),..Default::default()});
 let directory=PathBuf::from("/tmp/palim-mixed-profile-20261004");
 let fixtures:Value=serde_json::from_slice(&std::fs::read(directory.join("fixtures.json")).unwrap()).unwrap();
 for fixture in fixtures.as_array().unwrap(){
  let input:Value=serde_json::from_slice(&std::fs::read(fixture["fixture"].as_str().unwrap()).unwrap()).unwrap();
  let left=&input["left"];let right=&input["right"];
  for tests in [false,true]{
   palim::__profile_reset();let start=std::time::Instant::now();
   let patch=dp.diff_json_patch(left,right,&JsonPatchOptions{factorize:true,rationalize:true,tests}).unwrap();
   let elapsed=start.elapsed().as_secs_f64()*1000.0;
   let counts:BTreeMap<_,_>=palim::__profile_read().into_iter().collect();
   let serialized=serde_json::to_vec(&patch).unwrap();
   assert_eq!(palim::apply_json_patch(left,&patch).unwrap(),*right);
   let inverse=palim::invert_json_patch(left,&patch).unwrap();
   assert_eq!(palim::apply_json_patch(right,&inverse).unwrap(),*left);
   let stem=format!("{}-{}",input["name"].as_str().unwrap(),if tests{"guarded"}else{"plain"});
   std::fs::write(directory.join("outputs").join(format!("{stem}.json")),&serialized).unwrap();
   println!("{}",json!({"name":input["name"],"shape":input["shape"],"size":input["size"],"tests":tests,"total_ms_instrumented_nonformal":elapsed,"counts":counts,"operations":patch.0.len(),"wire_bytes":serialized.len(),"forward_inverse_pass":true}));
  }
 }
}
