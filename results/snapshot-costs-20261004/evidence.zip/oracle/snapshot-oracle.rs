#[cfg(test)]
mod snapshot_cost_oracle {
    use super::*;
    #[test]
    fn freeze() {
        let cases: Vec<Value> = serde_json::from_str(include_str!("/tmp/palim-snapshot-cost-oracle-20261004/snapshot-cases.json")).unwrap();
        let mut records=Vec::new();
        for case in cases {
            let left=&case["left"];
            let original=Patch(case["original"].as_array().unwrap().iter().cloned().map(|v|decode(v).unwrap()).collect());
            let actual=guard(left.clone(),&original);
            let calculated=guarded_operation_bytes(left,original.0.iter(),original.0.len(),&[]);
            let mut record=json!({"id":case["id"]});
            match (actual,calculated) {
                (Err(a),Err(b))=>{assert_eq!(a,b);assert_eq!(case["error"],true);record["error"]=json!({"path":a.path,"message":a.message});},
                (Ok(actual),Ok((size,costs,shadow)))=>{
                    assert_ne!(case["error"],true);
                    assert_eq!(size,bytes(&actual).unwrap());
                    let mut independent=left.clone();json_patch::patch(&mut independent,&actual).unwrap();assert_eq!(independent,shadow);
                    let mut prefixes=Vec::new();
                    for end in 0..=original.0.len() {
                        let prefix=guard(left.clone(),&Patch(original.0[..end].to_vec())).unwrap();
                        assert_eq!(costs[end].bytes,bytes(&prefix).unwrap());
                        assert_eq!(costs[end].operations,prefix.0.len());
                        assert_eq!(guarded_bytes(left,&original,true,&costs[..=end]).unwrap().0,size);
                        prefixes.push(json!({"bytes":costs[end].bytes,"operations":costs[end].operations}));
                    }
                    record["prefixes"]=json!(prefixes);
                    record["patch_wire"]=json!(serde_json::to_string(&actual).unwrap());
                    let inverse=crate::invert_json_patch(left,&actual).unwrap();
                    json_patch::patch(&mut independent,&inverse).unwrap();assert_eq!(independent,*left);
                    record["inverse_wire"]=json!(serde_json::to_string(&inverse).unwrap());
                },
                _=>panic!("error contract mismatch {}",case["id"]),
            }
            records.push(record);
        }
        std::fs::write(std::env::var("PALIM_SNAPSHOT_ORACLE_OUTPUT").unwrap(),serde_json::to_vec(&records).unwrap()).unwrap();
        println!("Snapshot oracle: {} cases",records.len());
    }
}
