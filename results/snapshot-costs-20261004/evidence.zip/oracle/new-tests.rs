    #[test]
    fn object_rename_snapshot_costs_match_serialized_prefixes_and_resumed_replay() {
        let payload: Value = serde_json::from_str(
            r#"{"float":1.0,"integer":1234567890123456789012345678901234567890,"exponent":1e9999}"#,
        )
        .unwrap();
        let object = json!({"":payload,"a/~\"\\\n":payload,"~1":[payload,"🦀"]});
        for container in ["", "/outer~1~0", "/items/0"] {
            let left = match container {
                "" => object.clone(),
                "/items/0" => json!({"items":[object]}),
                _ => json!({"outer/~":object}),
            };
            let original = Patch(
                [("a/~\"\\\n", "短"), ("", "目标~/🤖\0"), ("~1", "~01")]
                    .into_iter()
                    .map(|(source, destination)| {
                        decode(json!({"op":"move","from":pointer(container,source),
                            "path":pointer(container,destination)}))
                        .unwrap()
                    })
                    .collect(),
            );
            let actual = guard(left.clone(), &original).unwrap();
            let (size, costs, shadow) =
                guarded_operation_bytes(&left, original.0.iter(), original.0.len(), &[]).unwrap();
            assert_eq!(size, bytes(&actual).unwrap());
            let mut applied = left.clone();
            json_patch::patch(&mut applied, &actual).unwrap();
            assert_eq!(shadow, applied);
            for end in 0..=original.0.len() {
                let prefix = guard(left.clone(), &Patch(original.0[..end].to_vec())).unwrap();
                assert_eq!(costs[end].bytes, bytes(&prefix).unwrap());
                assert_eq!(costs[end].operations, prefix.0.len());
                assert_eq!(
                    guarded_bytes(&left, &original, true, &costs[..=end])
                        .unwrap()
                        .0,
                    size
                );
            }
            let inverse = crate::invert_json_patch(&left, &actual).unwrap();
            json_patch::patch(&mut applied, &inverse).unwrap();
            assert_eq!(applied, left);
        }
    }

    #[test]
    fn object_rename_snapshot_costs_reset_on_other_writes_and_preserve_errors() {
        let left = json!({"o":{"a":{"body":"old"},"b":2,"c":3,"d":4,
            "e":5,"f":6,"g":7,"overwrite":{"large":"🦀".repeat(50)}},
            "arr":[1,2],"source":"copy"});
        let original = patch(json!([
            {"op":"move","from":"/o/a","path":"/o/new-a"},
            {"op":"move","from":"/o/b","path":"/o/overwrite"},
            {"op":"move","from":"/o/c","path":"/o/new-c"},
            {"op":"replace","path":"/o/new-a/body","value":"changed 🦀"},
            {"op":"move","from":"/o/d","path":"/o/new-d"},
            {"op":"copy","from":"/source","path":"/o/copied"},
            {"op":"move","from":"/o/e","path":"/o/new-e"},
            {"op":"move","from":"/arr/0","path":"/arr/1"},
            {"op":"move","from":"/o/f","path":"/o/new-f"},
            {"op":"add","path":"/o/added","value":true},
            {"op":"remove","path":"/o/copied"},
            {"op":"test","path":"/source","value":"copy"},
            {"op":"move","from":"/o/g","path":"/o/new-g"},
            {"op":"move","from":"/o/new-g","path":"/outside"},
            {"op":"move","from":"/o/new-f","path":"/o/final-f"}
        ]));
        let (size, costs) = guarded_bytes(&left, &original, true, &[]).unwrap();
        assert_eq!(
            size,
            bytes(&guard(left.clone(), &original).unwrap()).unwrap()
        );
        for end in 0..=original.0.len() {
            let prefix = guard(left.clone(), &Patch(original.0[..end].to_vec())).unwrap();
            assert_eq!(costs[end].bytes, bytes(&prefix).unwrap());
            assert_eq!(costs[end].operations, prefix.0.len());
            assert_eq!(
                guarded_bytes(&left, &original, true, &costs[..=end])
                    .unwrap()
                    .0,
                size
            );
        }
        let mut invalid = original;
        invalid
            .0
            .push(decode(json!({"op":"move","from":"/o/missing","path":"/o/end"})).unwrap());
        assert_eq!(
            guarded_bytes(&left, &invalid, true, &[]).err(),
            guard(left, &invalid).err()
        );
    }

