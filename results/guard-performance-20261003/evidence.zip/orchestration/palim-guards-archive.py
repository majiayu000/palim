import hashlib,json,pathlib,subprocess,zipfile
R=pathlib.Path('/Users/apple/Desktop/code/AI/tool/secrets/palim-guards');O=R/'results/guard-performance-20261003';entries={}
def add(p,name):
 p=pathlib.Path(p)
 if p.is_file():entries[name]=p.read_bytes()
def tree(p,prefix,skip=()):
 p=pathlib.Path(p)
 for f in sorted(p.rglob('*')):
  rel=f.relative_to(p)
  if f.is_file() and not any(x in skip for x in rel.parts):add(f,prefix+'/'+str(rel))
M=pathlib.Path('/tmp/palim-guards-benchmark-final-20261003');C=pathlib.Path('/tmp/palim-guards-competitors-final-20261003');F=pathlib.Path('/tmp/palim-guards-rfc-20261003');P=pathlib.Path('/tmp/palim-competitor-20261003');S=pathlib.Path('/tmp/palim-guards-small-20261003')
tree(M,'loaded',skip=('target',))
tree(C,'competitor-measurements')
for directory in ['fixtures','js','go']:tree(P/directory,'competitors/'+directory,skip=('node_modules','probe'))
g=pathlib.Path('/Users/apple/go/pkg/mod/github.com/w!i2!l/jsondiff@v0.7.1')
if not g.exists():
 hits=list(pathlib.Path('/Users/apple/go/pkg/mod/github.com').glob('*/*jsondiff*@v0.7.1'));g=hits[0] if hits else None
if g:tree(g,'prior-art/go-jsondiff-v0.7.1',skip=('.git',))
for f in F.iterdir():
 if f.is_file():add(f,'rfc/'+f.name)
for directory in ['baseline','candidate-oracle','baseline-driver','candidate-driver','probe']:
 d=F/directory
 for n in ['Cargo.toml','Cargo.lock','README.md']:add(d/n,'rfc/'+directory+'/'+n)
 for n in ['src','examples','benches']:tree(d/n,'rfc/'+directory+'/'+n,skip=('target',))
add(S/'evidence.zip','native/evidence.zip');add(S/'REPORT.md','native/REPORT.md');add(S/'verification.json','native/verification.json');add(S/'source-hashes.json','native/source-hashes.json')
tree('/tmp/palim-guards-review-20261003','review')
for f in ['BENCHMARK.md','Cargo.toml','Cargo.lock','README.md','LICENSE']:add(R/f,'candidate/'+f)
for d in ['src','tests','examples','benches']:tree(R/d,'candidate/'+d)
for f in ['remaining-hotspots.py','interop.mjs','package.json','package-lock.json']:add(R/'tools'/f,'candidate/tools/'+f)
for f in ['Cargo.toml','Cargo.lock','fuzz_targets/core.rs']:add(R/'fuzz'/f,'candidate/fuzz/'+f)
for f in ['palim-guards-competitors-final.py','palim-guards-checks.py','palim-guards-artifacts.py','palim-guards-archive.py','palim-guards-start-20261003.json','palim-guards-package-consumer-20261003.json']:
 add(pathlib.Path('/tmp')/f,'orchestration/'+f)
for f in ['Cargo.toml','Cargo.lock','src/main.rs']:add(pathlib.Path('/tmp/palim-guards-consumer-20261003')/f,'consumer/'+f)
add(R/'target/package/palim-0.1.0.crate','package/palim-0.1.0.crate')
for f in ['REPORT.md','checks.json','measurements.json']:add(O/f,'final/'+f)
entries['task.patch']=subprocess.check_output(['git','diff','--','src/diff.rs','src/rfc.rs','tools/remaining-hotspots.py','BENCHMARK.md'],cwd=R)
manifest={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(O/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(O/'evidence.zip') as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(k)).hexdigest()==v['sha256'] for k,v in manifest.items())
print(json.dumps(dict(entries=len(entries),bytes=(O/'evidence.zip').stat().st_size,sha256=hashlib.sha256((O/'evidence.zip').read_bytes()).hexdigest(),manifest_verified=True,go_prior_art_archived=str(g)),indent=2))
