
use serde_json::json;
use palim::{DiffPatcher,JsonPatchOptions};
fn main(){for n in [100,400,800] {for tests in [true] {
 let a=json!((0..n).map(|i|json!({"id":i,"a_long_property_name":i,"b_long_property_name":i,"c_long_property_name":i})).collect::<Vec<_>>());
 let b=json!((0..n).map(|i|json!({"id":i,"a_long_property_name":i+100000,"b_long_property_name":i+200000,"c_long_property_name":i+300000})).collect::<Vec<_>>());
 let start=std::time::Instant::now();
 let p=DiffPatcher::default().diff_json_patch(&a,&b,&JsonPatchOptions{factorize:false,rationalize:true,tests}).unwrap();
 let elapsed=start.elapsed().as_secs_f64()*1000.0;
 assert_eq!(palim::apply_json_patch(&a,&p).unwrap(),b);
 println!("{}",json!({"case":n,"guarded":tests,"total_ms":elapsed,"operations":p.0.len(),"bytes":serde_json::to_vec(&p).unwrap().len()}));
}}}
