
use serde_json::Value;
use palim::{DiffPatcher,DiffOptions,JsonPatchOptions};
use std::sync::Arc;
fn main(){
 let cases: Vec<Value>=serde_json::from_slice(&std::fs::read("/Users/apple/Desktop/code/AI/tool/secrets/palim/tests/fixtures/correctness.json").unwrap()).unwrap();
 let dp=DiffPatcher::new(DiffOptions{object_hash:Some(Arc::new(|v,_|v.get("id").map(Value::to_string))),..Default::default()});
 for (i,case) in cases.iter().enumerate(){for factorize in [false,true]{for rationalize in [false,true]{for tests in [false,true]{
  let patch=dp.diff_json_patch(&case["left"],&case["right"],&JsonPatchOptions{factorize,rationalize,tests}).unwrap();
  let actual=palim::apply_json_patch(&case["left"],&patch).unwrap();assert_eq!(actual,case["right"]);
  let inverse=palim::invert_json_patch(&case["left"],&patch).unwrap();assert_eq!(palim::apply_json_patch(&actual,&inverse).unwrap(),case["left"]);
  println!("{}",serde_json::json!({"index":i,"factorize":factorize,"rationalize":rationalize,"tests":tests,"patch":patch}));
 }}}}
}
