# Guard 成本复用的最小证明边界

基线：13ebc70。仅只读源码研究；没有生产修改、编译、测试或计时。`design-proof.json` 保存冻结源码 hash、完整输入与候选及预期结果；这些预期源于源码推导，尚未冒称原生执行。

## 可复用的范围

先用已有完整 guard replay 的最终 shadow 验证当前 patch 能到达 right，再要求现有 independent_replacement 成立。对每个外部 Add/Copy/Move，额外保守排除 parent(destination) 为替换边界祖先的情况。此时所有外部 guard 读取的 destination/source/parent 都与边界不相交，原来的逐 op 成本差额保持有效。Replace/Remove 不新增父快照风险；Test 不新增 guard。

不必新增状态层。first selected 之前没有内部操作，外部操作也不能改变边界，所以 replacement 的旧值就是 left.pointer(ancestor)。已有对象 sibling 的 Add 可能可以放宽，但需要当时存在性判断，本轮不要求。

## 不可省掉的条件

- 缺失 sibling 的 Add 会快照父容器。提前压缩 /a 可以保持最终结果，却把 add /z 时 root 内的 a.y 从 0 提前改成 22222；外部 guard 多四个字节。嵌套 /p/a 与 /p/z 同理。
- Copy/Move 即使 source 完全不相交，缺失 sibling destination 的父快照仍有同样风险。
- 跨边界 Copy source 可能被后续 overwrite 隐藏，因此最终值相同仍不能保证 intermediate guards 相同；现有 independence 必须拒绝。
- 重复写入的 guard 读取中间值；removed op 用现有精确成本相减，不能改为从 left/right 重新算。独立 sibling 重复写入的差额可复用，但压缩后的 prefix 索引必须重建。
- ancestor array 上的 Remove/Move/Add/Copy 会移动边界和指针；保持现有拒绝，不放宽。

## 成本和错误合同

累计差额含 group 前导逗号。先依据旧 prefix.operations 去掉它，再依据新 prefix.operations 补回；replacement group 的两个 op 自身含一个逗号。接受候选后按新索引重建累计 bytes/operations，避免下一候选混用旧 prefix。

数学 JSON 相等无法证明序列化长度相等。保留实际 serializer、错误传播、旧路径 fallback。initial replay 失败不能变成成本缺失或零；最终状态验证不足以替代 guard footprint 证明。

## 最终冻结只读确认

生产逻辑与前次审查完全一致（`#[cfg(test)]`之前源码 SHA256 为 `80b873d86caeb04775cd71a8851853ab46b19e2d2b64ab42c22f17120bcba199`）。最终 RFC 源码 SHA256 为 `e909c9c8c98bff16e3f092ca6a8ab96b5f3243bc4debf2218ac6b35f958a2366`；diff 源码 SHA256 为 `906a816e4016aca85de033a8f96a75bdca616689a0208d263e073fb705f46f31`。父 agent 已确认冻结。

已只读检查新增 private 测试：valid original 到不了完整 right 时禁快捷路径，invalid initial patch 仍返回原 guard-cost Error。隔离 oracle 的 source 对每个 fixture 验证正向和逆向；performance_lead 提供的 baseline/candidate JSON 各 16 条（8 fixture×tests 两模式），我直接读取确认完整文件字节相同，SHA256 为 `c1ebd51b6c8fa7f14876fa83bef6b4485cbfef5557bbe3aced2d2ccf3e10693a`。其 native build/run 是 performance_lead 的证据，我未重跑；旧 shared target oracle 缓存结果已由其废弃。

未发现阻塞问题，最终完整记录见 `final-review.json`。本 reviewer 没有编译、测试、计时或新增探索。
