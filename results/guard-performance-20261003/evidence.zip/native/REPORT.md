# Native small-config object lookup reduction — 2026-10-03

## Scope and verified source findings
Frozen baseline `13ebc709cd38a09799d73ec9d80d8d05b73b0581` in `palim-guards`.
Only production `src/diff.rs` changed; `numbers.rs`, text/RFC, dependencies, options and APIs untouched.
Source inspection verifies native `diff::node` uses serde_json representation equality and does not call
`numbers_equal` or `number_key`; number normalization is therefore not this workload's native hotspot.
Atomic replacements already clone two Values directly and avoid redundant Serialize/to_value.
`pointer` is outside the owned scope; no path contract or error changes introduced.

## Minimal decision/proof
The object branch previously looks up every old key in right, then looks up every right key in left,
even when there are no newly added keys. Count only first-pass `Some(new)` lookups, after the existing
property predicate and before the equal-primitive continue. If the count equals right map length,
every distinct right key has already been found in left; second pass cannot contain an added property.
Skip that complete second loop. Rejected properties simply leave a smaller count and retain the
original fallback loop. No extra scan, allocation, hash table, callback, public flag or helper layer.
Old deletion handling and node_filter/property_filter call order remain untouched.
The count is bounded by right.len(), so no new overflow or error path.

## Measured results
Same frozen fixture, loaded native diff including delta drop; parsing/validation oracle outside timer.
Three independent processes per version/case, 9 samples/process, alternating version order.
Timing binary has no allocator hook; memory measured by separate allocation binary.

| Workload | Baseline μs | Candidate μs | Conclusion |
|---|---:|---:|---|
| small-config-edit (30 equal keys, one integer edit) | 2.602132 | 1.932597 | 26% less loaded diff time / 1.35× |
| small-config-added | 2.300273 | 2.285319 | equivalent within noise |
| small-config-key-churn (same len, different key set) | 2.847046 | 2.840108 | equivalent within noise |

Small-config process medians baseline [2.602132, 2.569804, 2.602966] μs,
candidate [1.944092, 1.921793, 1.932597] μs. All three candidate processes improve.
All raw samples retained in measurements.json. Output hashes identical, forward/inverse independently
checked per process. Allocation/reallocation calls, total requested bytes, peak additional live bytes
unchanged in all three repeats per case:
- edit: 20 calls, 1482 requested B, 1359 peak B, final live delta 0;
- added: 26 calls, 1605 requested B, 1448 peak B, final 0;
- key churn: 29 calls, 1654 requested B, 1480 peak B, final 0.

These are loaded core results, not full parse→diff→serialize improvements or global ranking.
The prior parser diagnosis established caller-side parsing dominates this small input; root will
freshly rebuild the combined source and rerun complete pipeline/competitor comparisons.

## Correctness and error/callback verification
The first attempt built same-named source-package examples in a shared target and returned identical
binary SHA256. That experiment is rejected, retained under invalid-shared-example-cache; never used
as proof of candidate verification. The independent dependency probe timing/allocation binaries were
distinct and correctly identified; their measured samples remain valid.
Trace and fixture binaries were rebuilt in independent targets with palim fingerprints removed,
exact path package IDs saved in baseline-package-ids.json / candidate-package-ids.json, and distinct
baseline/candidate executable SHA256 recorded. Corrected acceptance:
- 4 fixtures × 4 modes (default, all callbacks, property rejection, node rejection): complete events,
  delta, inverse, projected result and RFC stdout byte-identical; forward/reverse and RFC apply checked.
- Existing correctness.json 373 cases including atomic, array, object, adds/deletes and escaped keys:
  complete delta/inverse/RFC stdout byte-identical, all forward/inverse/RFC checks passed.
  stdout SHA256 `3146d3e7657aefa636bab85a21ad9d1efcda290dcf188ac3e74f53b0d140e8b1`.
- `cargo test --release --locked --test core --test performance_regressions --target-dir ../../probes/candidate/target`:
  core 10/10 and performance_regressions 13/13 pass, including existing advanced callback trace,
  atomic number representation, depth/option/errors and structural cases. No implementation-mirroring test added.
- targeted rustfmt --check and git diff --check: passed.

## Frozen production and reproducibility
Final `src/diff.rs` SHA256 `906a816e4016aca85de033a8f96a75bdca616689a0208d263e073fb705f46f31`.
Measured candidate differs only by removing one unnecessary blank line; see measured-vs-final-format.patch.
owned.patch attributes this task's one production file. No commits/push/publication performed.
Exact sources, locks, probes, input fixtures, raw output/samples, source/binary hashes, environment
and failed-cache record are preserved under /tmp/palim-guards-small-20261003.

Build each probe independently with `cargo build --release --locked --bins --target-dir target`
from probes/baseline and probes/candidate. Copy release timing/allocation/callback_probe/fixture_runner
into the respective preserved binary directory. `python3 run.py` reproduces the bounded timing;
`python3 verify.py` reproduces byte equivalence. Existing focused tests run from sources/candidate.
The compact evidence archive excludes build outputs/binaries and unrelated historical results/tools,
but includes all necessary source/lock/README/test/probe/input files to rebuild from scratch.
