use palim::{apply_json_patch, diff, diff_json_patch, invert_json_patch_guarded, patch, reverse, test_json_patch, JsonPatchOptions, Patch};
use serde_json::{Value, json};

fn main() {
    let before = json!({"items":[{"code":"1"},{"code":"2"}], "keep":"unchanged"});
    let operations: Patch = serde_json::from_str(r#"[{"op":"add","path":"/items/0","value":{"code":"3"}}]"#).unwrap();
    let after = apply_json_patch(&before, &operations).unwrap();
    let inverse = invert_json_patch_guarded(&before, &operations).unwrap();
    assert_eq!(apply_json_patch(&after, &inverse).unwrap(), before);
    assert!(apply_json_patch(&json!({"items":[{"code":"1"},{"code":"2"},{"code":"3"}],"keep":"unchanged"}), &inverse).is_err());
    let tests: Patch = serde_json::from_str(r#"[{"op":"test","path":"/n","value":1.0}]"#).unwrap();
    test_json_patch(&json!({"n":1}), &tests).unwrap();
    let huge: Value = serde_json::from_str(r#"{"n":1e10000}"#).unwrap();
    let tests: Patch = serde_json::from_str(r#"[{"op":"test","path":"/n","value":10e9999}]"#).unwrap();
    test_json_patch(&huge, &tests).unwrap();
    let text = "long Unicode 🦀 text\n".repeat(10_000);
    let edited = text.replacen("text", "edit", 1).replacen("Unicode", "changed", 1) + "finish";
    let (a,b) = (json!(text),json!(edited));
    let delta = diff(&a,&b).unwrap().unwrap();
    assert_eq!(patch(&a,&delta).unwrap(),b);
    assert_eq!(patch(&b,&reverse(&delta).unwrap()).unwrap(),a);
    let standard = diff_json_patch(&a,&b,&JsonPatchOptions::default()).unwrap();
    assert_eq!(apply_json_patch(&a,&standard).unwrap(),b);
    println!("new APIs, guarded drift rejection, exact numbers and Unicode roundtrip passed");
}
