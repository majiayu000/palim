import fs from 'node:fs'; import {isDeepStrictEqual} from 'node:util'; import pkg from 'fast-json-patch';
const f=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));const p=JSON.parse(fs.readFileSync(0,'utf8'));
const actual=pkg.applyPatch(structuredClone(f.left),p,true,false).newDocument;if(!isDeepStrictEqual(actual,f.right))throw new Error('RFC result mismatch');console.log('verified');
