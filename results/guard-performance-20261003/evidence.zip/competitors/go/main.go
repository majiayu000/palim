package main
import("encoding/json";"os";"time";"sort";"fmt"; d "github.com/wI2L/jsondiff")
func main(){
 f,err:=os.ReadFile(os.Args[2]);if err!=nil{panic(err)}
 var c struct{Name string `json:"name"`;Left json.RawMessage `json:"left"`;Right json.RawMessage `json:"right"`};if err=json.Unmarshal(f,&c);err!=nil{panic(err)}
 var opts []d.Option
 switch os.Args[1]{case "optimized":opts=[]d.Option{d.Factorize(),d.Rationalize()};case "lcs":opts=[]d.Option{d.LCS()};case "optimized-lcs":opts=[]d.Option{d.LCS(),d.Factorize(),d.Rationalize()}}
 exec:=func()[]byte{p,e:=d.CompareJSON(c.Left,c.Right,opts...);if e!=nil{panic(e)};b,e:=json.Marshal(p);if e!=nil{panic(e)};return b}
 output:=exec();for i:=0;i<20;i++{exec()};n:=1
 for {t:=time.Now();for i:=0;i<n;i++{exec()};if time.Since(t)>=25*time.Millisecond||n>=16384{break};n*=2}
 samples:=[]float64{};for j:=0;j<10;j++{t:=time.Now();for i:=0;i<n;i++{exec()};samples=append(samples,float64(time.Since(t).Nanoseconds())/1e6/float64(n))};sorted:=append([]float64{},samples...);sort.Float64s(sorted)
 var p []map[string]interface{};if err=json.Unmarshal(output,&p);err!=nil{panic(err)};counts:=map[string]int{};for _,op:=range p{counts[op["op"].(string)]++}
 r:=map[string]interface{}{"name":c.Name,"engine":"go-jsondiff-v0.7.1-"+os.Args[1],"pipeline_ms":(sorted[4]+sorted[5])/2,"samples_ms":samples,"operations":len(p),"operation_counts":counts,"patch_bytes":len(output),"patch":json.RawMessage(output)};b,_:=json.Marshal(r);fmt.Println(string(b))
}
